module.exports = {

"[project]/node_modules/.pnpm/@vercel+analytics@1.3.1_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/@vercel/analytics/dist/react/index.mjs (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Analytics": ()=>Analytics,
    "track": ()=>track
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const Analytics = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Analytics() from the server but Analytics is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/@vercel+analytics@1.3.1_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/@vercel/analytics/dist/react/index.mjs", "Analytics");
const track = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call track() from the server but track is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/@vercel+analytics@1.3.1_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/@vercel/analytics/dist/react/index.mjs", "track");

})()),
"[project]/node_modules/.pnpm/@vercel+analytics@1.3.1_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/@vercel/analytics/dist/react/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$vercel$2b$analytics$40$1$2e$3$2e$1_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f40$vercel$2f$analytics$2f$dist$2f$react$2f$index$2e$mjs__$28$client__proxy$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@vercel+analytics@1.3.1_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/@vercel/analytics/dist/react/index.mjs (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$vercel$2b$analytics$40$1$2e$3$2e$1_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f40$vercel$2f$analytics$2f$dist$2f$react$2f$index$2e$mjs__$28$client__proxy$29$__);

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.module.css [app-rsc] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "geistsans_81192321-module__9LgBlq__className",
  "variable": "geistsans_81192321-module__9LgBlq__variable",
});

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.module.css [app-rsc] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__GeistSans_811923', '__GeistSans_Fallback_811923'"
    }
};
if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/sans.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
;
;

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/sans.js [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$sans$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/sans.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.js [app-rsc] (ecmascript) <export default as GeistSans>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "GeistSans": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistsans_81192321$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistsans_81192321.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.module.css [app-rsc] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "geistmono_8e2790ea-module__isS2MW__className",
  "variable": "geistmono_8e2790ea-module__isS2MW__variable",
});

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.module.css [app-rsc] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__GeistMono_8e2790', ui-monospace, SFMono-Regular, Roboto Mono, Menlo, Monaco, Liberation Mono, DejaVu Sans Mono, Courier New, monospace"
    }
};
if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/mono.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
;
;

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/mono.js [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$mono$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/mono.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.js [app-rsc] (ecmascript) <export default as GeistMono>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "GeistMono": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$geist$40$1$2e$3$2e$0_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$2f$node_modules$2f$geist$2f$dist$2f$geistmono_8e2790ea$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/geist@1.3.0_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1_/node_modules/geist/dist/geistmono_8e2790ea.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "clsx": ()=>clsx,
    "default": ()=>__TURBOPACK__default__export__
});
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
        var o = e.length;
        for(t = 0; t < o; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for(f in e)e[f] && (n && (n += " "), n += f);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = "", o = arguments.length; f < o; f++)(e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;

})()),
"[project]/node_modules/.pnpm/clsx@2.0.0/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "clsx": ()=>clsx,
    "default": ()=>__TURBOPACK__default__export__
});
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) for(t = 0; t < e.length; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    else for(t in e)e[t] && (n && (n += " "), n += t);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = ""; f < arguments.length;)(e = arguments[f++]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;

})()),
"[project]/node_modules/.pnpm/nanoid@5.0.7/node_modules/nanoid/url-alphabet/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "urlAlphabet": ()=>urlAlphabet
});
const urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';

})()),
"[project]/node_modules/.pnpm/nanoid@5.0.7/node_modules/nanoid/index.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "customAlphabet": ()=>customAlphabet,
    "customRandom": ()=>customRandom,
    "nanoid": ()=>nanoid,
    "random": ()=>random
});
var __TURBOPACK__commonjs__external__node$3a$crypto__ = __turbopack_external_require__("node:crypto", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nanoid$40$5$2e$0$2e$7$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/nanoid@5.0.7/node_modules/nanoid/url-alphabet/index.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const POOL_SIZE_MULTIPLIER = 128;
let pool, poolOffset;
function fillPool(bytes) {
    if (!pool || pool.length < bytes) {
        pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER);
        __TURBOPACK__commonjs__external__node$3a$crypto__["webcrypto"].getRandomValues(pool);
        poolOffset = 0;
    } else if (poolOffset + bytes > pool.length) {
        __TURBOPACK__commonjs__external__node$3a$crypto__["webcrypto"].getRandomValues(pool);
        poolOffset = 0;
    }
    poolOffset += bytes;
}
function random(bytes) {
    fillPool(bytes -= 0);
    return pool.subarray(poolOffset - bytes, poolOffset);
}
function customRandom(alphabet, defaultSize, getRandom) {
    let mask = (2 << 31 - Math.clz32(alphabet.length - 1 | 1)) - 1;
    let step = Math.ceil(1.6 * mask * defaultSize / alphabet.length);
    return (size = defaultSize)=>{
        let id = '';
        while(true){
            let bytes = getRandom(step);
            let i = step;
            while(i--){
                id += alphabet[bytes[i] & mask] || '';
                if (id.length === size) return id;
            }
        }
    };
}
function customAlphabet(alphabet, size = 21) {
    return customRandom(alphabet, size, random);
}
function nanoid(size = 21) {
    fillPool(size -= 0);
    let id = '';
    for(let i = poolOffset - size; i < poolOffset; i++){
        id += __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nanoid$40$5$2e$0$2e$7$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["urlAlphabet"][pool[i] & 63];
    }
    return id;
}

})()),
"[project]/node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/non-secure/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "customAlphabet": ()=>customAlphabet,
    "nanoid": ()=>nanoid
});
let urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';
let customAlphabet = (alphabet, defaultSize = 21)=>{
    return (size = defaultSize)=>{
        let id = '';
        let i = size;
        while(i--){
            id += alphabet[Math.random() * alphabet.length | 0];
        }
        return id;
    };
};
let nanoid = (size = 21)=>{
    let id = '';
    let i = size;
    while(i--){
        id += urlAlphabet[Math.random() * 64 | 0];
    }
    return id;
};
;

})()),
"[project]/node_modules/.pnpm/@panva+hkdf@1.2.0/node_modules/@panva/hkdf/dist/node/esm/runtime/fallback.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__commonjs__external__crypto__ = __turbopack_external_require__("crypto", true);
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = (digest, ikm, salt, info, keylen)=>{
    const hashlen = parseInt(digest.substr(3), 10) >> 3 || 20;
    const prk = (0, __TURBOPACK__commonjs__external__crypto__["createHmac"])(digest, salt.byteLength ? salt : new Uint8Array(hashlen)).update(ikm).digest();
    const N = Math.ceil(keylen / hashlen);
    const T = new Uint8Array(hashlen * N + info.byteLength + 1);
    let prev = 0;
    let start = 0;
    for(let c = 1; c <= N; c++){
        T.set(info, start);
        T[start + info.byteLength] = c;
        T.set((0, __TURBOPACK__commonjs__external__crypto__["createHmac"])(digest, prk).update(T.subarray(prev, start + info.byteLength + 1)).digest(), start);
        prev = start;
        start += hashlen;
    }
    return T.slice(0, keylen);
};

})()),
"[project]/node_modules/.pnpm/@panva+hkdf@1.2.0/node_modules/@panva/hkdf/dist/node/esm/runtime/hkdf.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__commonjs__external__crypto__ = __turbopack_external_require__("crypto", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$panva$2b$hkdf$40$1$2e$2$2e$0$2f$node_modules$2f40$panva$2f$hkdf$2f$dist$2f$node$2f$esm$2f$runtime$2f$fallback$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@panva+hkdf@1.2.0/node_modules/@panva/hkdf/dist/node/esm/runtime/fallback.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
let hkdf;
if (typeof __TURBOPACK__commonjs__external__crypto__.hkdf === 'function' && !process.versions.electron) {
    hkdf = async (...args)=>new Promise((resolve, reject)=>{
            __TURBOPACK__commonjs__external__crypto__.hkdf(...args, (err, arrayBuffer)=>{
                if (err) reject(err);
                else resolve(new Uint8Array(arrayBuffer));
            });
        });
}
const __TURBOPACK__default__export__ = async (digest, ikm, salt, info, keylen)=>(hkdf || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$panva$2b$hkdf$40$1$2e$2$2e$0$2f$node_modules$2f40$panva$2f$hkdf$2f$dist$2f$node$2f$esm$2f$runtime$2f$fallback$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(digest, ikm, salt, info, keylen);

})()),
"[project]/node_modules/.pnpm/@panva+hkdf@1.2.0/node_modules/@panva/hkdf/dist/node/esm/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>hkdf,
    "hkdf": ()=>hkdf
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$panva$2b$hkdf$40$1$2e$2$2e$0$2f$node_modules$2f40$panva$2f$hkdf$2f$dist$2f$node$2f$esm$2f$runtime$2f$hkdf$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@panva+hkdf@1.2.0/node_modules/@panva/hkdf/dist/node/esm/runtime/hkdf.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
function normalizeDigest(digest) {
    switch(digest){
        case 'sha256':
        case 'sha384':
        case 'sha512':
        case 'sha1':
            return digest;
        default:
            throw new TypeError('unsupported "digest" value');
    }
}
function normalizeUint8Array(input, label) {
    if (typeof input === 'string') return new TextEncoder().encode(input);
    if (!(input instanceof Uint8Array)) throw new TypeError(`"${label}"" must be an instance of Uint8Array or a string`);
    return input;
}
function normalizeIkm(input) {
    const ikm = normalizeUint8Array(input, 'ikm');
    if (!ikm.byteLength) throw new TypeError(`"ikm" must be at least one byte in length`);
    return ikm;
}
function normalizeInfo(input) {
    const info = normalizeUint8Array(input, 'info');
    if (info.byteLength > 1024) {
        throw TypeError('"info" must not contain more than 1024 bytes');
    }
    return info;
}
function normalizeKeylen(input, digest) {
    if (typeof input !== 'number' || !Number.isInteger(input) || input < 1) {
        throw new TypeError('"keylen" must be a positive integer');
    }
    const hashlen = parseInt(digest.substr(3), 10) >> 3 || 20;
    if (input > 255 * hashlen) {
        throw new TypeError('"keylen" too large');
    }
    return input;
}
async function hkdf(digest, ikm, salt, info, keylen) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$panva$2b$hkdf$40$1$2e$2$2e$0$2f$node_modules$2f40$panva$2f$hkdf$2f$dist$2f$node$2f$esm$2f$runtime$2f$hkdf$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(normalizeDigest(digest), normalizeIkm(ikm), normalizeUint8Array(salt, 'salt'), normalizeInfo(info), normalizeKeylen(keylen, digest));
}
;

})()),
"[project]/node_modules/.pnpm/cookie@0.6.0/node_modules/cookie/index.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

/*!
 * cookie
 * Copyright(c) 2012-2014 Roman Shtylman
 * Copyright(c) 2015 Douglas Christopher Wilson
 * MIT Licensed
 */ 'use strict';
/**
 * Module exports.
 * @public
 */ exports.parse = parse;
exports.serialize = serialize;
/**
 * Module variables.
 * @private
 */ var __toString = Object.prototype.toString;
/**
 * RegExp to match field-content in RFC 7230 sec 3.2
 *
 * field-content = field-vchar [ 1*( SP / HTAB ) field-vchar ]
 * field-vchar   = VCHAR / obs-text
 * obs-text      = %x80-FF
 */ var fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
/**
 * Parse a cookie header.
 *
 * Parse the given cookie header string into an object
 * The object has the various cookies as keys(names) => values
 *
 * @param {string} str
 * @param {object} [options]
 * @return {object}
 * @public
 */ function parse(str, options) {
    if (typeof str !== 'string') {
        throw new TypeError('argument str must be a string');
    }
    var obj = {};
    var opt = options || {};
    var dec = opt.decode || decode;
    var index = 0;
    while(index < str.length){
        var eqIdx = str.indexOf('=', index);
        // no more cookie pairs
        if (eqIdx === -1) {
            break;
        }
        var endIdx = str.indexOf(';', index);
        if (endIdx === -1) {
            endIdx = str.length;
        } else if (endIdx < eqIdx) {
            // backtrack on prior semicolon
            index = str.lastIndexOf(';', eqIdx - 1) + 1;
            continue;
        }
        var key = str.slice(index, eqIdx).trim();
        // only assign once
        if (undefined === obj[key]) {
            var val = str.slice(eqIdx + 1, endIdx).trim();
            // quoted values
            if (val.charCodeAt(0) === 0x22) {
                val = val.slice(1, -1);
            }
            obj[key] = tryDecode(val, dec);
        }
        index = endIdx + 1;
    }
    return obj;
}
/**
 * Serialize data into a cookie header.
 *
 * Serialize the a name value pair into a cookie string suitable for
 * http headers. An optional options object specified cookie parameters.
 *
 * serialize('foo', 'bar', { httpOnly: true })
 *   => "foo=bar; httpOnly"
 *
 * @param {string} name
 * @param {string} val
 * @param {object} [options]
 * @return {string}
 * @public
 */ function serialize(name, val, options) {
    var opt = options || {};
    var enc = opt.encode || encode;
    if (typeof enc !== 'function') {
        throw new TypeError('option encode is invalid');
    }
    if (!fieldContentRegExp.test(name)) {
        throw new TypeError('argument name is invalid');
    }
    var value = enc(val);
    if (value && !fieldContentRegExp.test(value)) {
        throw new TypeError('argument val is invalid');
    }
    var str = name + '=' + value;
    if (null != opt.maxAge) {
        var maxAge = opt.maxAge - 0;
        if (isNaN(maxAge) || !isFinite(maxAge)) {
            throw new TypeError('option maxAge is invalid');
        }
        str += '; Max-Age=' + Math.floor(maxAge);
    }
    if (opt.domain) {
        if (!fieldContentRegExp.test(opt.domain)) {
            throw new TypeError('option domain is invalid');
        }
        str += '; Domain=' + opt.domain;
    }
    if (opt.path) {
        if (!fieldContentRegExp.test(opt.path)) {
            throw new TypeError('option path is invalid');
        }
        str += '; Path=' + opt.path;
    }
    if (opt.expires) {
        var expires = opt.expires;
        if (!isDate(expires) || isNaN(expires.valueOf())) {
            throw new TypeError('option expires is invalid');
        }
        str += '; Expires=' + expires.toUTCString();
    }
    if (opt.httpOnly) {
        str += '; HttpOnly';
    }
    if (opt.secure) {
        str += '; Secure';
    }
    if (opt.partitioned) {
        str += '; Partitioned';
    }
    if (opt.priority) {
        var priority = typeof opt.priority === 'string' ? opt.priority.toLowerCase() : opt.priority;
        switch(priority){
            case 'low':
                str += '; Priority=Low';
                break;
            case 'medium':
                str += '; Priority=Medium';
                break;
            case 'high':
                str += '; Priority=High';
                break;
            default:
                throw new TypeError('option priority is invalid');
        }
    }
    if (opt.sameSite) {
        var sameSite = typeof opt.sameSite === 'string' ? opt.sameSite.toLowerCase() : opt.sameSite;
        switch(sameSite){
            case true:
                str += '; SameSite=Strict';
                break;
            case 'lax':
                str += '; SameSite=Lax';
                break;
            case 'strict':
                str += '; SameSite=Strict';
                break;
            case 'none':
                str += '; SameSite=None';
                break;
            default:
                throw new TypeError('option sameSite is invalid');
        }
    }
    return str;
}
/**
 * URL-decode string value. Optimized to skip native call when no %.
 *
 * @param {string} str
 * @returns {string}
 */ function decode(str) {
    return str.indexOf('%') !== -1 ? decodeURIComponent(str) : str;
}
/**
 * URL-encode value.
 *
 * @param {string} val
 * @returns {string}
 */ function encode(val) {
    return encodeURIComponent(val);
}
/**
 * Determine if value is a Date.
 *
 * @param {*} val
 * @private
 */ function isDate(val) {
    return __toString.call(val) === '[object Date]' || val instanceof Date;
}
/**
 * Try decoding a string using a decoding function.
 *
 * @param {string} str
 * @param {function} decode
 * @private
 */ function tryDecode(str, decode) {
    try {
        return decode(str);
    } catch (e) {
        return str;
    }
}

}.call(this) }),
"[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/dist/preact.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Component": ()=>d,
    "Fragment": ()=>p,
    "cloneElement": ()=>q,
    "createContext": ()=>B,
    "createElement": ()=>h,
    "createRef": ()=>y,
    "h": ()=>h,
    "hydrate": ()=>S,
    "isValidElement": ()=>i,
    "options": ()=>l,
    "render": ()=>P,
    "toChildArray": ()=>x
});
var n, l, u, i, t, o, r, f = {}, e = [], c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
function s(n, l) {
    for(var u in l)n[u] = l[u];
    return n;
}
function a(n) {
    var l = n.parentNode;
    l && l.removeChild(n);
}
function h(l, u, i) {
    var t, o, r, f = {};
    for(r in u)"key" == r ? t = u[r] : "ref" == r ? o = u[r] : f[r] = u[r];
    if (arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : i), "function" == typeof l && null != l.defaultProps) for(r in l.defaultProps)void 0 === f[r] && (f[r] = l.defaultProps[r]);
    return v(l, f, t, o, null);
}
function v(n, i, t, o, r) {
    var f = {
        type: n,
        props: i,
        key: t,
        ref: o,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        __h: null,
        constructor: void 0,
        __v: null == r ? ++u : r
    };
    return null == r && null != l.vnode && l.vnode(f), f;
}
function y() {
    return {
        current: null
    };
}
function p(n) {
    return n.children;
}
function d(n, l) {
    this.props = n, this.context = l;
}
function _(n, l) {
    if (null == l) return n.__ ? _(n.__, n.__.__k.indexOf(n) + 1) : null;
    for(var u; l < n.__k.length; l++)if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? _(n) : null;
}
function k(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
        for(n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++)if (null != (u = n.__k[l]) && null != u.__e) {
            n.__e = n.__c.base = u.__e;
            break;
        }
        return k(n);
    }
}
function b(n) {
    (!n.__d && (n.__d = !0) && t.push(n) && !g.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || setTimeout)(g);
}
function g() {
    for(var n; g.__r = t.length;)n = t.sort(function(n, l) {
        return n.__v.__b - l.__v.__b;
    }), t = [], n.some(function(n) {
        var l, u, i, t, o, r;
        n.__d && (o = (t = (l = n).__v).__e, (r = l.__P) && (u = [], (i = s({}, t)).__v = t.__v + 1, j(r, t, i, l.__n, void 0 !== r.ownerSVGElement, null != t.__h ? [
            o
        ] : null, u, null == o ? _(t) : o, t.__h), z(u, t), t.__e != o && k(t)));
    });
}
function w(n, l, u, i, t, o, r, c, s, a) {
    var h, y, d, k, b, g, w, x = i && i.__k || e, C = x.length;
    for(u.__k = [], h = 0; h < l.length; h++)if (null != (k = u.__k[h] = null == (k = l[h]) || "boolean" == typeof k ? null : "string" == typeof k || "number" == typeof k || "bigint" == typeof k ? v(null, k, null, null, k) : Array.isArray(k) ? v(p, {
        children: k
    }, null, null, null) : k.__b > 0 ? v(k.type, k.props, k.key, k.ref ? k.ref : null, k.__v) : k)) {
        if (k.__ = u, k.__b = u.__b + 1, null === (d = x[h]) || d && k.key == d.key && k.type === d.type) x[h] = void 0;
        else for(y = 0; y < C; y++){
            if ((d = x[y]) && k.key == d.key && k.type === d.type) {
                x[y] = void 0;
                break;
            }
            d = null;
        }
        j(n, k, d = d || f, t, o, r, c, s, a), b = k.__e, (y = k.ref) && d.ref != y && (w || (w = []), d.ref && w.push(d.ref, null, k), w.push(y, k.__c || b, k)), null != b ? (null == g && (g = b), "function" == typeof k.type && k.__k === d.__k ? k.__d = s = m(k, s, n) : s = A(n, k, d, x, b, s), "function" == typeof u.type && (u.__d = s)) : s && d.__e == s && s.parentNode != n && (s = _(d));
    }
    for(u.__e = g, h = C; h--;)null != x[h] && N(x[h], x[h]);
    if (w) for(h = 0; h < w.length; h++)M(w[h], w[++h], w[++h]);
}
function m(n, l, u) {
    for(var i, t = n.__k, o = 0; t && o < t.length; o++)(i = t[o]) && (i.__ = n, l = "function" == typeof i.type ? m(i, l, u) : A(u, i, i, t, i.__e, l));
    return l;
}
function x(n, l) {
    return l = l || [], null == n || "boolean" == typeof n || (Array.isArray(n) ? n.some(function(n) {
        x(n, l);
    }) : l.push(n)), l;
}
function A(n, l, u, i, t, o) {
    var r, f, e;
    if (void 0 !== l.__d) r = l.__d, l.__d = void 0;
    else if (null == u || t != o || null == t.parentNode) n: if (null == o || o.parentNode !== n) n.appendChild(t), r = null;
    else {
        for(f = o, e = 0; (f = f.nextSibling) && e < i.length; e += 1)if (f == t) break n;
        n.insertBefore(t, o), r = o;
    }
    return void 0 !== r ? r : t.nextSibling;
}
function C(n, l, u, i, t) {
    var o;
    for(o in u)"children" === o || "key" === o || o in l || H(n, o, null, u[o], i);
    for(o in l)t && "function" != typeof l[o] || "children" === o || "key" === o || "value" === o || "checked" === o || u[o] === l[o] || H(n, o, l[o], u[o], i);
}
function $(n, l, u) {
    "-" === l[0] ? n.setProperty(l, u) : n[l] = null == u ? "" : "number" != typeof u || c.test(l) ? u : u + "px";
}
function H(n, l, u, i, t) {
    var o;
    n: if ("style" === l) if ("string" == typeof u) n.style.cssText = u;
    else {
        if ("string" == typeof i && (n.style.cssText = i = ""), i) for(l in i)u && l in u || $(n.style, l, "");
        if (u) for(l in u)i && u[l] === i[l] || $(n.style, l, u[l]);
    }
    else if ("o" === l[0] && "n" === l[1]) o = l !== (l = l.replace(/Capture$/, "")), l = l.toLowerCase() in n ? l.toLowerCase().slice(2) : l.slice(2), n.l || (n.l = {}), n.l[l + o] = u, u ? i || n.addEventListener(l, o ? T : I, o) : n.removeEventListener(l, o ? T : I, o);
    else if ("dangerouslySetInnerHTML" !== l) {
        if (t) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("href" !== l && "list" !== l && "form" !== l && "tabIndex" !== l && "download" !== l && l in n) try {
            n[l] = null == u ? "" : u;
            break n;
        } catch (n) {}
        "function" == typeof u || (null == u || !1 === u && -1 == l.indexOf("-") ? n.removeAttribute(l) : n.setAttribute(l, u));
    }
}
function I(n) {
    this.l[n.type + !1](l.event ? l.event(n) : n);
}
function T(n) {
    this.l[n.type + !0](l.event ? l.event(n) : n);
}
function j(n, u, i, t, o, r, f, e, c) {
    var a, h, v, y, _, k, b, g, m, x, A, C, $, H, I, T = u.type;
    if (void 0 !== u.constructor) return null;
    null != i.__h && (c = i.__h, e = u.__e = i.__e, u.__h = null, r = [
        e
    ]), (a = l.__b) && a(u);
    try {
        n: if ("function" == typeof T) {
            if (g = u.props, m = (a = T.contextType) && t[a.__c], x = a ? m ? m.props.value : a.__ : t, i.__c ? b = (h = u.__c = i.__c).__ = h.__E : ("prototype" in T && T.prototype.render ? u.__c = h = new T(g, x) : (u.__c = h = new d(g, x), h.constructor = T, h.render = O), m && m.sub(h), h.props = g, h.state || (h.state = {}), h.context = x, h.__n = t, v = h.__d = !0, h.__h = [], h._sb = []), null == h.__s && (h.__s = h.state), null != T.getDerivedStateFromProps && (h.__s == h.state && (h.__s = s({}, h.__s)), s(h.__s, T.getDerivedStateFromProps(g, h.__s))), y = h.props, _ = h.state, v) null == T.getDerivedStateFromProps && null != h.componentWillMount && h.componentWillMount(), null != h.componentDidMount && h.__h.push(h.componentDidMount);
            else {
                if (null == T.getDerivedStateFromProps && g !== y && null != h.componentWillReceiveProps && h.componentWillReceiveProps(g, x), !h.__e && null != h.shouldComponentUpdate && !1 === h.shouldComponentUpdate(g, h.__s, x) || u.__v === i.__v) {
                    for(h.props = g, h.state = h.__s, u.__v !== i.__v && (h.__d = !1), h.__v = u, u.__e = i.__e, u.__k = i.__k, u.__k.forEach(function(n) {
                        n && (n.__ = u);
                    }), A = 0; A < h._sb.length; A++)h.__h.push(h._sb[A]);
                    h._sb = [], h.__h.length && f.push(h);
                    break n;
                }
                null != h.componentWillUpdate && h.componentWillUpdate(g, h.__s, x), null != h.componentDidUpdate && h.__h.push(function() {
                    h.componentDidUpdate(y, _, k);
                });
            }
            if (h.context = x, h.props = g, h.__v = u, h.__P = n, C = l.__r, $ = 0, "prototype" in T && T.prototype.render) {
                for(h.state = h.__s, h.__d = !1, C && C(u), a = h.render(h.props, h.state, h.context), H = 0; H < h._sb.length; H++)h.__h.push(h._sb[H]);
                h._sb = [];
            } else do {
                h.__d = !1, C && C(u), a = h.render(h.props, h.state, h.context), h.state = h.__s;
            }while (h.__d && ++$ < 25)
            h.state = h.__s, null != h.getChildContext && (t = s(s({}, t), h.getChildContext())), v || null == h.getSnapshotBeforeUpdate || (k = h.getSnapshotBeforeUpdate(y, _)), I = null != a && a.type === p && null == a.key ? a.props.children : a, w(n, Array.isArray(I) ? I : [
                I
            ], u, i, t, o, r, f, e, c), h.base = u.__e, u.__h = null, h.__h.length && f.push(h), b && (h.__E = h.__ = null), h.__e = !1;
        } else null == r && u.__v === i.__v ? (u.__k = i.__k, u.__e = i.__e) : u.__e = L(i.__e, u, i, t, o, r, f, c);
        (a = l.diffed) && a(u);
    } catch (n) {
        u.__v = null, (c || null != r) && (u.__e = e, u.__h = !!c, r[r.indexOf(e)] = null), l.__e(n, u, i);
    }
}
function z(n, u) {
    l.__c && l.__c(u, n), n.some(function(u) {
        try {
            n = u.__h, u.__h = [], n.some(function(n) {
                n.call(u);
            });
        } catch (n) {
            l.__e(n, u.__v);
        }
    });
}
function L(l, u, i, t, o, r, e, c) {
    var s, h, v, y = i.props, p = u.props, d = u.type, k = 0;
    if ("svg" === d && (o = !0), null != r) {
        for(; k < r.length; k++)if ((s = r[k]) && "setAttribute" in s == !!d && (d ? s.localName === d : 3 === s.nodeType)) {
            l = s, r[k] = null;
            break;
        }
    }
    if (null == l) {
        if (null === d) return document.createTextNode(p);
        l = o ? document.createElementNS("http://www.w3.org/2000/svg", d) : document.createElement(d, p.is && p), r = null, c = !1;
    }
    if (null === d) y === p || c && l.data === p || (l.data = p);
    else {
        if (r = r && n.call(l.childNodes), h = (y = i.props || f).dangerouslySetInnerHTML, v = p.dangerouslySetInnerHTML, !c) {
            if (null != r) for(y = {}, k = 0; k < l.attributes.length; k++)y[l.attributes[k].name] = l.attributes[k].value;
            (v || h) && (v && (h && v.__html == h.__html || v.__html === l.innerHTML) || (l.innerHTML = v && v.__html || ""));
        }
        if (C(l, p, y, o, c), v) u.__k = [];
        else if (k = u.props.children, w(l, Array.isArray(k) ? k : [
            k
        ], u, i, t, o && "foreignObject" !== d, r, e, r ? r[0] : i.__k && _(i, 0), c), null != r) for(k = r.length; k--;)null != r[k] && a(r[k]);
        c || ("value" in p && void 0 !== (k = p.value) && (k !== l.value || "progress" === d && !k || "option" === d && k !== y.value) && H(l, "value", k, y.value, !1), "checked" in p && void 0 !== (k = p.checked) && k !== l.checked && H(l, "checked", k, y.checked, !1));
    }
    return l;
}
function M(n, u, i) {
    try {
        "function" == typeof n ? n(u) : n.current = u;
    } catch (n) {
        l.__e(n, i);
    }
}
function N(n, u, i) {
    var t, o;
    if (l.unmount && l.unmount(n), (t = n.ref) && (t.current && t.current !== n.__e || M(t, null, u)), null != (t = n.__c)) {
        if (t.componentWillUnmount) try {
            t.componentWillUnmount();
        } catch (n) {
            l.__e(n, u);
        }
        t.base = t.__P = null, n.__c = void 0;
    }
    if (t = n.__k) for(o = 0; o < t.length; o++)t[o] && N(t[o], u, i || "function" != typeof n.type);
    i || null == n.__e || a(n.__e), n.__ = n.__e = n.__d = void 0;
}
function O(n, l, u) {
    return this.constructor(n, u);
}
function P(u, i, t) {
    var o, r, e;
    l.__ && l.__(u, i), r = (o = "function" == typeof t) ? null : t && t.__k || i.__k, e = [], j(i, u = (!o && t || i).__k = h(p, null, [
        u
    ]), r || f, f, void 0 !== i.ownerSVGElement, !o && t ? [
        t
    ] : r ? null : i.firstChild ? n.call(i.childNodes) : null, e, !o && t ? t : r ? r.__e : i.firstChild, o), z(e, u);
}
function S(n, l) {
    P(n, l, S);
}
function q(l, u, i) {
    var t, o, r, f = s({}, l.props);
    for(r in u)"key" == r ? t = u[r] : "ref" == r ? o = u[r] : f[r] = u[r];
    return arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : i), v(l.type, f, t || l.key, o || l.ref, null);
}
function B(n, l) {
    var u = {
        __c: l = "__cC" + r++,
        __: n,
        Consumer: function(n, l) {
            return n.children(l);
        },
        Provider: function(n) {
            var u, i;
            return this.getChildContext || (u = [], (i = {})[l] = this, this.getChildContext = function() {
                return i;
            }, this.shouldComponentUpdate = function(n) {
                this.props.value !== n.value && u.some(b);
            }, this.sub = function(n) {
                u.push(n);
                var l = n.componentWillUnmount;
                n.componentWillUnmount = function() {
                    u.splice(u.indexOf(n), 1), l && l.call(n);
                };
            }), n.children;
        }
    };
    return u.Provider.__ = u.Consumer.contextType = u;
}
n = e.slice, l = {
    __e: function(n, l, u, i) {
        for(var t, o, r; l = l.__;)if ((t = l.__c) && !t.__) try {
            if ((o = t.constructor) && null != o.getDerivedStateFromError && (t.setState(o.getDerivedStateFromError(n)), r = t.__d), null != t.componentDidCatch && (t.componentDidCatch(n, i || {}), r = t.__d), r) return t.__E = t;
        } catch (l) {
            n = l;
        }
        throw n;
    }
}, u = 0, i = function(n) {
    return null != n && void 0 === n.constructor;
}, d.prototype.setState = function(n, l) {
    var u;
    u = null != this.__s && this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n && (n = n(s({}, u), this.props)), n && s(u, n), null != n && this.__v && (l && this._sb.push(l), b(this));
}, d.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), b(this));
}, d.prototype.render = p, t = [], g.__r = 0, r = 0;
;
 //# sourceMappingURL=preact.module.js.map

})()),
"[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "jsx": ()=>o,
    "jsxDEV": ()=>o,
    "jsxs": ()=>o
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/dist/preact.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
var _ = 0;
function o(o, e, n, t, f) {
    var l, s, u = {};
    for(s in e)"ref" == s ? l = e[s] : u[s] = e[s];
    var a = {
        type: o,
        props: u,
        key: n,
        ref: l,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        __h: null,
        constructor: void 0,
        __v: --_,
        __source: f,
        __self: t
    };
    if ("function" == typeof o && (l = o.defaultProps)) for(s in l)void 0 === u[s] && (u[s] = l[s]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].vnode && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].vnode(a), a;
}
;
 //# sourceMappingURL=jsxRuntime.module.js.map

})()),
"[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/dist/preact.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$jsx$2d$runtime$2f$dist$2f$jsxRuntime$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/preact-render-to-string@5.2.3_preact@10.11.3/node_modules/preact-render-to-string/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__,
    "render": ()=>k,
    "renderToStaticMarkup": ()=>k,
    "renderToString": ()=>k,
    "shallowRender": ()=>b
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/preact@10.11.3/node_modules/preact/dist/preact.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var r = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|^--/i, n = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)$/, o = /[\s\n\\/='"\0<>]/, i = /^xlink:?./, a = /["&<]/;
function l(e) {
    if (!1 === a.test(e += "")) return e;
    for(var t = 0, r = 0, n = "", o = ""; r < e.length; r++){
        switch(e.charCodeAt(r)){
            case 34:
                o = "&quot;";
                break;
            case 38:
                o = "&amp;";
                break;
            case 60:
                o = "&lt;";
                break;
            default:
                continue;
        }
        r !== t && (n += e.slice(t, r)), n += o, t = r + 1;
    }
    return r !== t && (n += e.slice(t, r)), n;
}
var s = function(e, t) {
    return String(e).replace(/(\n+)/g, "$1" + (t || "\t"));
}, f = function(e, t, r) {
    return String(e).length > (t || 40) || !r && -1 !== String(e).indexOf("\n") || -1 !== String(e).indexOf("<");
}, c = {}, u = /([A-Z])/g;
function p(e) {
    var t = "";
    for(var n in e){
        var o = e[n];
        null != o && "" !== o && (t && (t += " "), t += "-" == n[0] ? n : c[n] || (c[n] = n.replace(u, "-$1").toLowerCase()), t = "number" == typeof o && !1 === r.test(n) ? t + ": " + o + "px;" : t + ": " + o + ";");
    }
    return t || void 0;
}
function _(e, t) {
    return Array.isArray(t) ? t.reduce(_, e) : null != t && !1 !== t && e.push(t), e;
}
function d() {
    this.__d = !0;
}
function v(e, t) {
    return {
        __v: e,
        context: t,
        props: e.props,
        setState: d,
        forceUpdate: d,
        __d: !0,
        __h: []
    };
}
function h(e, t) {
    var r = e.contextType, n = r && t[r.__c];
    return null != r ? n ? n.props.value : r.__ : t;
}
var g = [];
function y(r, a, c, u, d, m) {
    if (null == r || "boolean" == typeof r) return "";
    if ("object" != typeof r) return l(r);
    var b = c.pretty, x = b && "string" == typeof b ? b : "\t";
    if (Array.isArray(r)) {
        for(var k = "", S = 0; S < r.length; S++)b && S > 0 && (k += "\n"), k += y(r[S], a, c, u, d, m);
        return k;
    }
    var w, C = r.type, O = r.props, j = !1;
    if ("function" == typeof C) {
        if (j = !0, !c.shallow || !u && !1 !== c.renderRootComponent) {
            if (C === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"]) {
                var A = [];
                return _(A, r.props.children), y(A, a, c, !1 !== c.shallowHighOrder, d, m);
            }
            var F, H = r.__c = v(r, a);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__b && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__b(r);
            var M = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__r;
            if (C.prototype && "function" == typeof C.prototype.render) {
                var L = h(C, a);
                (H = r.__c = new C(O, L)).__v = r, H._dirty = H.__d = !0, H.props = O, null == H.state && (H.state = {}), null == H._nextState && null == H.__s && (H._nextState = H.__s = H.state), H.context = L, C.getDerivedStateFromProps ? H.state = Object.assign({}, H.state, C.getDerivedStateFromProps(H.props, H.state)) : H.componentWillMount && (H.componentWillMount(), H.state = H._nextState !== H.state ? H._nextState : H.__s !== H.state ? H.__s : H.state), M && M(r), F = H.render(H.props, H.state, H.context);
            } else for(var T = h(C, a), E = 0; H.__d && E++ < 25;)H.__d = !1, M && M(r), F = C.call(r.__c, O, T);
            return H.getChildContext && (a = Object.assign({}, a, H.getChildContext())), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed(r), y(F, a, c, !1 !== c.shallowHighOrder, d, m);
        }
        C = (w = C).displayName || w !== Function && w.name || function(e) {
            var t = (Function.prototype.toString.call(e).match(/^\s*function\s+([^( ]+)/) || "")[1];
            if (!t) {
                for(var r = -1, n = g.length; n--;)if (g[n] === e) {
                    r = n;
                    break;
                }
                r < 0 && (r = g.push(e) - 1), t = "UnnamedComponent" + r;
            }
            return t;
        }(w);
    }
    var $, D, N = "<" + C;
    if (O) {
        var P = Object.keys(O);
        c && !0 === c.sortAttributes && P.sort();
        for(var W = 0; W < P.length; W++){
            var I = P[W], R = O[I];
            if ("children" !== I) {
                if (!o.test(I) && (c && c.allAttributes || "key" !== I && "ref" !== I && "__self" !== I && "__source" !== I)) {
                    if ("defaultValue" === I) I = "value";
                    else if ("defaultChecked" === I) I = "checked";
                    else if ("defaultSelected" === I) I = "selected";
                    else if ("className" === I) {
                        if (void 0 !== O.class) continue;
                        I = "class";
                    } else d && i.test(I) && (I = I.toLowerCase().replace(/^xlink:?/, "xlink:"));
                    if ("htmlFor" === I) {
                        if (O.for) continue;
                        I = "for";
                    }
                    "style" === I && R && "object" == typeof R && (R = p(R)), "a" === I[0] && "r" === I[1] && "boolean" == typeof R && (R = String(R));
                    var U = c.attributeHook && c.attributeHook(I, R, a, c, j);
                    if (U || "" === U) N += U;
                    else if ("dangerouslySetInnerHTML" === I) D = R && R.__html;
                    else if ("textarea" === C && "value" === I) $ = R;
                    else if ((R || 0 === R || "" === R) && "function" != typeof R) {
                        if (!(!0 !== R && "" !== R || (R = I, c && c.xml))) {
                            N = N + " " + I;
                            continue;
                        }
                        if ("value" === I) {
                            if ("select" === C) {
                                m = R;
                                continue;
                            }
                            "option" === C && m == R && void 0 === O.selected && (N += " selected");
                        }
                        N = N + " " + I + '="' + l(R) + '"';
                    }
                }
            } else $ = R;
        }
    }
    if (b) {
        var V = N.replace(/\n\s*/, " ");
        V === N || ~V.indexOf("\n") ? b && ~N.indexOf("\n") && (N += "\n") : N = V;
    }
    if (N += ">", o.test(C)) throw new Error(C + " is not a valid HTML tag name in " + N);
    var q, z = n.test(C) || c.voidElements && c.voidElements.test(C), Z = [];
    if (D) b && f(D) && (D = "\n" + x + s(D, x)), N += D;
    else if (null != $ && _(q = [], $).length) {
        for(var B = b && ~N.indexOf("\n"), G = !1, J = 0; J < q.length; J++){
            var K = q[J];
            if (null != K && !1 !== K) {
                var Q = y(K, a, c, !0, "svg" === C || "foreignObject" !== C && d, m);
                if (b && !B && f(Q) && (B = !0), Q) if (b) {
                    var X = Q.length > 0 && "<" != Q[0];
                    G && X ? Z[Z.length - 1] += Q : Z.push(Q), G = X;
                } else Z.push(Q);
            }
        }
        if (b && B) for(var Y = Z.length; Y--;)Z[Y] = "\n" + x + s(Z[Y], x);
    }
    if (Z.length || D) N += Z.join("");
    else if (c && c.xml) return N.substring(0, N.length - 1) + " />";
    return !z || q || D ? (b && ~N.indexOf("\n") && (N += "\n"), N = N + "</" + C + ">") : N = N.replace(/>$/, " />"), N;
}
var m = {
    shallow: !0
};
k.render = k;
var b = function(e, t) {
    return k(e, t, m);
}, x = [];
function k(e, r, n) {
    r = r || {};
    var o, i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__s;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__s = !0, o = n && (n.pretty || n.voidElements || n.sortAttributes || n.shallow || n.allAttributes || n.xml || n.attributeHook) ? y(e, r, n) : j(e, r, !1, void 0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__c && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__c(e, x), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__s = i, x.length = 0, o;
}
function S(e, t) {
    return "className" === e ? "class" : "htmlFor" === e ? "for" : "defaultValue" === e ? "value" : "defaultChecked" === e ? "checked" : "defaultSelected" === e ? "selected" : t && i.test(e) ? e.toLowerCase().replace(/^xlink:?/, "xlink:") : e;
}
function w(e, t) {
    return "style" === e && null != t && "object" == typeof t ? p(t) : "a" === e[0] && "r" === e[1] && "boolean" == typeof t ? String(t) : t;
}
var C = Array.isArray, O = Object.assign;
function j(r, i, a, s) {
    if (null == r || !0 === r || !1 === r || "" === r) return "";
    if ("object" != typeof r) return l(r);
    if (C(r)) {
        for(var f = "", c = 0; c < r.length; c++)f += j(r[c], i, a, s);
        return f;
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__b && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__b(r);
    var u = r.type, p = r.props;
    if ("function" == typeof u) {
        if (u === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"]) return j(r.props.children, i, a, s);
        var _;
        _ = u.prototype && "function" == typeof u.prototype.render ? function(e, r) {
            var n = e.type, o = h(n, r), i = new n(e.props, o);
            e.__c = i, i.__v = e, i.__d = !0, i.props = e.props, null == i.state && (i.state = {}), null == i.__s && (i.__s = i.state), i.context = o, n.getDerivedStateFromProps ? i.state = O({}, i.state, n.getDerivedStateFromProps(i.props, i.state)) : i.componentWillMount && (i.componentWillMount(), i.state = i.__s !== i.state ? i.__s : i.state);
            var a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__r;
            return a && a(e), i.render(i.props, i.state, i.context);
        }(r, i) : function(e, r) {
            var n, o = v(e, r), i = h(e.type, r);
            e.__c = o;
            for(var a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].__r, l = 0; o.__d && l++ < 25;)o.__d = !1, a && a(e), n = e.type.call(o, e.props, i);
            return n;
        }(r, i);
        var d = r.__c;
        d.getChildContext && (i = O({}, i, d.getChildContext()));
        var g = j(_, i, a, s);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed(r), g;
    }
    var y, m, b = "<";
    if (b += u, p) for(var x in y = p.children, p){
        var k = p[x];
        if (!("key" === x || "ref" === x || "__self" === x || "__source" === x || "children" === x || "className" === x && "class" in p || "htmlFor" === x && "for" in p || o.test(x))) {
            if (k = w(x = S(x, a), k), "dangerouslySetInnerHTML" === x) m = k && k.__html;
            else if ("textarea" === u && "value" === x) y = k;
            else if ((k || 0 === k || "" === k) && "function" != typeof k) {
                if (!0 === k || "" === k) {
                    k = x, b = b + " " + x;
                    continue;
                }
                if ("value" === x) {
                    if ("select" === u) {
                        s = k;
                        continue;
                    }
                    "option" !== u || s != k || "selected" in p || (b += " selected");
                }
                b = b + " " + x + '="' + l(k) + '"';
            }
        }
    }
    var A = b;
    if (b += ">", o.test(u)) throw new Error(u + " is not a valid HTML tag name in " + b);
    var F = "", H = !1;
    if (m) F += m, H = !0;
    else if ("string" == typeof y) F += l(y), H = !0;
    else if (C(y)) for(var M = 0; M < y.length; M++){
        var L = y[M];
        if (null != L && !1 !== L) {
            var T = j(L, i, "svg" === u || "foreignObject" !== u && a, s);
            T && (F += T, H = !0);
        }
    }
    else if (null != y && !1 !== y && !0 !== y) {
        var E = j(y, i, "svg" === u || "foreignObject" !== u && a, s);
        E && (F += E, H = !0);
    }
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$preact$40$10$2e$11$2e$3$2f$node_modules$2f$preact$2f$dist$2f$preact$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["options"].diffed(r), H) b += F;
    else if (n.test(u)) return A + " />";
    return b + "</" + u + ">";
}
k.shallowRender = b;
const __TURBOPACK__default__export__ = k;
;
 //# sourceMappingURL=index.module.js.map

})()),
"[project]/node_modules/.pnpm/oauth4webapi@2.11.1/node_modules/oauth4webapi/build/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "OperationProcessingError": ()=>OperationProcessingError,
    "UnsupportedOperationError": ()=>UnsupportedOperationError,
    "authorizationCodeGrantRequest": ()=>authorizationCodeGrantRequest,
    "calculatePKCECodeChallenge": ()=>calculatePKCECodeChallenge,
    "clientCredentialsGrantRequest": ()=>clientCredentialsGrantRequest,
    "clockSkew": ()=>clockSkew,
    "clockTolerance": ()=>clockTolerance,
    "customFetch": ()=>customFetch,
    "deviceAuthorizationRequest": ()=>deviceAuthorizationRequest,
    "deviceCodeGrantRequest": ()=>deviceCodeGrantRequest,
    "discoveryRequest": ()=>discoveryRequest,
    "expectNoNonce": ()=>expectNoNonce,
    "expectNoState": ()=>expectNoState,
    "experimentalCustomFetch": ()=>experimentalCustomFetch,
    "experimentalUseMtlsAlias": ()=>experimentalUseMtlsAlias,
    "experimental_customFetch": ()=>experimental_customFetch,
    "experimental_jwksCache": ()=>experimental_jwksCache,
    "experimental_useMtlsAlias": ()=>experimental_useMtlsAlias,
    "experimental_validateDetachedSignatureResponse": ()=>experimental_validateDetachedSignatureResponse,
    "experimental_validateJwtAccessToken": ()=>experimental_validateJwtAccessToken,
    "generateKeyPair": ()=>generateKeyPair,
    "generateRandomCodeVerifier": ()=>generateRandomCodeVerifier,
    "generateRandomNonce": ()=>generateRandomNonce,
    "generateRandomState": ()=>generateRandomState,
    "getValidatedIdTokenClaims": ()=>getValidatedIdTokenClaims,
    "introspectionRequest": ()=>introspectionRequest,
    "isOAuth2Error": ()=>isOAuth2Error,
    "issueRequestObject": ()=>issueRequestObject,
    "parseWwwAuthenticateChallenges": ()=>parseWwwAuthenticateChallenges,
    "processAuthorizationCodeOAuth2Response": ()=>processAuthorizationCodeOAuth2Response,
    "processAuthorizationCodeOpenIDResponse": ()=>processAuthorizationCodeOpenIDResponse,
    "processClientCredentialsResponse": ()=>processClientCredentialsResponse,
    "processDeviceAuthorizationResponse": ()=>processDeviceAuthorizationResponse,
    "processDeviceCodeResponse": ()=>processDeviceCodeResponse,
    "processDiscoveryResponse": ()=>processDiscoveryResponse,
    "processIntrospectionResponse": ()=>processIntrospectionResponse,
    "processPushedAuthorizationResponse": ()=>processPushedAuthorizationResponse,
    "processRefreshTokenResponse": ()=>processRefreshTokenResponse,
    "processRevocationResponse": ()=>processRevocationResponse,
    "processUserInfoResponse": ()=>processUserInfoResponse,
    "protectedResourceRequest": ()=>protectedResourceRequest,
    "pushedAuthorizationRequest": ()=>pushedAuthorizationRequest,
    "refreshTokenGrantRequest": ()=>refreshTokenGrantRequest,
    "revocationRequest": ()=>revocationRequest,
    "skipAuthTimeCheck": ()=>skipAuthTimeCheck,
    "skipStateCheck": ()=>skipStateCheck,
    "skipSubjectCheck": ()=>skipSubjectCheck,
    "useMtlsAlias": ()=>useMtlsAlias,
    "userInfoRequest": ()=>userInfoRequest,
    "validateAuthResponse": ()=>validateAuthResponse,
    "validateDetachedSignatureResponse": ()=>validateDetachedSignatureResponse,
    "validateJwtAccessToken": ()=>validateJwtAccessToken,
    "validateJwtAuthResponse": ()=>validateJwtAuthResponse
});
let USER_AGENT;
if (typeof navigator === 'undefined' || !navigator.userAgent?.startsWith?.('Mozilla/5.0 ')) {
    const NAME = 'oauth4webapi';
    const VERSION = 'v2.11.1';
    USER_AGENT = `${NAME}/${VERSION}`;
}
function looseInstanceOf(input, expected) {
    if (input == null) {
        return false;
    }
    try {
        return input instanceof expected || Object.getPrototypeOf(input)[Symbol.toStringTag] === expected.prototype[Symbol.toStringTag];
    } catch  {
        return false;
    }
}
const clockSkew = Symbol();
const clockTolerance = Symbol();
const customFetch = Symbol();
const experimental_jwksCache = Symbol();
const useMtlsAlias = Symbol();
const encoder = new TextEncoder();
const decoder = new TextDecoder();
function buf(input) {
    if (typeof input === 'string') {
        return encoder.encode(input);
    }
    return decoder.decode(input);
}
const CHUNK_SIZE = 0x8000;
function encodeBase64Url(input) {
    if (input instanceof ArrayBuffer) {
        input = new Uint8Array(input);
    }
    const arr = [];
    for(let i = 0; i < input.byteLength; i += CHUNK_SIZE){
        arr.push(String.fromCharCode.apply(null, input.subarray(i, i + CHUNK_SIZE)));
    }
    return btoa(arr.join('')).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function decodeBase64Url(input) {
    try {
        const binary = atob(input.replace(/-/g, '+').replace(/_/g, '/').replace(/\s/g, ''));
        const bytes = new Uint8Array(binary.length);
        for(let i = 0; i < binary.length; i++){
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    } catch (cause) {
        throw new OPE('The input to be decoded is not correctly encoded.', {
            cause
        });
    }
}
function b64u(input) {
    if (typeof input === 'string') {
        return decodeBase64Url(input);
    }
    return encodeBase64Url(input);
}
class LRU {
    constructor(maxSize){
        this.cache = new Map();
        this._cache = new Map();
        this.maxSize = maxSize;
    }
    get(key) {
        let v = this.cache.get(key);
        if (v) {
            return v;
        }
        if (v = this._cache.get(key)) {
            this.update(key, v);
            return v;
        }
        return undefined;
    }
    has(key) {
        return this.cache.has(key) || this._cache.has(key);
    }
    set(key, value) {
        if (this.cache.has(key)) {
            this.cache.set(key, value);
        } else {
            this.update(key, value);
        }
        return this;
    }
    delete(key) {
        if (this.cache.has(key)) {
            return this.cache.delete(key);
        }
        if (this._cache.has(key)) {
            return this._cache.delete(key);
        }
        return false;
    }
    update(key, value) {
        this.cache.set(key, value);
        if (this.cache.size >= this.maxSize) {
            this._cache = this.cache;
            this.cache = new Map();
        }
    }
}
class UnsupportedOperationError extends Error {
    constructor(message){
        super(message ?? 'operation not supported');
        this.name = this.constructor.name;
        Error.captureStackTrace?.(this, this.constructor);
    }
}
class OperationProcessingError extends Error {
    constructor(message, options){
        super(message, options);
        this.name = this.constructor.name;
        Error.captureStackTrace?.(this, this.constructor);
    }
}
const OPE = OperationProcessingError;
const dpopNonces = new LRU(100);
function isCryptoKey(key) {
    return key instanceof CryptoKey;
}
function isPrivateKey(key) {
    return isCryptoKey(key) && key.type === 'private';
}
function isPublicKey(key) {
    return isCryptoKey(key) && key.type === 'public';
}
const SUPPORTED_JWS_ALGS = [
    'PS256',
    'ES256',
    'RS256',
    'PS384',
    'ES384',
    'RS384',
    'PS512',
    'ES512',
    'RS512',
    'EdDSA'
];
function processDpopNonce(response) {
    try {
        const nonce = response.headers.get('dpop-nonce');
        if (nonce) {
            dpopNonces.set(new URL(response.url).origin, nonce);
        }
    } catch  {}
    return response;
}
function normalizeTyp(value) {
    return value.toLowerCase().replace(/^application\//, '');
}
function isJsonObject(input) {
    if (input === null || typeof input !== 'object' || Array.isArray(input)) {
        return false;
    }
    return true;
}
function prepareHeaders(input) {
    if (looseInstanceOf(input, Headers)) {
        input = Object.fromEntries(input.entries());
    }
    const headers = new Headers(input);
    if (USER_AGENT && !headers.has('user-agent')) {
        headers.set('user-agent', USER_AGENT);
    }
    if (headers.has('authorization')) {
        throw new TypeError('"options.headers" must not include the "authorization" header name');
    }
    if (headers.has('dpop')) {
        throw new TypeError('"options.headers" must not include the "dpop" header name');
    }
    return headers;
}
function signal(value) {
    if (typeof value === 'function') {
        value = value();
    }
    if (!(value instanceof AbortSignal)) {
        throw new TypeError('"options.signal" must return or be an instance of AbortSignal');
    }
    return value;
}
async function discoveryRequest(issuerIdentifier, options) {
    if (!(issuerIdentifier instanceof URL)) {
        throw new TypeError('"issuerIdentifier" must be an instance of URL');
    }
    if (issuerIdentifier.protocol !== 'https:' && issuerIdentifier.protocol !== 'http:') {
        throw new TypeError('"issuer.protocol" must be "https:" or "http:"');
    }
    const url = new URL(issuerIdentifier.href);
    switch(options?.algorithm){
        case undefined:
        case 'oidc':
            url.pathname = `${url.pathname}/.well-known/openid-configuration`.replace('//', '/');
            break;
        case 'oauth2':
            if (url.pathname === '/') {
                url.pathname = '.well-known/oauth-authorization-server';
            } else {
                url.pathname = `.well-known/oauth-authorization-server/${url.pathname}`.replace('//', '/');
            }
            break;
        default:
            throw new TypeError('"options.algorithm" must be "oidc" (default), or "oauth2"');
    }
    const headers = prepareHeaders(options?.headers);
    headers.set('accept', 'application/json');
    return (options?.[customFetch] || fetch)(url.href, {
        headers: Object.fromEntries(headers.entries()),
        method: 'GET',
        redirect: 'manual',
        signal: options?.signal ? signal(options.signal) : null
    }).then(processDpopNonce);
}
function validateString(input) {
    return typeof input === 'string' && input.length !== 0;
}
async function processDiscoveryResponse(expectedIssuerIdentifier, response) {
    if (!(expectedIssuerIdentifier instanceof URL)) {
        throw new TypeError('"expectedIssuer" must be an instance of URL');
    }
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        throw new OPE('"response" is not a conform Authorization Server Metadata response');
    }
    assertReadableResponse(response);
    let json;
    try {
        json = await response.json();
    } catch (cause) {
        throw new OPE('failed to parse "response" body as JSON', {
            cause
        });
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!validateString(json.issuer)) {
        throw new OPE('"response" body "issuer" property must be a non-empty string');
    }
    if (new URL(json.issuer).href !== expectedIssuerIdentifier.href) {
        throw new OPE('"response" body "issuer" does not match "expectedIssuer"');
    }
    return json;
}
function randomBytes() {
    return b64u(crypto.getRandomValues(new Uint8Array(32)));
}
function generateRandomCodeVerifier() {
    return randomBytes();
}
function generateRandomState() {
    return randomBytes();
}
function generateRandomNonce() {
    return randomBytes();
}
async function calculatePKCECodeChallenge(codeVerifier) {
    if (!validateString(codeVerifier)) {
        throw new TypeError('"codeVerifier" must be a non-empty string');
    }
    return b64u(await crypto.subtle.digest('SHA-256', buf(codeVerifier)));
}
function getKeyAndKid(input) {
    if (input instanceof CryptoKey) {
        return {
            key: input
        };
    }
    if (!(input?.key instanceof CryptoKey)) {
        return {};
    }
    if (input.kid !== undefined && !validateString(input.kid)) {
        throw new TypeError('"kid" must be a non-empty string');
    }
    return {
        key: input.key,
        kid: input.kid
    };
}
function formUrlEncode(token) {
    return encodeURIComponent(token).replace(/%20/g, '+');
}
function clientSecretBasic(clientId, clientSecret) {
    const username = formUrlEncode(clientId);
    const password = formUrlEncode(clientSecret);
    const credentials = btoa(`${username}:${password}`);
    return `Basic ${credentials}`;
}
function psAlg(key) {
    switch(key.algorithm.hash.name){
        case 'SHA-256':
            return 'PS256';
        case 'SHA-384':
            return 'PS384';
        case 'SHA-512':
            return 'PS512';
        default:
            throw new UnsupportedOperationError('unsupported RsaHashedKeyAlgorithm hash name');
    }
}
function rsAlg(key) {
    switch(key.algorithm.hash.name){
        case 'SHA-256':
            return 'RS256';
        case 'SHA-384':
            return 'RS384';
        case 'SHA-512':
            return 'RS512';
        default:
            throw new UnsupportedOperationError('unsupported RsaHashedKeyAlgorithm hash name');
    }
}
function esAlg(key) {
    switch(key.algorithm.namedCurve){
        case 'P-256':
            return 'ES256';
        case 'P-384':
            return 'ES384';
        case 'P-521':
            return 'ES512';
        default:
            throw new UnsupportedOperationError('unsupported EcKeyAlgorithm namedCurve');
    }
}
function keyToJws(key) {
    switch(key.algorithm.name){
        case 'RSA-PSS':
            return psAlg(key);
        case 'RSASSA-PKCS1-v1_5':
            return rsAlg(key);
        case 'ECDSA':
            return esAlg(key);
        case 'Ed25519':
        case 'Ed448':
            return 'EdDSA';
        default:
            throw new UnsupportedOperationError('unsupported CryptoKey algorithm name');
    }
}
function getClockSkew(client) {
    const skew = client?.[clockSkew];
    return typeof skew === 'number' && Number.isFinite(skew) ? skew : 0;
}
function getClockTolerance(client) {
    const tolerance = client?.[clockTolerance];
    return typeof tolerance === 'number' && Number.isFinite(tolerance) && Math.sign(tolerance) !== -1 ? tolerance : 30;
}
function epochTime() {
    return Math.floor(Date.now() / 1000);
}
function clientAssertion(as, client) {
    const now = epochTime() + getClockSkew(client);
    return {
        jti: randomBytes(),
        aud: [
            as.issuer,
            as.token_endpoint
        ],
        exp: now + 60,
        iat: now,
        nbf: now,
        iss: client.client_id,
        sub: client.client_id
    };
}
async function privateKeyJwt(as, client, key, kid) {
    return jwt({
        alg: keyToJws(key),
        kid
    }, clientAssertion(as, client), key);
}
function assertAs(as) {
    if (typeof as !== 'object' || as === null) {
        throw new TypeError('"as" must be an object');
    }
    if (!validateString(as.issuer)) {
        throw new TypeError('"as.issuer" property must be a non-empty string');
    }
    return true;
}
function assertClient(client) {
    if (typeof client !== 'object' || client === null) {
        throw new TypeError('"client" must be an object');
    }
    if (!validateString(client.client_id)) {
        throw new TypeError('"client.client_id" property must be a non-empty string');
    }
    return true;
}
function assertClientSecret(clientSecret) {
    if (!validateString(clientSecret)) {
        throw new TypeError('"client.client_secret" property must be a non-empty string');
    }
    return clientSecret;
}
function assertNoClientPrivateKey(clientAuthMethod, clientPrivateKey) {
    if (clientPrivateKey !== undefined) {
        throw new TypeError(`"options.clientPrivateKey" property must not be provided when ${clientAuthMethod} client authentication method is used.`);
    }
}
function assertNoClientSecret(clientAuthMethod, clientSecret) {
    if (clientSecret !== undefined) {
        throw new TypeError(`"client.client_secret" property must not be provided when ${clientAuthMethod} client authentication method is used.`);
    }
}
async function clientAuthentication(as, client, body, headers, clientPrivateKey) {
    body.delete('client_secret');
    body.delete('client_assertion_type');
    body.delete('client_assertion');
    switch(client.token_endpoint_auth_method){
        case undefined:
        case 'client_secret_basic':
            {
                assertNoClientPrivateKey('client_secret_basic', clientPrivateKey);
                headers.set('authorization', clientSecretBasic(client.client_id, assertClientSecret(client.client_secret)));
                break;
            }
        case 'client_secret_post':
            {
                assertNoClientPrivateKey('client_secret_post', clientPrivateKey);
                body.set('client_id', client.client_id);
                body.set('client_secret', assertClientSecret(client.client_secret));
                break;
            }
        case 'private_key_jwt':
            {
                assertNoClientSecret('private_key_jwt', client.client_secret);
                if (clientPrivateKey === undefined) {
                    throw new TypeError('"options.clientPrivateKey" must be provided when "client.token_endpoint_auth_method" is "private_key_jwt"');
                }
                const { key, kid } = getKeyAndKid(clientPrivateKey);
                if (!isPrivateKey(key)) {
                    throw new TypeError('"options.clientPrivateKey.key" must be a private CryptoKey');
                }
                body.set('client_id', client.client_id);
                body.set('client_assertion_type', 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer');
                body.set('client_assertion', await privateKeyJwt(as, client, key, kid));
                break;
            }
        case 'tls_client_auth':
        case 'self_signed_tls_client_auth':
        case 'none':
            {
                assertNoClientSecret(client.token_endpoint_auth_method, client.client_secret);
                assertNoClientPrivateKey(client.token_endpoint_auth_method, clientPrivateKey);
                body.set('client_id', client.client_id);
                break;
            }
        default:
            throw new UnsupportedOperationError('unsupported client token_endpoint_auth_method');
    }
}
async function jwt(header, claimsSet, key) {
    if (!key.usages.includes('sign')) {
        throw new TypeError('CryptoKey instances used for signing assertions must include "sign" in their "usages"');
    }
    const input = `${b64u(buf(JSON.stringify(header)))}.${b64u(buf(JSON.stringify(claimsSet)))}`;
    const signature = b64u(await crypto.subtle.sign(keyToSubtle(key), key, buf(input)));
    return `${input}.${signature}`;
}
async function issueRequestObject(as, client, parameters, privateKey) {
    assertAs(as);
    assertClient(client);
    parameters = new URLSearchParams(parameters);
    const { key, kid } = getKeyAndKid(privateKey);
    if (!isPrivateKey(key)) {
        throw new TypeError('"privateKey.key" must be a private CryptoKey');
    }
    parameters.set('client_id', client.client_id);
    const now = epochTime() + getClockSkew(client);
    const claims = {
        ...Object.fromEntries(parameters.entries()),
        jti: randomBytes(),
        aud: as.issuer,
        exp: now + 60,
        iat: now,
        nbf: now,
        iss: client.client_id
    };
    let resource;
    if (parameters.has('resource') && (resource = parameters.getAll('resource')) && resource.length > 1) {
        claims.resource = resource;
    }
    {
        let value = parameters.get('max_age');
        if (value !== null) {
            claims.max_age = parseInt(value, 10);
            if (!Number.isFinite(claims.max_age)) {
                throw new OPE('"max_age" parameter must be a number');
            }
        }
    }
    {
        let value = parameters.get('claims');
        if (value !== null) {
            try {
                claims.claims = JSON.parse(value);
            } catch (cause) {
                throw new OPE('failed to parse the "claims" parameter as JSON', {
                    cause
                });
            }
            if (!isJsonObject(claims.claims)) {
                throw new OPE('"claims" parameter must be a JSON with a top level object');
            }
        }
    }
    {
        let value = parameters.get('authorization_details');
        if (value !== null) {
            try {
                claims.authorization_details = JSON.parse(value);
            } catch (cause) {
                throw new OPE('failed to parse the "authorization_details" parameter as JSON', {
                    cause
                });
            }
            if (!Array.isArray(claims.authorization_details)) {
                throw new OPE('"authorization_details" parameter must be a JSON with a top level array');
            }
        }
    }
    return jwt({
        alg: keyToJws(key),
        typ: 'oauth-authz-req+jwt',
        kid
    }, claims, key);
}
async function dpopProofJwt(headers, options, url, htm, clockSkew, accessToken) {
    const { privateKey, publicKey, nonce = dpopNonces.get(url.origin) } = options;
    if (!isPrivateKey(privateKey)) {
        throw new TypeError('"DPoP.privateKey" must be a private CryptoKey');
    }
    if (!isPublicKey(publicKey)) {
        throw new TypeError('"DPoP.publicKey" must be a public CryptoKey');
    }
    if (nonce !== undefined && !validateString(nonce)) {
        throw new TypeError('"DPoP.nonce" must be a non-empty string or undefined');
    }
    if (!publicKey.extractable) {
        throw new TypeError('"DPoP.publicKey.extractable" must be true');
    }
    const now = epochTime() + clockSkew;
    const proof = await jwt({
        alg: keyToJws(privateKey),
        typ: 'dpop+jwt',
        jwk: await publicJwk(publicKey)
    }, {
        iat: now,
        jti: randomBytes(),
        htm,
        nonce,
        htu: `${url.origin}${url.pathname}`,
        ath: accessToken ? b64u(await crypto.subtle.digest('SHA-256', buf(accessToken))) : undefined
    }, privateKey);
    headers.set('dpop', proof);
}
let jwkCache;
async function getSetPublicJwkCache(key) {
    const { kty, e, n, x, y, crv } = await crypto.subtle.exportKey('jwk', key);
    const jwk = {
        kty,
        e,
        n,
        x,
        y,
        crv
    };
    jwkCache.set(key, jwk);
    return jwk;
}
async function publicJwk(key) {
    jwkCache || (jwkCache = new WeakMap());
    return jwkCache.get(key) || getSetPublicJwkCache(key);
}
function validateEndpoint(value, endpoint, options) {
    if (typeof value !== 'string') {
        if (options?.[useMtlsAlias]) {
            throw new TypeError(`"as.mtls_endpoint_aliases.${endpoint}" must be a string`);
        }
        throw new TypeError(`"as.${endpoint}" must be a string`);
    }
    return new URL(value);
}
function resolveEndpoint(as, endpoint, options) {
    if (options?.[useMtlsAlias] && as.mtls_endpoint_aliases && endpoint in as.mtls_endpoint_aliases) {
        return validateEndpoint(as.mtls_endpoint_aliases[endpoint], endpoint, options);
    }
    return validateEndpoint(as[endpoint], endpoint);
}
async function pushedAuthorizationRequest(as, client, parameters, options) {
    assertAs(as);
    assertClient(client);
    const url = resolveEndpoint(as, 'pushed_authorization_request_endpoint', options);
    const body = new URLSearchParams(parameters);
    body.set('client_id', client.client_id);
    const headers = prepareHeaders(options?.headers);
    headers.set('accept', 'application/json');
    if (options?.DPoP !== undefined) {
        await dpopProofJwt(headers, options.DPoP, url, 'POST', getClockSkew(client));
    }
    return authenticatedRequest(as, client, 'POST', url, body, headers, options);
}
function isOAuth2Error(input) {
    const value = input;
    if (typeof value !== 'object' || Array.isArray(value) || value === null) {
        return false;
    }
    return value.error !== undefined;
}
function unquote(value) {
    if (value.length >= 2 && value[0] === '"' && value[value.length - 1] === '"') {
        return value.slice(1, -1);
    }
    return value;
}
const SPLIT_REGEXP = /((?:,|, )?[0-9a-zA-Z!#$%&'*+-.^_`|~]+=)/;
const SCHEMES_REGEXP = /(?:^|, ?)([0-9a-zA-Z!#$%&'*+\-.^_`|~]+)(?=$|[ ,])/g;
function wwwAuth(scheme, params) {
    const arr = params.split(SPLIT_REGEXP).slice(1);
    if (!arr.length) {
        return {
            scheme: scheme.toLowerCase(),
            parameters: {}
        };
    }
    arr[arr.length - 1] = arr[arr.length - 1].replace(/,$/, '');
    const parameters = {};
    for(let i = 1; i < arr.length; i += 2){
        const idx = i;
        if (arr[idx][0] === '"') {
            while(arr[idx].slice(-1) !== '"' && ++i < arr.length){
                arr[idx] += arr[i];
            }
        }
        const key = arr[idx - 1].replace(/^(?:, ?)|=$/g, '').toLowerCase();
        parameters[key] = unquote(arr[idx]);
    }
    return {
        scheme: scheme.toLowerCase(),
        parameters
    };
}
function parseWwwAuthenticateChallenges(response) {
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    const header = response.headers.get('www-authenticate');
    if (header === null) {
        return undefined;
    }
    const result = [];
    for (const { 1: scheme, index } of header.matchAll(SCHEMES_REGEXP)){
        result.push([
            scheme,
            index
        ]);
    }
    if (!result.length) {
        return undefined;
    }
    const challenges = result.map(([scheme, indexOf], i, others)=>{
        const next = others[i + 1];
        let parameters;
        if (next) {
            parameters = header.slice(indexOf, next[1]);
        } else {
            parameters = header.slice(indexOf);
        }
        return wwwAuth(scheme, parameters);
    });
    return challenges;
}
async function processPushedAuthorizationResponse(as, client, response) {
    assertAs(as);
    assertClient(client);
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 201) {
        let err;
        if (err = await handleOAuthBodyError(response)) {
            return err;
        }
        throw new OPE('"response" is not a conform Pushed Authorization Request Endpoint response');
    }
    assertReadableResponse(response);
    let json;
    try {
        json = await response.json();
    } catch (cause) {
        throw new OPE('failed to parse "response" body as JSON', {
            cause
        });
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!validateString(json.request_uri)) {
        throw new OPE('"response" body "request_uri" property must be a non-empty string');
    }
    if (typeof json.expires_in !== 'number' || json.expires_in <= 0) {
        throw new OPE('"response" body "expires_in" property must be a positive number');
    }
    return json;
}
async function protectedResourceRequest(accessToken, method, url, headers, body, options) {
    if (!validateString(accessToken)) {
        throw new TypeError('"accessToken" must be a non-empty string');
    }
    if (!(url instanceof URL)) {
        throw new TypeError('"url" must be an instance of URL');
    }
    headers = prepareHeaders(headers);
    if (options?.DPoP === undefined) {
        headers.set('authorization', `Bearer ${accessToken}`);
    } else {
        await dpopProofJwt(headers, options.DPoP, url, 'GET', getClockSkew({
            [clockSkew]: options?.[clockSkew]
        }), accessToken);
        headers.set('authorization', `DPoP ${accessToken}`);
    }
    return (options?.[customFetch] || fetch)(url.href, {
        body,
        headers: Object.fromEntries(headers.entries()),
        method,
        redirect: 'manual',
        signal: options?.signal ? signal(options.signal) : null
    }).then(processDpopNonce);
}
async function userInfoRequest(as, client, accessToken, options) {
    assertAs(as);
    assertClient(client);
    const url = resolveEndpoint(as, 'userinfo_endpoint', options);
    const headers = prepareHeaders(options?.headers);
    if (client.userinfo_signed_response_alg) {
        headers.set('accept', 'application/jwt');
    } else {
        headers.set('accept', 'application/json');
        headers.append('accept', 'application/jwt');
    }
    return protectedResourceRequest(accessToken, 'GET', url, headers, null, {
        ...options,
        [clockSkew]: getClockSkew(client)
    });
}
let jwksMap;
function setJwksCache(as, jwks, uat, cache) {
    jwksMap || (jwksMap = new WeakMap());
    jwksMap.set(as, {
        jwks,
        uat,
        get age () {
            return epochTime() - this.uat;
        }
    });
    if (cache) {
        Object.assign(cache, {
            jwks: structuredClone(jwks),
            uat
        });
    }
}
function isFreshJwksCache(input) {
    if (typeof input !== 'object' || input === null) {
        return false;
    }
    if (!('uat' in input) || typeof input.uat !== 'number' || epochTime() - input.uat >= 300) {
        return false;
    }
    if (!('jwks' in input) || !isJsonObject(input.jwks) || !Array.isArray(input.jwks.keys) || !Array.prototype.every.call(input.jwks.keys, isJsonObject)) {
        return false;
    }
    return true;
}
function clearJwksCache(as, cache) {
    jwksMap?.delete(as);
    delete cache?.jwks;
    delete cache?.uat;
}
async function getPublicSigKeyFromIssuerJwksUri(as, options, header) {
    const { alg, kid } = header;
    checkSupportedJwsAlg(alg);
    if (!jwksMap?.has(as) && isFreshJwksCache(options?.[experimental_jwksCache])) {
        setJwksCache(as, options?.[experimental_jwksCache].jwks, options?.[experimental_jwksCache].uat);
    }
    let jwks;
    let age;
    if (jwksMap?.has(as)) {
        ;
        ({ jwks, age } = jwksMap.get(as));
        if (age >= 300) {
            clearJwksCache(as, options?.[experimental_jwksCache]);
            return getPublicSigKeyFromIssuerJwksUri(as, options, header);
        }
    } else {
        jwks = await jwksRequest(as, options).then(processJwksResponse);
        age = 0;
        setJwksCache(as, jwks, epochTime(), options?.[experimental_jwksCache]);
    }
    let kty;
    switch(alg.slice(0, 2)){
        case 'RS':
        case 'PS':
            kty = 'RSA';
            break;
        case 'ES':
            kty = 'EC';
            break;
        case 'Ed':
            kty = 'OKP';
            break;
        default:
            throw new UnsupportedOperationError();
    }
    const candidates = jwks.keys.filter((jwk)=>{
        if (jwk.kty !== kty) {
            return false;
        }
        if (kid !== undefined && kid !== jwk.kid) {
            return false;
        }
        if (jwk.alg !== undefined && alg !== jwk.alg) {
            return false;
        }
        if (jwk.use !== undefined && jwk.use !== 'sig') {
            return false;
        }
        if (jwk.key_ops?.includes('verify') === false) {
            return false;
        }
        switch(true){
            case alg === 'ES256' && jwk.crv !== 'P-256':
            case alg === 'ES384' && jwk.crv !== 'P-384':
            case alg === 'ES512' && jwk.crv !== 'P-521':
            case alg === 'EdDSA' && !(jwk.crv === 'Ed25519' || jwk.crv === 'Ed448'):
                return false;
        }
        return true;
    });
    const { 0: jwk, length } = candidates;
    if (!length) {
        if (age >= 60) {
            clearJwksCache(as, options?.[experimental_jwksCache]);
            return getPublicSigKeyFromIssuerJwksUri(as, options, header);
        }
        throw new OPE('error when selecting a JWT verification key, no applicable keys found');
    }
    if (length !== 1) {
        throw new OPE('error when selecting a JWT verification key, multiple applicable keys found, a "kid" JWT Header Parameter is required');
    }
    const key = await importJwk(alg, jwk);
    if (key.type !== 'public') {
        throw new OPE('jwks_uri must only contain public keys');
    }
    return key;
}
const skipSubjectCheck = Symbol();
function getContentType(response) {
    return response.headers.get('content-type')?.split(';')[0];
}
async function processUserInfoResponse(as, client, expectedSubject, response) {
    assertAs(as);
    assertClient(client);
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        throw new OPE('"response" is not a conform UserInfo Endpoint response');
    }
    let json;
    if (getContentType(response) === 'application/jwt') {
        assertReadableResponse(response);
        const { claims } = await validateJwt(await response.text(), checkSigningAlgorithm.bind(undefined, client.userinfo_signed_response_alg, as.userinfo_signing_alg_values_supported), noSignatureCheck, getClockSkew(client), getClockTolerance(client)).then(validateOptionalAudience.bind(undefined, client.client_id)).then(validateOptionalIssuer.bind(undefined, as.issuer));
        json = claims;
    } else {
        if (client.userinfo_signed_response_alg) {
            throw new OPE('JWT UserInfo Response expected');
        }
        assertReadableResponse(response);
        try {
            json = await response.json();
        } catch (cause) {
            throw new OPE('failed to parse "response" body as JSON', {
                cause
            });
        }
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!validateString(json.sub)) {
        throw new OPE('"response" body "sub" property must be a non-empty string');
    }
    switch(expectedSubject){
        case skipSubjectCheck:
            break;
        default:
            if (!validateString(expectedSubject)) {
                throw new OPE('"expectedSubject" must be a non-empty string');
            }
            if (json.sub !== expectedSubject) {
                throw new OPE('unexpected "response" body "sub" value');
            }
    }
    return json;
}
async function authenticatedRequest(as, client, method, url, body, headers, options) {
    await clientAuthentication(as, client, body, headers, options?.clientPrivateKey);
    headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
    return (options?.[customFetch] || fetch)(url.href, {
        body,
        headers: Object.fromEntries(headers.entries()),
        method,
        redirect: 'manual',
        signal: options?.signal ? signal(options.signal) : null
    }).then(processDpopNonce);
}
async function tokenEndpointRequest(as, client, grantType, parameters, options) {
    const url = resolveEndpoint(as, 'token_endpoint', options);
    parameters.set('grant_type', grantType);
    const headers = prepareHeaders(options?.headers);
    headers.set('accept', 'application/json');
    if (options?.DPoP !== undefined) {
        await dpopProofJwt(headers, options.DPoP, url, 'POST', getClockSkew(client));
    }
    return authenticatedRequest(as, client, 'POST', url, parameters, headers, options);
}
async function refreshTokenGrantRequest(as, client, refreshToken, options) {
    assertAs(as);
    assertClient(client);
    if (!validateString(refreshToken)) {
        throw new TypeError('"refreshToken" must be a non-empty string');
    }
    const parameters = new URLSearchParams(options?.additionalParameters);
    parameters.set('refresh_token', refreshToken);
    return tokenEndpointRequest(as, client, 'refresh_token', parameters, options);
}
const idTokenClaims = new WeakMap();
function getValidatedIdTokenClaims(ref) {
    if (!ref.id_token) {
        return undefined;
    }
    const claims = idTokenClaims.get(ref);
    if (!claims) {
        throw new TypeError('"ref" was already garbage collected or did not resolve from the proper sources');
    }
    return claims;
}
async function processGenericAccessTokenResponse(as, client, response, ignoreIdToken = false, ignoreRefreshToken = false) {
    assertAs(as);
    assertClient(client);
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        let err;
        if (err = await handleOAuthBodyError(response)) {
            return err;
        }
        throw new OPE('"response" is not a conform Token Endpoint response');
    }
    assertReadableResponse(response);
    let json;
    try {
        json = await response.json();
    } catch (cause) {
        throw new OPE('failed to parse "response" body as JSON', {
            cause
        });
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!validateString(json.access_token)) {
        throw new OPE('"response" body "access_token" property must be a non-empty string');
    }
    if (!validateString(json.token_type)) {
        throw new OPE('"response" body "token_type" property must be a non-empty string');
    }
    json.token_type = json.token_type.toLowerCase();
    if (json.token_type !== 'dpop' && json.token_type !== 'bearer') {
        throw new UnsupportedOperationError('unsupported `token_type` value');
    }
    if (json.expires_in !== undefined && (typeof json.expires_in !== 'number' || json.expires_in <= 0)) {
        throw new OPE('"response" body "expires_in" property must be a positive number');
    }
    if (!ignoreRefreshToken && json.refresh_token !== undefined && !validateString(json.refresh_token)) {
        throw new OPE('"response" body "refresh_token" property must be a non-empty string');
    }
    if (json.scope !== undefined && typeof json.scope !== 'string') {
        throw new OPE('"response" body "scope" property must be a string');
    }
    if (!ignoreIdToken) {
        if (json.id_token !== undefined && !validateString(json.id_token)) {
            throw new OPE('"response" body "id_token" property must be a non-empty string');
        }
        if (json.id_token) {
            const { claims } = await validateJwt(json.id_token, checkSigningAlgorithm.bind(undefined, client.id_token_signed_response_alg, as.id_token_signing_alg_values_supported), noSignatureCheck, getClockSkew(client), getClockTolerance(client)).then(validatePresence.bind(undefined, [
                'aud',
                'exp',
                'iat',
                'iss',
                'sub'
            ])).then(validateIssuer.bind(undefined, as.issuer)).then(validateAudience.bind(undefined, client.client_id));
            if (Array.isArray(claims.aud) && claims.aud.length !== 1 && claims.azp !== client.client_id) {
                throw new OPE('unexpected ID Token "azp" (authorized party) claim value');
            }
            if (claims.auth_time !== undefined && (!Number.isFinite(claims.auth_time) || Math.sign(claims.auth_time) !== 1)) {
                throw new OPE('ID Token "auth_time" (authentication time) must be a positive number');
            }
            idTokenClaims.set(json, claims);
        }
    }
    return json;
}
async function processRefreshTokenResponse(as, client, response) {
    return processGenericAccessTokenResponse(as, client, response);
}
function validateOptionalAudience(expected, result) {
    if (result.claims.aud !== undefined) {
        return validateAudience(expected, result);
    }
    return result;
}
function validateAudience(expected, result) {
    if (Array.isArray(result.claims.aud)) {
        if (!result.claims.aud.includes(expected)) {
            throw new OPE('unexpected JWT "aud" (audience) claim value');
        }
    } else if (result.claims.aud !== expected) {
        throw new OPE('unexpected JWT "aud" (audience) claim value');
    }
    return result;
}
function validateOptionalIssuer(expected, result) {
    if (result.claims.iss !== undefined) {
        return validateIssuer(expected, result);
    }
    return result;
}
function validateIssuer(expected, result) {
    if (result.claims.iss !== expected) {
        throw new OPE('unexpected JWT "iss" (issuer) claim value');
    }
    return result;
}
const branded = new WeakSet();
function brand(searchParams) {
    branded.add(searchParams);
    return searchParams;
}
async function authorizationCodeGrantRequest(as, client, callbackParameters, redirectUri, codeVerifier, options) {
    assertAs(as);
    assertClient(client);
    if (!branded.has(callbackParameters)) {
        throw new TypeError('"callbackParameters" must be an instance of URLSearchParams obtained from "validateAuthResponse()", or "validateJwtAuthResponse()');
    }
    if (!validateString(redirectUri)) {
        throw new TypeError('"redirectUri" must be a non-empty string');
    }
    if (!validateString(codeVerifier)) {
        throw new TypeError('"codeVerifier" must be a non-empty string');
    }
    const code = getURLSearchParameter(callbackParameters, 'code');
    if (!code) {
        throw new OPE('no authorization code in "callbackParameters"');
    }
    const parameters = new URLSearchParams(options?.additionalParameters);
    parameters.set('redirect_uri', redirectUri);
    parameters.set('code_verifier', codeVerifier);
    parameters.set('code', code);
    return tokenEndpointRequest(as, client, 'authorization_code', parameters, options);
}
const jwtClaimNames = {
    aud: 'audience',
    c_hash: 'code hash',
    client_id: 'client id',
    exp: 'expiration time',
    iat: 'issued at',
    iss: 'issuer',
    jti: 'jwt id',
    nonce: 'nonce',
    s_hash: 'state hash',
    sub: 'subject',
    ath: 'access token hash',
    htm: 'http method',
    htu: 'http uri',
    cnf: 'confirmation'
};
function validatePresence(required, result) {
    for (const claim of required){
        if (result.claims[claim] === undefined) {
            throw new OPE(`JWT "${claim}" (${jwtClaimNames[claim]}) claim missing`);
        }
    }
    return result;
}
const expectNoNonce = Symbol();
const skipAuthTimeCheck = Symbol();
async function processAuthorizationCodeOpenIDResponse(as, client, response, expectedNonce, maxAge) {
    const result = await processGenericAccessTokenResponse(as, client, response);
    if (isOAuth2Error(result)) {
        return result;
    }
    if (!validateString(result.id_token)) {
        throw new OPE('"response" body "id_token" property must be a non-empty string');
    }
    maxAge ?? (maxAge = client.default_max_age ?? skipAuthTimeCheck);
    const claims = getValidatedIdTokenClaims(result);
    if ((client.require_auth_time || maxAge !== skipAuthTimeCheck) && claims.auth_time === undefined) {
        throw new OPE('ID Token "auth_time" (authentication time) claim missing');
    }
    if (maxAge !== skipAuthTimeCheck) {
        if (typeof maxAge !== 'number' || maxAge < 0) {
            throw new TypeError('"maxAge" must be a non-negative number');
        }
        const now = epochTime() + getClockSkew(client);
        const tolerance = getClockTolerance(client);
        if (claims.auth_time + maxAge < now - tolerance) {
            throw new OPE('too much time has elapsed since the last End-User authentication');
        }
    }
    switch(expectedNonce){
        case undefined:
        case expectNoNonce:
            if (claims.nonce !== undefined) {
                throw new OPE('unexpected ID Token "nonce" claim value');
            }
            break;
        default:
            if (!validateString(expectedNonce)) {
                throw new TypeError('"expectedNonce" must be a non-empty string');
            }
            if (claims.nonce === undefined) {
                throw new OPE('ID Token "nonce" claim missing');
            }
            if (claims.nonce !== expectedNonce) {
                throw new OPE('unexpected ID Token "nonce" claim value');
            }
    }
    return result;
}
async function processAuthorizationCodeOAuth2Response(as, client, response) {
    const result = await processGenericAccessTokenResponse(as, client, response, true);
    if (isOAuth2Error(result)) {
        return result;
    }
    if (result.id_token !== undefined) {
        if (typeof result.id_token === 'string' && result.id_token.length) {
            throw new OPE('Unexpected ID Token returned, use processAuthorizationCodeOpenIDResponse() for OpenID Connect callback processing');
        }
        delete result.id_token;
    }
    return result;
}
function checkJwtType(expected, result) {
    if (typeof result.header.typ !== 'string' || normalizeTyp(result.header.typ) !== expected) {
        throw new OPE('unexpected JWT "typ" header parameter value');
    }
    return result;
}
async function clientCredentialsGrantRequest(as, client, parameters, options) {
    assertAs(as);
    assertClient(client);
    return tokenEndpointRequest(as, client, 'client_credentials', new URLSearchParams(parameters), options);
}
async function processClientCredentialsResponse(as, client, response) {
    const result = await processGenericAccessTokenResponse(as, client, response, true, true);
    if (isOAuth2Error(result)) {
        return result;
    }
    return result;
}
async function revocationRequest(as, client, token, options) {
    assertAs(as);
    assertClient(client);
    if (!validateString(token)) {
        throw new TypeError('"token" must be a non-empty string');
    }
    const url = resolveEndpoint(as, 'revocation_endpoint', options);
    const body = new URLSearchParams(options?.additionalParameters);
    body.set('token', token);
    const headers = prepareHeaders(options?.headers);
    headers.delete('accept');
    return authenticatedRequest(as, client, 'POST', url, body, headers, options);
}
async function processRevocationResponse(response) {
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        let err;
        if (err = await handleOAuthBodyError(response)) {
            return err;
        }
        throw new OPE('"response" is not a conform Revocation Endpoint response');
    }
    return undefined;
}
function assertReadableResponse(response) {
    if (response.bodyUsed) {
        throw new TypeError('"response" body has been used already');
    }
}
async function introspectionRequest(as, client, token, options) {
    assertAs(as);
    assertClient(client);
    if (!validateString(token)) {
        throw new TypeError('"token" must be a non-empty string');
    }
    const url = resolveEndpoint(as, 'introspection_endpoint', options);
    const body = new URLSearchParams(options?.additionalParameters);
    body.set('token', token);
    const headers = prepareHeaders(options?.headers);
    if (options?.requestJwtResponse ?? client.introspection_signed_response_alg) {
        headers.set('accept', 'application/token-introspection+jwt');
    } else {
        headers.set('accept', 'application/json');
    }
    return authenticatedRequest(as, client, 'POST', url, body, headers, options);
}
async function processIntrospectionResponse(as, client, response) {
    assertAs(as);
    assertClient(client);
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        let err;
        if (err = await handleOAuthBodyError(response)) {
            return err;
        }
        throw new OPE('"response" is not a conform Introspection Endpoint response');
    }
    let json;
    if (getContentType(response) === 'application/token-introspection+jwt') {
        assertReadableResponse(response);
        const { claims } = await validateJwt(await response.text(), checkSigningAlgorithm.bind(undefined, client.introspection_signed_response_alg, as.introspection_signing_alg_values_supported), noSignatureCheck, getClockSkew(client), getClockTolerance(client)).then(checkJwtType.bind(undefined, 'token-introspection+jwt')).then(validatePresence.bind(undefined, [
            'aud',
            'iat',
            'iss'
        ])).then(validateIssuer.bind(undefined, as.issuer)).then(validateAudience.bind(undefined, client.client_id));
        json = claims.token_introspection;
        if (!isJsonObject(json)) {
            throw new OPE('JWT "token_introspection" claim must be a JSON object');
        }
    } else {
        assertReadableResponse(response);
        try {
            json = await response.json();
        } catch (cause) {
            throw new OPE('failed to parse "response" body as JSON', {
                cause
            });
        }
        if (!isJsonObject(json)) {
            throw new OPE('"response" body must be a top level object');
        }
    }
    if (typeof json.active !== 'boolean') {
        throw new OPE('"response" body "active" property must be a boolean');
    }
    return json;
}
async function jwksRequest(as, options) {
    assertAs(as);
    const url = resolveEndpoint(as, 'jwks_uri');
    const headers = prepareHeaders(options?.headers);
    headers.set('accept', 'application/json');
    headers.append('accept', 'application/jwk-set+json');
    return (options?.[customFetch] || fetch)(url.href, {
        headers: Object.fromEntries(headers.entries()),
        method: 'GET',
        redirect: 'manual',
        signal: options?.signal ? signal(options.signal) : null
    }).then(processDpopNonce);
}
async function processJwksResponse(response) {
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        throw new OPE('"response" is not a conform JSON Web Key Set response');
    }
    assertReadableResponse(response);
    let json;
    try {
        json = await response.json();
    } catch (cause) {
        throw new OPE('failed to parse "response" body as JSON', {
            cause
        });
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!Array.isArray(json.keys)) {
        throw new OPE('"response" body "keys" property must be an array');
    }
    if (!Array.prototype.every.call(json.keys, isJsonObject)) {
        throw new OPE('"response" body "keys" property members must be JWK formatted objects');
    }
    return json;
}
async function handleOAuthBodyError(response) {
    if (response.status > 399 && response.status < 500) {
        assertReadableResponse(response);
        try {
            const json = await response.json();
            if (isJsonObject(json) && typeof json.error === 'string' && json.error.length) {
                if (json.error_description !== undefined && typeof json.error_description !== 'string') {
                    delete json.error_description;
                }
                if (json.error_uri !== undefined && typeof json.error_uri !== 'string') {
                    delete json.error_uri;
                }
                if (json.algs !== undefined && typeof json.algs !== 'string') {
                    delete json.algs;
                }
                if (json.scope !== undefined && typeof json.scope !== 'string') {
                    delete json.scope;
                }
                return json;
            }
        } catch  {}
    }
    return undefined;
}
function checkSupportedJwsAlg(alg) {
    if (!SUPPORTED_JWS_ALGS.includes(alg)) {
        throw new UnsupportedOperationError('unsupported JWS "alg" identifier');
    }
    return alg;
}
function checkRsaKeyAlgorithm(algorithm) {
    if (typeof algorithm.modulusLength !== 'number' || algorithm.modulusLength < 2048) {
        throw new OPE(`${algorithm.name} modulusLength must be at least 2048 bits`);
    }
}
function ecdsaHashName(namedCurve) {
    switch(namedCurve){
        case 'P-256':
            return 'SHA-256';
        case 'P-384':
            return 'SHA-384';
        case 'P-521':
            return 'SHA-512';
        default:
            throw new UnsupportedOperationError();
    }
}
function keyToSubtle(key) {
    switch(key.algorithm.name){
        case 'ECDSA':
            return {
                name: key.algorithm.name,
                hash: ecdsaHashName(key.algorithm.namedCurve)
            };
        case 'RSA-PSS':
            {
                checkRsaKeyAlgorithm(key.algorithm);
                switch(key.algorithm.hash.name){
                    case 'SHA-256':
                    case 'SHA-384':
                    case 'SHA-512':
                        return {
                            name: key.algorithm.name,
                            saltLength: parseInt(key.algorithm.hash.name.slice(-3), 10) >> 3
                        };
                    default:
                        throw new UnsupportedOperationError();
                }
            }
        case 'RSASSA-PKCS1-v1_5':
            checkRsaKeyAlgorithm(key.algorithm);
            return key.algorithm.name;
        case 'Ed448':
        case 'Ed25519':
            return key.algorithm.name;
    }
    throw new UnsupportedOperationError();
}
const noSignatureCheck = Symbol();
async function validateJwt(jws, checkAlg, getKey, clockSkew, clockTolerance) {
    const { 0: protectedHeader, 1: payload, 2: encodedSignature, length } = jws.split('.');
    if (length === 5) {
        throw new UnsupportedOperationError('JWE structure JWTs are not supported');
    }
    if (length !== 3) {
        throw new OPE('Invalid JWT');
    }
    let header;
    try {
        header = JSON.parse(buf(b64u(protectedHeader)));
    } catch (cause) {
        throw new OPE('failed to parse JWT Header body as base64url encoded JSON', {
            cause
        });
    }
    if (!isJsonObject(header)) {
        throw new OPE('JWT Header must be a top level object');
    }
    checkAlg(header);
    if (header.crit !== undefined) {
        throw new OPE('unexpected JWT "crit" header parameter');
    }
    const signature = b64u(encodedSignature);
    let key;
    if (getKey !== noSignatureCheck) {
        key = await getKey(header);
        const input = `${protectedHeader}.${payload}`;
        const verified = await crypto.subtle.verify(keyToSubtle(key), key, signature, buf(input));
        if (!verified) {
            throw new OPE('JWT signature verification failed');
        }
    }
    let claims;
    try {
        claims = JSON.parse(buf(b64u(payload)));
    } catch (cause) {
        throw new OPE('failed to parse JWT Payload body as base64url encoded JSON', {
            cause
        });
    }
    if (!isJsonObject(claims)) {
        throw new OPE('JWT Payload must be a top level object');
    }
    const now = epochTime() + clockSkew;
    if (claims.exp !== undefined) {
        if (typeof claims.exp !== 'number') {
            throw new OPE('unexpected JWT "exp" (expiration time) claim type');
        }
        if (claims.exp <= now - clockTolerance) {
            throw new OPE('unexpected JWT "exp" (expiration time) claim value, timestamp is <= now()');
        }
    }
    if (claims.iat !== undefined) {
        if (typeof claims.iat !== 'number') {
            throw new OPE('unexpected JWT "iat" (issued at) claim type');
        }
    }
    if (claims.iss !== undefined) {
        if (typeof claims.iss !== 'string') {
            throw new OPE('unexpected JWT "iss" (issuer) claim type');
        }
    }
    if (claims.nbf !== undefined) {
        if (typeof claims.nbf !== 'number') {
            throw new OPE('unexpected JWT "nbf" (not before) claim type');
        }
        if (claims.nbf > now + clockTolerance) {
            throw new OPE('unexpected JWT "nbf" (not before) claim value, timestamp is > now()');
        }
    }
    if (claims.aud !== undefined) {
        if (typeof claims.aud !== 'string' && !Array.isArray(claims.aud)) {
            throw new OPE('unexpected JWT "aud" (audience) claim type');
        }
    }
    return {
        header,
        claims,
        signature,
        key
    };
}
async function validateJwtAuthResponse(as, client, parameters, expectedState, options) {
    assertAs(as);
    assertClient(client);
    if (parameters instanceof URL) {
        parameters = parameters.searchParams;
    }
    if (!(parameters instanceof URLSearchParams)) {
        throw new TypeError('"parameters" must be an instance of URLSearchParams, or URL');
    }
    const response = getURLSearchParameter(parameters, 'response');
    if (!response) {
        throw new OPE('"parameters" does not contain a JARM response');
    }
    if (typeof as.jwks_uri !== 'string') {
        throw new TypeError('"as.jwks_uri" must be a string');
    }
    const { claims } = await validateJwt(response, checkSigningAlgorithm.bind(undefined, client.authorization_signed_response_alg, as.authorization_signing_alg_values_supported), getPublicSigKeyFromIssuerJwksUri.bind(undefined, as, options), getClockSkew(client), getClockTolerance(client)).then(validatePresence.bind(undefined, [
        'aud',
        'exp',
        'iss'
    ])).then(validateIssuer.bind(undefined, as.issuer)).then(validateAudience.bind(undefined, client.client_id));
    const result = new URLSearchParams();
    for (const [key, value] of Object.entries(claims)){
        if (typeof value === 'string' && key !== 'aud') {
            result.set(key, value);
        }
    }
    return validateAuthResponse(as, client, result, expectedState);
}
async function idTokenHash(alg, data, key) {
    let algorithm;
    switch(alg){
        case 'RS256':
        case 'PS256':
        case 'ES256':
            algorithm = 'SHA-256';
            break;
        case 'RS384':
        case 'PS384':
        case 'ES384':
            algorithm = 'SHA-384';
            break;
        case 'RS512':
        case 'PS512':
        case 'ES512':
            algorithm = 'SHA-512';
            break;
        case 'EdDSA':
            if (key.algorithm.name === 'Ed25519') {
                algorithm = 'SHA-512';
                break;
            }
            throw new UnsupportedOperationError();
        default:
            throw new UnsupportedOperationError();
    }
    const digest = await crypto.subtle.digest(algorithm, buf(data));
    return b64u(digest.slice(0, digest.byteLength / 2));
}
async function idTokenHashMatches(data, actual, alg, key) {
    const expected = await idTokenHash(alg, data, key);
    return actual === expected;
}
async function validateDetachedSignatureResponse(as, client, parameters, expectedNonce, expectedState, maxAge, options) {
    assertAs(as);
    assertClient(client);
    if (parameters instanceof URL) {
        if (!parameters.hash.length) {
            throw new TypeError('"parameters" as an instance of URL must contain a hash (fragment) with the Authorization Response parameters');
        }
        parameters = new URLSearchParams(parameters.hash.slice(1));
    }
    if (!(parameters instanceof URLSearchParams)) {
        throw new TypeError('"parameters" must be an instance of URLSearchParams');
    }
    parameters = new URLSearchParams(parameters);
    const id_token = getURLSearchParameter(parameters, 'id_token');
    parameters.delete('id_token');
    switch(expectedState){
        case undefined:
        case expectNoState:
            break;
        default:
            if (!validateString(expectedState)) {
                throw new TypeError('"expectedState" must be a non-empty string');
            }
    }
    const result = validateAuthResponse({
        ...as,
        authorization_response_iss_parameter_supported: false
    }, client, parameters, expectedState);
    if (isOAuth2Error(result)) {
        return result;
    }
    if (!id_token) {
        throw new OPE('"parameters" does not contain an ID Token');
    }
    const code = getURLSearchParameter(parameters, 'code');
    if (!code) {
        throw new OPE('"parameters" does not contain an Authorization Code');
    }
    if (typeof as.jwks_uri !== 'string') {
        throw new TypeError('"as.jwks_uri" must be a string');
    }
    const requiredClaims = [
        'aud',
        'exp',
        'iat',
        'iss',
        'sub',
        'nonce',
        'c_hash'
    ];
    if (typeof expectedState === 'string') {
        requiredClaims.push('s_hash');
    }
    const { claims, header, key } = await validateJwt(id_token, checkSigningAlgorithm.bind(undefined, client.id_token_signed_response_alg, as.id_token_signing_alg_values_supported), getPublicSigKeyFromIssuerJwksUri.bind(undefined, as, options), getClockSkew(client), getClockTolerance(client)).then(validatePresence.bind(undefined, requiredClaims)).then(validateIssuer.bind(undefined, as.issuer)).then(validateAudience.bind(undefined, client.client_id));
    const clockSkew = getClockSkew(client);
    const now = epochTime() + clockSkew;
    if (claims.iat < now - 3600) {
        throw new OPE('unexpected JWT "iat" (issued at) claim value, it is too far in the past');
    }
    if (typeof claims.c_hash !== 'string' || await idTokenHashMatches(code, claims.c_hash, header.alg, key) !== true) {
        throw new OPE('invalid ID Token "c_hash" (code hash) claim value');
    }
    if (claims.s_hash !== undefined && typeof expectedState !== 'string') {
        throw new OPE('could not verify ID Token "s_hash" (state hash) claim value');
    }
    if (typeof expectedState === 'string' && (typeof claims.s_hash !== 'string' || await idTokenHashMatches(expectedState, claims.s_hash, header.alg, key) !== true)) {
        throw new OPE('invalid ID Token "s_hash" (state hash) claim value');
    }
    if (claims.auth_time !== undefined && (!Number.isFinite(claims.auth_time) || Math.sign(claims.auth_time) !== 1)) {
        throw new OPE('ID Token "auth_time" (authentication time) must be a positive number');
    }
    maxAge ?? (maxAge = client.default_max_age ?? skipAuthTimeCheck);
    if ((client.require_auth_time || maxAge !== skipAuthTimeCheck) && claims.auth_time === undefined) {
        throw new OPE('ID Token "auth_time" (authentication time) claim missing');
    }
    if (maxAge !== skipAuthTimeCheck) {
        if (typeof maxAge !== 'number' || maxAge < 0) {
            throw new TypeError('"maxAge" must be a non-negative number');
        }
        const now = epochTime() + getClockSkew(client);
        const tolerance = getClockTolerance(client);
        if (claims.auth_time + maxAge < now - tolerance) {
            throw new OPE('too much time has elapsed since the last End-User authentication');
        }
    }
    if (!validateString(expectedNonce)) {
        throw new TypeError('"expectedNonce" must be a non-empty string');
    }
    if (claims.nonce !== expectedNonce) {
        throw new OPE('unexpected ID Token "nonce" claim value');
    }
    if (Array.isArray(claims.aud) && claims.aud.length !== 1 && claims.azp !== client.client_id) {
        throw new OPE('unexpected ID Token "azp" (authorized party) claim value');
    }
    return result;
}
function checkSigningAlgorithm(client, issuer, header) {
    if (client !== undefined) {
        if (header.alg !== client) {
            throw new OPE('unexpected JWT "alg" header parameter');
        }
        return;
    }
    if (Array.isArray(issuer)) {
        if (!issuer.includes(header.alg)) {
            throw new OPE('unexpected JWT "alg" header parameter');
        }
        return;
    }
    if (header.alg !== 'RS256') {
        throw new OPE('unexpected JWT "alg" header parameter');
    }
}
function getURLSearchParameter(parameters, name) {
    const { 0: value, length } = parameters.getAll(name);
    if (length > 1) {
        throw new OPE(`"${name}" parameter must be provided only once`);
    }
    return value;
}
const skipStateCheck = Symbol();
const expectNoState = Symbol();
function validateAuthResponse(as, client, parameters, expectedState) {
    assertAs(as);
    assertClient(client);
    if (parameters instanceof URL) {
        parameters = parameters.searchParams;
    }
    if (!(parameters instanceof URLSearchParams)) {
        throw new TypeError('"parameters" must be an instance of URLSearchParams, or URL');
    }
    if (getURLSearchParameter(parameters, 'response')) {
        throw new OPE('"parameters" contains a JARM response, use validateJwtAuthResponse() instead of validateAuthResponse()');
    }
    const iss = getURLSearchParameter(parameters, 'iss');
    const state = getURLSearchParameter(parameters, 'state');
    if (!iss && as.authorization_response_iss_parameter_supported) {
        throw new OPE('response parameter "iss" (issuer) missing');
    }
    if (iss && iss !== as.issuer) {
        throw new OPE('unexpected "iss" (issuer) response parameter value');
    }
    switch(expectedState){
        case undefined:
        case expectNoState:
            if (state !== undefined) {
                throw new OPE('unexpected "state" response parameter encountered');
            }
            break;
        case skipStateCheck:
            break;
        default:
            if (!validateString(expectedState)) {
                throw new OPE('"expectedState" must be a non-empty string');
            }
            if (state === undefined) {
                throw new OPE('response parameter "state" missing');
            }
            if (state !== expectedState) {
                throw new OPE('unexpected "state" response parameter value');
            }
    }
    const error = getURLSearchParameter(parameters, 'error');
    if (error) {
        return {
            error,
            error_description: getURLSearchParameter(parameters, 'error_description'),
            error_uri: getURLSearchParameter(parameters, 'error_uri')
        };
    }
    const id_token = getURLSearchParameter(parameters, 'id_token');
    const token = getURLSearchParameter(parameters, 'token');
    if (id_token !== undefined || token !== undefined) {
        throw new UnsupportedOperationError('implicit and hybrid flows are not supported');
    }
    return brand(new URLSearchParams(parameters));
}
function algToSubtle(alg, crv) {
    switch(alg){
        case 'PS256':
        case 'PS384':
        case 'PS512':
            return {
                name: 'RSA-PSS',
                hash: `SHA-${alg.slice(-3)}`
            };
        case 'RS256':
        case 'RS384':
        case 'RS512':
            return {
                name: 'RSASSA-PKCS1-v1_5',
                hash: `SHA-${alg.slice(-3)}`
            };
        case 'ES256':
        case 'ES384':
            return {
                name: 'ECDSA',
                namedCurve: `P-${alg.slice(-3)}`
            };
        case 'ES512':
            return {
                name: 'ECDSA',
                namedCurve: 'P-521'
            };
        case 'EdDSA':
            {
                switch(crv){
                    case 'Ed25519':
                    case 'Ed448':
                        return crv;
                    default:
                        throw new UnsupportedOperationError();
                }
            }
        default:
            throw new UnsupportedOperationError();
    }
}
async function importJwk(alg, jwk) {
    const { ext, key_ops, use, ...key } = jwk;
    return crypto.subtle.importKey('jwk', key, algToSubtle(alg, jwk.crv), true, [
        'verify'
    ]);
}
async function deviceAuthorizationRequest(as, client, parameters, options) {
    assertAs(as);
    assertClient(client);
    const url = resolveEndpoint(as, 'device_authorization_endpoint', options);
    const body = new URLSearchParams(parameters);
    body.set('client_id', client.client_id);
    const headers = prepareHeaders(options?.headers);
    headers.set('accept', 'application/json');
    return authenticatedRequest(as, client, 'POST', url, body, headers, options);
}
async function processDeviceAuthorizationResponse(as, client, response) {
    assertAs(as);
    assertClient(client);
    if (!looseInstanceOf(response, Response)) {
        throw new TypeError('"response" must be an instance of Response');
    }
    if (response.status !== 200) {
        let err;
        if (err = await handleOAuthBodyError(response)) {
            return err;
        }
        throw new OPE('"response" is not a conform Device Authorization Endpoint response');
    }
    assertReadableResponse(response);
    let json;
    try {
        json = await response.json();
    } catch (cause) {
        throw new OPE('failed to parse "response" body as JSON', {
            cause
        });
    }
    if (!isJsonObject(json)) {
        throw new OPE('"response" body must be a top level object');
    }
    if (!validateString(json.device_code)) {
        throw new OPE('"response" body "device_code" property must be a non-empty string');
    }
    if (!validateString(json.user_code)) {
        throw new OPE('"response" body "user_code" property must be a non-empty string');
    }
    if (!validateString(json.verification_uri)) {
        throw new OPE('"response" body "verification_uri" property must be a non-empty string');
    }
    if (typeof json.expires_in !== 'number' || json.expires_in <= 0) {
        throw new OPE('"response" body "expires_in" property must be a positive number');
    }
    if (json.verification_uri_complete !== undefined && !validateString(json.verification_uri_complete)) {
        throw new OPE('"response" body "verification_uri_complete" property must be a non-empty string');
    }
    if (json.interval !== undefined && (typeof json.interval !== 'number' || json.interval <= 0)) {
        throw new OPE('"response" body "interval" property must be a positive number');
    }
    return json;
}
async function deviceCodeGrantRequest(as, client, deviceCode, options) {
    assertAs(as);
    assertClient(client);
    if (!validateString(deviceCode)) {
        throw new TypeError('"deviceCode" must be a non-empty string');
    }
    const parameters = new URLSearchParams(options?.additionalParameters);
    parameters.set('device_code', deviceCode);
    return tokenEndpointRequest(as, client, 'urn:ietf:params:oauth:grant-type:device_code', parameters, options);
}
async function processDeviceCodeResponse(as, client, response) {
    return processGenericAccessTokenResponse(as, client, response);
}
async function generateKeyPair(alg, options) {
    if (!validateString(alg)) {
        throw new TypeError('"alg" must be a non-empty string');
    }
    const algorithm = algToSubtle(alg, alg === 'EdDSA' ? options?.crv ?? 'Ed25519' : undefined);
    if (alg.startsWith('PS') || alg.startsWith('RS')) {
        Object.assign(algorithm, {
            modulusLength: options?.modulusLength ?? 2048,
            publicExponent: new Uint8Array([
                0x01,
                0x00,
                0x01
            ])
        });
    }
    return crypto.subtle.generateKey(algorithm, options?.extractable ?? false, [
        'sign',
        'verify'
    ]);
}
function normalizeHtu(htu) {
    const url = new URL(htu);
    url.search = '';
    url.hash = '';
    return url.href;
}
async function validateDPoP(as, request, accessToken, accessTokenClaims, options) {
    const header = request.headers.get('dpop');
    if (header === null) {
        throw new OPE('operation indicated DPoP use but the request has no DPoP HTTP Header');
    }
    if (request.headers.get('authorization')?.toLowerCase().startsWith('dpop ') === false) {
        throw new OPE(`operation indicated DPoP use but the request's Authorization HTTP Header scheme is not DPoP`);
    }
    if (typeof accessTokenClaims.cnf?.jkt !== 'string') {
        throw new OPE('operation indicated DPoP use but the JWT Access Token has no jkt confirmation claim');
    }
    const clockSkew = getClockSkew(options);
    const proof = await validateJwt(header, checkSigningAlgorithm.bind(undefined, undefined, as?.dpop_signing_alg_values_supported || SUPPORTED_JWS_ALGS), async ({ jwk, alg })=>{
        if (!jwk) {
            throw new OPE('DPoP Proof is missing the jwk header parameter');
        }
        const key = await importJwk(alg, jwk);
        if (key.type !== 'public') {
            throw new OPE('DPoP Proof jwk header parameter must contain a public key');
        }
        return key;
    }, clockSkew, getClockTolerance(options)).then(checkJwtType.bind(undefined, 'dpop+jwt')).then(validatePresence.bind(undefined, [
        'iat',
        'jti',
        'ath',
        'htm',
        'htu'
    ]));
    const now = epochTime() + clockSkew;
    const diff = Math.abs(now - proof.claims.iat);
    if (diff > 300) {
        throw new OPE('DPoP Proof iat is not recent enough');
    }
    if (proof.claims.htm !== request.method) {
        throw new OPE('DPoP Proof htm mismatch');
    }
    if (typeof proof.claims.htu !== 'string' || normalizeHtu(proof.claims.htu) !== normalizeHtu(request.url)) {
        throw new OPE('DPoP Proof htu mismatch');
    }
    {
        const expected = b64u(await crypto.subtle.digest('SHA-256', encoder.encode(accessToken)));
        if (proof.claims.ath !== expected) {
            throw new OPE('DPoP Proof ath mismatch');
        }
    }
    {
        let components;
        switch(proof.header.jwk.kty){
            case 'EC':
                components = {
                    crv: proof.header.jwk.crv,
                    kty: proof.header.jwk.kty,
                    x: proof.header.jwk.x,
                    y: proof.header.jwk.y
                };
                break;
            case 'OKP':
                components = {
                    crv: proof.header.jwk.crv,
                    kty: proof.header.jwk.kty,
                    x: proof.header.jwk.x
                };
                break;
            case 'RSA':
                components = {
                    e: proof.header.jwk.e,
                    kty: proof.header.jwk.kty,
                    n: proof.header.jwk.n
                };
                break;
            default:
                throw new UnsupportedOperationError();
        }
        const expected = b64u(await crypto.subtle.digest('SHA-256', encoder.encode(JSON.stringify(components))));
        if (accessTokenClaims.cnf.jkt !== expected) {
            throw new OPE('JWT Access Token confirmation mismatch');
        }
    }
}
async function validateJwtAccessToken(as, request, expectedAudience, options) {
    assertAs(as);
    if (!looseInstanceOf(request, Request)) {
        throw new TypeError('"request" must be an instance of Request');
    }
    if (!validateString(expectedAudience)) {
        throw new OPE('"expectedAudience" must be a non-empty string');
    }
    const authorization = request.headers.get('authorization');
    if (authorization === null) {
        throw new OPE('"request" is missing an Authorization HTTP Header');
    }
    let { 0: scheme, 1: accessToken, length } = authorization.split(' ');
    scheme = scheme.toLowerCase();
    switch(scheme){
        case 'dpop':
        case 'bearer':
            break;
        default:
            throw new UnsupportedOperationError('unsupported Authorization HTTP Header scheme');
    }
    if (length !== 2) {
        throw new OPE('invalid Authorization HTTP Header format');
    }
    const requiredClaims = [
        'iss',
        'exp',
        'aud',
        'sub',
        'iat',
        'jti',
        'client_id'
    ];
    if (options?.requireDPoP || scheme === 'dpop' || request.headers.has('dpop')) {
        requiredClaims.push('cnf');
    }
    const { claims } = await validateJwt(accessToken, checkSigningAlgorithm.bind(undefined, undefined, SUPPORTED_JWS_ALGS), getPublicSigKeyFromIssuerJwksUri.bind(undefined, as, options), getClockSkew(options), getClockTolerance(options)).then(checkJwtType.bind(undefined, 'at+jwt')).then(validatePresence.bind(undefined, requiredClaims)).then(validateIssuer.bind(undefined, as.issuer)).then(validateAudience.bind(undefined, expectedAudience));
    for (const claim of [
        'client_id',
        'jti',
        'sub'
    ]){
        if (typeof claims[claim] !== 'string') {
            throw new OPE(`unexpected JWT "${claim}" claim type`);
        }
    }
    if ('cnf' in claims) {
        if (!isJsonObject(claims.cnf)) {
            throw new OPE('unexpected JWT "cnf" (confirmation) claim value');
        }
        const { 0: cnf, length } = Object.keys(claims.cnf);
        if (length) {
            if (length !== 1) {
                throw new UnsupportedOperationError('multiple confirmation claims are not supported');
            }
            if (cnf !== 'jkt') {
                throw new UnsupportedOperationError('unsupported JWT Confirmation method');
            }
        }
    }
    if (options?.requireDPoP || scheme === 'dpop' || claims.cnf?.jkt !== undefined || request.headers.has('dpop')) {
        await validateDPoP(as, request, accessToken, claims, options);
    }
    return claims;
}
const experimentalCustomFetch = customFetch;
const experimental_customFetch = customFetch;
const experimentalUseMtlsAlias = useMtlsAlias;
const experimental_useMtlsAlias = useMtlsAlias;
const experimental_validateDetachedSignatureResponse = validateDetachedSignatureResponse;
const experimental_validateJwtAccessToken = validateJwtAccessToken;

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/env.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "detectOrigin": ()=>detectOrigin,
    "reqWithEnvUrl": ()=>reqWithEnvUrl,
    "setEnvDefaults": ()=>setEnvDefaults
});
function setEnvDefaults(config) {
    config.secret ?? (config.secret = process.env.AUTH_SECRET ?? process.env.NEXTAUTH_SECRET);
    config.trustHost ?? (config.trustHost = !!(process.env.AUTH_URL ?? process.env.NEXTAUTH_URL ?? process.env.AUTH_TRUST_HOST ?? process.env.VERCEL ?? ("TURBOPACK compile-time value", "development") !== "production"));
    config.redirectProxyUrl ?? (config.redirectProxyUrl = process.env.AUTH_REDIRECT_PROXY_URL);
    config.providers = config.providers.map((p)=>{
        const finalProvider = typeof p === "function" ? p({}) : p;
        if (finalProvider.type === "oauth" || finalProvider.type === "oidc") {
            const ID = finalProvider.id.toUpperCase();
            finalProvider.clientId ?? (finalProvider.clientId = process.env[`AUTH_${ID}_ID`]);
            finalProvider.clientSecret ?? (finalProvider.clientSecret = process.env[`AUTH_${ID}_SECRET`]);
            if (finalProvider.type === "oidc") {
                finalProvider.issuer ?? (finalProvider.issuer = process.env[`AUTH_${ID}_ISSUER`]);
            }
        }
        return finalProvider;
    });
}
function detectOrigin(h) {
    const url = process.env.AUTH_URL ?? process.env.NEXTAUTH_URL;
    if (url) return new URL(url);
    const host = h.get("x-forwarded-host") ?? h.get("host");
    const protocol = h.get("x-forwarded-proto") === "http" ? "http" : "https";
    return new URL(`${protocol}://${host}`);
}
function reqWithEnvUrl(req) {
    const url = process.env.AUTH_URL ?? process.env.NEXTAUTH_URL;
    if (!url) return req;
    const base = new URL(url).origin;
    // REVIEW: Bug in Next.js?: TypeError: next_dist_server_web_exports_next_request__WEBPACK_IMPORTED_MODULE_0__ is not a constructor
    // return new NextRequest(new URL(nonBase, base), req)
    const _url = req.nextUrl.clone();
    _url.href = req.nextUrl.href.replace(req.nextUrl.origin, base);
    const _req = new Request(_url, req);
    _req.nextUrl = _url;
    return _req;
}

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "initAuth": ()=>initAuth
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/headers.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/env.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
/** Server-side method to read the session. */ async function getSession(headers, config) {
    const origin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["detectOrigin"])(headers);
    const request = new Request(`${origin}/session`, {
        headers: {
            cookie: headers.get("cookie") ?? ""
        }
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Auth"])(request, {
        ...config,
        callbacks: {
            ...config.callbacks,
            // Since we are server-side, we don't need to filter out the session data
            // See https://authjs.dev/guides/upgrade-to-v5/v5#authenticating-server-side
            // TODO: Taint the session data to prevent accidental leakage to the client
            // https://react.devreference/nextjs/react/experimental_taintObjectReference
            async session (...args) {
                const session = // If the user defined a custom session callback, use that instead
                await config.callbacks?.session?.(...args) ?? args[0].session;
                const user = args[0].user ?? args[0].token;
                return {
                    user,
                    ...session
                };
            }
        }
    });
}
function isReqWrapper(arg) {
    return typeof arg === "function";
}
function initAuth(config) {
    return (...args)=>{
        if (!args.length) {
            // React Server Components
            return getSession((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["headers"])(), config).then((r)=>r.json());
        }
        if (args[0] instanceof Request) {
            // middleare.ts
            // export { auth as default } from "auth"
            const req = args[0];
            const ev = args[1];
            return handleAuth([
                req,
                ev
            ], config);
        }
        if (isReqWrapper(args[0])) {
            // middleware.ts/router.ts
            // import { auth } from "auth"
            // export default auth((req) => { console.log(req.auth) }})
            const userMiddlewareOrRoute = args[0];
            return async (...args)=>{
                return handleAuth(args, config, userMiddlewareOrRoute);
            };
        }
        // API Routes, getServerSideProps
        const request = "req" in args[0] ? args[0].req : args[0];
        const response = "res" in args[0] ? args[0].res : args[1];
        return getSession(// @ts-expect-error
        new Headers(request.headers), config).then(async (authResponse)=>{
            const auth = await authResponse.json();
            for (const cookie of authResponse.headers.getSetCookie())response.headers.append("set-cookie", cookie);
            return auth;
        });
    };
}
async function handleAuth(args, config, userMiddlewareOrRoute) {
    const request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["reqWithEnvUrl"])(args[0]);
    const sessionResponse = await getSession(request.headers, config);
    const auth = await sessionResponse.json();
    let authorized = true;
    if (config.callbacks?.authorized) {
        authorized = await config.callbacks.authorized({
            request,
            auth
        });
    }
    let response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].next?.();
    if (authorized instanceof Response) {
        // User returned a custom response, like redirecting to a page or 401, respect it
        response = authorized;
        const redirect = authorized.headers.get("Location");
        const { pathname } = request.nextUrl;
        // If the user is redirecting to the same NextAuth.js action path as the current request,
        // don't allow the redirect to prevent an infinite loop
        if (redirect && isSameAuthAction(pathname, new URL(redirect).pathname, config)) {
            authorized = true;
        }
    } else if (userMiddlewareOrRoute) {
        // Execute user's middleware/handler with the augmented request
        const augmentedReq = request;
        augmentedReq.auth = auth;
        response = // @ts-expect-error
        await userMiddlewareOrRoute(augmentedReq, args[1]) ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].next();
    } else if (!authorized) {
        const signInPage = config.pages?.signIn ?? "/api/auth/signin";
        if (request.nextUrl.pathname !== signInPage) {
            // Redirect to signin page by default if not authorized
            const signInUrl = request.nextUrl.clone();
            signInUrl.pathname = signInPage;
            signInUrl.searchParams.set("callbackUrl", request.nextUrl.href);
            response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].redirect(signInUrl);
        }
    }
    const finalResponse = new Response(response?.body, response);
    // Preserve cookies from the session response
    for (const cookie of sessionResponse.headers.getSetCookie())finalResponse.headers.append("set-cookie", cookie);
    return finalResponse;
}
function isSameAuthAction(requestPath, redirectPath, config) {
    const action = redirectPath.replace(`${requestPath}/`, "");
    const pages = Object.values(config.pages ?? {});
    return (actions.has(action) || pages.includes(redirectPath)) && redirectPath === requestPath;
}
const actions = new Set([
    "providers",
    "session",
    "csrf",
    "signin",
    "signout",
    "callback",
    "verify-request",
    "error"
]);

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/actions.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "signIn": ()=>signIn,
    "signOut": ()=>signOut,
    "update": ()=>update
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/lib/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/headers.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/env.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
async function signIn(provider, options = {}, authorizationParams, config) {
    const headers = new Headers((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["headers"])());
    const { redirect: shouldRedirect = true, redirectTo, ...rest } = options instanceof FormData ? Object.fromEntries(options) : options;
    const callbackUrl = redirectTo?.toString() ?? headers.get("Referer") ?? "/";
    const base = authUrl((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["detectOrigin"])(headers), "signin");
    if (!provider) {
        const url = `${base}?${new URLSearchParams({
            callbackUrl
        })}`;
        if (shouldRedirect) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["redirect"])(url);
        return url;
    }
    let url = `${base}/${provider}?${new URLSearchParams(authorizationParams)}`;
    let foundProvider = undefined;
    for (const _provider of config.providers){
        const { id } = typeof _provider === "function" ? _provider?.() : _provider;
        if (id === provider) {
            foundProvider = id;
            break;
        }
    }
    if (!foundProvider) {
        const url = `${base}?${new URLSearchParams({
            callbackUrl
        })}`;
        if (shouldRedirect) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["redirect"])(url);
        return url;
    }
    if (foundProvider === "credentials") {
        url = url.replace("signin", "callback");
    }
    headers.set("Content-Type", "application/x-www-form-urlencoded");
    const body = new URLSearchParams({
        ...rest,
        callbackUrl
    });
    const req = new Request(url, {
        method: "POST",
        headers,
        body
    });
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Auth"])(req, {
        ...config,
        raw: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["raw"],
        skipCSRFCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["skipCSRFCheck"]
    });
    for (const c of res?.cookies ?? [])(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cookies"])().set(c.name, c.value, c.options);
    if (shouldRedirect) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["redirect"])(res.redirect);
    return res.redirect;
}
async function signOut(options, config) {
    const headers = new Headers((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["headers"])());
    headers.set("Content-Type", "application/x-www-form-urlencoded");
    const url = authUrl((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["detectOrigin"])(headers), "signout");
    const callbackUrl = options?.redirectTo ?? headers.get("Referer") ?? "/";
    const body = new URLSearchParams({
        callbackUrl
    });
    const req = new Request(url, {
        method: "POST",
        headers,
        body
    });
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Auth"])(req, {
        ...config,
        raw: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["raw"],
        skipCSRFCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["skipCSRFCheck"]
    });
    for (const c of res?.cookies ?? [])(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cookies"])().set(c.name, c.value, c.options);
    if (options?.redirect ?? true) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["redirect"])(res.redirect);
    return res;
}
async function update(data, config) {
    const headers = new Headers((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["headers"])());
    headers.set("Content-Type", "application/json");
    const url = authUrl((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["detectOrigin"])(headers), "session");
    const body = JSON.stringify({
        data
    });
    const req = new Request(url, {
        method: "POST",
        headers,
        body
    });
    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Auth"])(req, {
        ...config,
        raw: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["raw"],
        skipCSRFCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["skipCSRFCheck"]
    });
    for (const c of res?.cookies ?? [])(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cookies"])().set(c.name, c.value, c.options);
    return res.body;
}
/** Determine an action's URL */ function authUrl(base, action) {
    let pathname;
    if (base.pathname === "/") pathname ?? (pathname = `/api/auth/${action}`);
    else pathname ?? (pathname = `${base.pathname}/${action}`);
    return new URL(pathname, base.origin);
}

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/index.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

/**
 * _If you are looking to migrate from v4, visit the [Upgrade Guide (v5)](https://authjs.dev/guides/upgrade-to-v5)._
 *
 * ## Installation
 *
 * ```bash npm2yarn
 * npm install next-auth@beta
 * ```
 *
 * ## Environment variable inferrence
 *
 * `NEXTAUTH_URL` and `NEXTAUTH_SECRET` have been inferred since v4.
 *
 * Since NextAuth.js v5 can also automatically infer environment variables that are prefiexed with `AUTH_`.
 *
 * For example `AUTH_GITHUB_ID` and `AUTH_GITHUB_SECRET` will be used as the `clientId` and `clientSecret` options for the GitHub provider.
 *
 * :::tip
 * The environment variable name inferring has the following format for OAuth providers: `AUTH_{PROVIDER}_{ID|SECRET}`.
 *
 * `PROVIDER` is the uppercase snake case version of the provider's id, followed by either `ID` or `SECRET` respectively.
 * :::
 *
 * `AUTH_SECRET` and `AUTH_URL` are also aliased for `NEXTAUTH_SECRET` and `NEXTAUTH_URL` for consistency.
 *
 * To add social login to your app, the configuration becomes:
 *
 * ```ts title="auth.ts"
 * import NextAuth from "next-auth"
 * import GitHub from "next-auth/providers/github"
 * export const { handlers, auth } = NextAuth({ providers: [ GitHub ] })
 * ```
 *
 * And the `.env.local` file:
 *
 * ```sh title=".env.local"
 * AUTH_GITHUB_ID=...
 * AUTH_GITHUB_SECRET=...
 * AUTH_SECRET=...
 * ```
 *
 * :::tip
 * In production, `AUTH_SECRET` is a required environment variable - if not set, NextAuth.js will throw an error. See [MissingSecretError](https://authjs.dev/reference/core/errors#missingsecret) for more details.
 * :::
 *
 * If you need to override the default values for a provider, you can still call it as a function `GitHub({...})` as before.
 *
 * @module next-auth
 */ __turbopack_esm__({
    "default": ()=>NextAuth
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/env.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/actions.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
function NextAuth(config) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["setEnvDefaults"])(config);
    const httpHandler = (req)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Auth"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["reqWithEnvUrl"])(req), config);
    return {
        handlers: {
            GET: httpHandler,
            POST: httpHandler
        },
        // @ts-expect-error
        auth: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["initAuth"])(config),
        signIn: (provider, options, authorizationParams)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["signIn"])(provider, options, authorizationParams, config);
        },
        signOut: (options)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["signOut"])(options, config);
        },
        update: (data)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["update"])(data, config);
        }
    };
}

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/index.js [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$env$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/env.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$lib$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/lib/actions.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$errors$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/errors.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/index.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
;
;

})()),
"[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$auth$2b$core$40$0$2e$18$2e$4$2f$node_modules$2f40$auth$2f$core$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@auth+core@0.18.4/node_modules/@auth/core/providers/credentials.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$5$2e$0$2e$0$2d$beta$2e$4_next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-auth@5.0.0-beta.4_next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1__react@18.3.1/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/core.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

;
(function(root, factory) {
    if (typeof exports === "object") {
        // CommonJS
        module.exports = exports = factory();
    } else if (typeof define === "function" && define.amd) {
        // AMD
        ((r)=>r !== undefined && __turbopack_export_value__(r))(factory());
    } else {
        // Global (browser)
        root.CryptoJS = factory();
    }
})(this, function() {
    /*globals window, global, require*/ /**
	 * CryptoJS core components.
	 */ var CryptoJS = CryptoJS || function(Math1, undefined) {
        var crypto;
        // Native crypto from window (Browser)
        if (typeof window !== 'undefined' && window.crypto) {
            crypto = window.crypto;
        }
        // Native crypto in web worker (Browser)
        if (typeof self !== 'undefined' && self.crypto) {
            crypto = self.crypto;
        }
        // Native crypto from worker
        if (typeof globalThis !== 'undefined' && globalThis.crypto) {
            crypto = globalThis.crypto;
        }
        // Native (experimental IE 11) crypto from window (Browser)
        if (!crypto && typeof window !== 'undefined' && window.msCrypto) {
            crypto = window.msCrypto;
        }
        // Native crypto from global (NodeJS)
        if (!crypto && typeof global !== 'undefined' && global.crypto) {
            crypto = global.crypto;
        }
        // Native crypto import via require (NodeJS)
        if (!crypto && typeof require === 'function') {
            try {
                crypto = require("crypto");
            } catch (err) {}
        }
        /*
	     * Cryptographically secure pseudorandom number generator
	     *
	     * As Math.random() is cryptographically not safe to use
	     */ var cryptoSecureRandomInt = function() {
            if (crypto) {
                // Use getRandomValues method (Browser)
                if (typeof crypto.getRandomValues === 'function') {
                    try {
                        return crypto.getRandomValues(new Uint32Array(1))[0];
                    } catch (err) {}
                }
                // Use randomBytes method (NodeJS)
                if (typeof crypto.randomBytes === 'function') {
                    try {
                        return crypto.randomBytes(4).readInt32LE();
                    } catch (err) {}
                }
            }
            throw new Error('Native crypto module could not be used to get secure random number.');
        };
        /*
	     * Local polyfill of Object.create

	     */ var create = Object.create || function() {
            function F() {}
            return function(obj) {
                var subtype;
                F.prototype = obj;
                subtype = new F();
                F.prototype = null;
                return subtype;
            };
        }();
        /**
	     * CryptoJS namespace.
	     */ var C = {};
        /**
	     * Library namespace.
	     */ var C_lib = C.lib = {};
        /**
	     * Base object for prototypal inheritance.
	     */ var Base = C_lib.Base = function() {
            return {
                /**
	             * Creates a new object that inherits from this object.
	             *
	             * @param {Object} overrides Properties to copy into the new object.
	             *
	             * @return {Object} The new object.
	             *
	             * @static
	             *
	             * @example
	             *
	             *     var MyType = CryptoJS.lib.Base.extend({
	             *         field: 'value',
	             *
	             *         method: function () {
	             *         }
	             *     });
	             */ extend: function(overrides) {
                    // Spawn
                    var subtype = create(this);
                    // Augment
                    if (overrides) {
                        subtype.mixIn(overrides);
                    }
                    // Create default initializer
                    if (!subtype.hasOwnProperty('init') || this.init === subtype.init) {
                        subtype.init = function() {
                            subtype.$super.init.apply(this, arguments);
                        };
                    }
                    // Initializer's prototype is the subtype object
                    subtype.init.prototype = subtype;
                    // Reference supertype
                    subtype.$super = this;
                    return subtype;
                },
                /**
	             * Extends this object and runs the init method.
	             * Arguments to create() will be passed to init().
	             *
	             * @return {Object} The new object.
	             *
	             * @static
	             *
	             * @example
	             *
	             *     var instance = MyType.create();
	             */ create: function() {
                    var instance = this.extend();
                    instance.init.apply(instance, arguments);
                    return instance;
                },
                /**
	             * Initializes a newly created object.
	             * Override this method to add some logic when your objects are created.
	             *
	             * @example
	             *
	             *     var MyType = CryptoJS.lib.Base.extend({
	             *         init: function () {
	             *             // ...
	             *         }
	             *     });
	             */ init: function() {},
                /**
	             * Copies properties into this object.
	             *
	             * @param {Object} properties The properties to mix in.
	             *
	             * @example
	             *
	             *     MyType.mixIn({
	             *         field: 'value'
	             *     });
	             */ mixIn: function(properties) {
                    for(var propertyName in properties){
                        if (properties.hasOwnProperty(propertyName)) {
                            this[propertyName] = properties[propertyName];
                        }
                    }
                    // IE won't copy toString using the loop above
                    if (properties.hasOwnProperty('toString')) {
                        this.toString = properties.toString;
                    }
                },
                /**
	             * Creates a copy of this object.
	             *
	             * @return {Object} The clone.
	             *
	             * @example
	             *
	             *     var clone = instance.clone();
	             */ clone: function() {
                    return this.init.prototype.extend(this);
                }
            };
        }();
        /**
	     * An array of 32-bit words.
	     *
	     * @property {Array} words The array of 32-bit words.
	     * @property {number} sigBytes The number of significant bytes in this word array.
	     */ var WordArray = C_lib.WordArray = Base.extend({
            /**
	         * Initializes a newly created word array.
	         *
	         * @param {Array} words (Optional) An array of 32-bit words.
	         * @param {number} sigBytes (Optional) The number of significant bytes in the words.
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.lib.WordArray.create();
	         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
	         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
	         */ init: function(words, sigBytes) {
                words = this.words = words || [];
                if (sigBytes != undefined) {
                    this.sigBytes = sigBytes;
                } else {
                    this.sigBytes = words.length * 4;
                }
            },
            /**
	         * Converts this word array to a string.
	         *
	         * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
	         *
	         * @return {string} The stringified word array.
	         *
	         * @example
	         *
	         *     var string = wordArray + '';
	         *     var string = wordArray.toString();
	         *     var string = wordArray.toString(CryptoJS.enc.Utf8);
	         */ toString: function(encoder) {
                return (encoder || Hex).stringify(this);
            },
            /**
	         * Concatenates a word array to this word array.
	         *
	         * @param {WordArray} wordArray The word array to append.
	         *
	         * @return {WordArray} This word array.
	         *
	         * @example
	         *
	         *     wordArray1.concat(wordArray2);
	         */ concat: function(wordArray) {
                // Shortcuts
                var thisWords = this.words;
                var thatWords = wordArray.words;
                var thisSigBytes = this.sigBytes;
                var thatSigBytes = wordArray.sigBytes;
                // Clamp excess bits
                this.clamp();
                // Concat
                if (thisSigBytes % 4) {
                    // Copy one byte at a time
                    for(var i = 0; i < thatSigBytes; i++){
                        var thatByte = thatWords[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                        thisWords[thisSigBytes + i >>> 2] |= thatByte << 24 - (thisSigBytes + i) % 4 * 8;
                    }
                } else {
                    // Copy one word at a time
                    for(var j = 0; j < thatSigBytes; j += 4){
                        thisWords[thisSigBytes + j >>> 2] = thatWords[j >>> 2];
                    }
                }
                this.sigBytes += thatSigBytes;
                // Chainable
                return this;
            },
            /**
	         * Removes insignificant bits.
	         *
	         * @example
	         *
	         *     wordArray.clamp();
	         */ clamp: function() {
                // Shortcuts
                var words = this.words;
                var sigBytes = this.sigBytes;
                // Clamp
                words[sigBytes >>> 2] &= 0xffffffff << 32 - sigBytes % 4 * 8;
                words.length = Math1.ceil(sigBytes / 4);
            },
            /**
	         * Creates a copy of this word array.
	         *
	         * @return {WordArray} The clone.
	         *
	         * @example
	         *
	         *     var clone = wordArray.clone();
	         */ clone: function() {
                var clone = Base.clone.call(this);
                clone.words = this.words.slice(0);
                return clone;
            },
            /**
	         * Creates a word array filled with random bytes.
	         *
	         * @param {number} nBytes The number of random bytes to generate.
	         *
	         * @return {WordArray} The random word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.lib.WordArray.random(16);
	         */ random: function(nBytes) {
                var words = [];
                for(var i = 0; i < nBytes; i += 4){
                    words.push(cryptoSecureRandomInt());
                }
                return new WordArray.init(words, nBytes);
            }
        });
        /**
	     * Encoder namespace.
	     */ var C_enc = C.enc = {};
        /**
	     * Hex encoding strategy.
	     */ var Hex = C_enc.Hex = {
            /**
	         * Converts a word array to a hex string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The hex string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
	         */ stringify: function(wordArray) {
                // Shortcuts
                var words = wordArray.words;
                var sigBytes = wordArray.sigBytes;
                // Convert
                var hexChars = [];
                for(var i = 0; i < sigBytes; i++){
                    var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                    hexChars.push((bite >>> 4).toString(16));
                    hexChars.push((bite & 0x0f).toString(16));
                }
                return hexChars.join('');
            },
            /**
	         * Converts a hex string to a word array.
	         *
	         * @param {string} hexStr The hex string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
	         */ parse: function(hexStr) {
                // Shortcut
                var hexStrLength = hexStr.length;
                // Convert
                var words = [];
                for(var i = 0; i < hexStrLength; i += 2){
                    words[i >>> 3] |= parseInt(hexStr.substr(i, 2), 16) << 24 - i % 8 * 4;
                }
                return new WordArray.init(words, hexStrLength / 2);
            }
        };
        /**
	     * Latin1 encoding strategy.
	     */ var Latin1 = C_enc.Latin1 = {
            /**
	         * Converts a word array to a Latin1 string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The Latin1 string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
	         */ stringify: function(wordArray) {
                // Shortcuts
                var words = wordArray.words;
                var sigBytes = wordArray.sigBytes;
                // Convert
                var latin1Chars = [];
                for(var i = 0; i < sigBytes; i++){
                    var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                    latin1Chars.push(String.fromCharCode(bite));
                }
                return latin1Chars.join('');
            },
            /**
	         * Converts a Latin1 string to a word array.
	         *
	         * @param {string} latin1Str The Latin1 string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
	         */ parse: function(latin1Str) {
                // Shortcut
                var latin1StrLength = latin1Str.length;
                // Convert
                var words = [];
                for(var i = 0; i < latin1StrLength; i++){
                    words[i >>> 2] |= (latin1Str.charCodeAt(i) & 0xff) << 24 - i % 4 * 8;
                }
                return new WordArray.init(words, latin1StrLength);
            }
        };
        /**
	     * UTF-8 encoding strategy.
	     */ var Utf8 = C_enc.Utf8 = {
            /**
	         * Converts a word array to a UTF-8 string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The UTF-8 string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
	         */ stringify: function(wordArray) {
                try {
                    return decodeURIComponent(escape(Latin1.stringify(wordArray)));
                } catch (e) {
                    throw new Error('Malformed UTF-8 data');
                }
            },
            /**
	         * Converts a UTF-8 string to a word array.
	         *
	         * @param {string} utf8Str The UTF-8 string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
	         */ parse: function(utf8Str) {
                return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
            }
        };
        /**
	     * Abstract buffered block algorithm template.
	     *
	     * The property blockSize must be implemented in a concrete subtype.
	     *
	     * @property {number} _minBufferSize The number of blocks that should be kept unprocessed in the buffer. Default: 0
	     */ var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm = Base.extend({
            /**
	         * Resets this block algorithm's data buffer to its initial state.
	         *
	         * @example
	         *
	         *     bufferedBlockAlgorithm.reset();
	         */ reset: function() {
                // Initial values
                this._data = new WordArray.init();
                this._nDataBytes = 0;
            },
            /**
	         * Adds new data to this block algorithm's buffer.
	         *
	         * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
	         *
	         * @example
	         *
	         *     bufferedBlockAlgorithm._append('data');
	         *     bufferedBlockAlgorithm._append(wordArray);
	         */ _append: function(data) {
                // Convert string to WordArray, else assume WordArray already
                if (typeof data == 'string') {
                    data = Utf8.parse(data);
                }
                // Append
                this._data.concat(data);
                this._nDataBytes += data.sigBytes;
            },
            /**
	         * Processes available data blocks.
	         *
	         * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
	         *
	         * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
	         *
	         * @return {WordArray} The processed data.
	         *
	         * @example
	         *
	         *     var processedData = bufferedBlockAlgorithm._process();
	         *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
	         */ _process: function(doFlush) {
                var processedWords;
                // Shortcuts
                var data = this._data;
                var dataWords = data.words;
                var dataSigBytes = data.sigBytes;
                var blockSize = this.blockSize;
                var blockSizeBytes = blockSize * 4;
                // Count blocks ready
                var nBlocksReady = dataSigBytes / blockSizeBytes;
                if (doFlush) {
                    // Round up to include partial blocks
                    nBlocksReady = Math1.ceil(nBlocksReady);
                } else {
                    // Round down to include only full blocks,
                    // less the number of blocks that must remain in the buffer
                    nBlocksReady = Math1.max((nBlocksReady | 0) - this._minBufferSize, 0);
                }
                // Count words ready
                var nWordsReady = nBlocksReady * blockSize;
                // Count bytes ready
                var nBytesReady = Math1.min(nWordsReady * 4, dataSigBytes);
                // Process blocks
                if (nWordsReady) {
                    for(var offset = 0; offset < nWordsReady; offset += blockSize){
                        // Perform concrete-algorithm logic
                        this._doProcessBlock(dataWords, offset);
                    }
                    // Remove processed words
                    processedWords = dataWords.splice(0, nWordsReady);
                    data.sigBytes -= nBytesReady;
                }
                // Return processed words
                return new WordArray.init(processedWords, nBytesReady);
            },
            /**
	         * Creates a copy of this object.
	         *
	         * @return {Object} The clone.
	         *
	         * @example
	         *
	         *     var clone = bufferedBlockAlgorithm.clone();
	         */ clone: function() {
                var clone = Base.clone.call(this);
                clone._data = this._data.clone();
                return clone;
            },
            _minBufferSize: 0
        });
        /**
	     * Abstract hasher template.
	     *
	     * @property {number} blockSize The number of 32-bit words this hasher operates on. Default: 16 (512 bits)
	     */ var Hasher = C_lib.Hasher = BufferedBlockAlgorithm.extend({
            /**
	         * Configuration options.
	         */ cfg: Base.extend(),
            /**
	         * Initializes a newly created hasher.
	         *
	         * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
	         *
	         * @example
	         *
	         *     var hasher = CryptoJS.algo.SHA256.create();
	         */ init: function(cfg) {
                // Apply config defaults
                this.cfg = this.cfg.extend(cfg);
                // Set initial values
                this.reset();
            },
            /**
	         * Resets this hasher to its initial state.
	         *
	         * @example
	         *
	         *     hasher.reset();
	         */ reset: function() {
                // Reset data buffer
                BufferedBlockAlgorithm.reset.call(this);
                // Perform concrete-hasher logic
                this._doReset();
            },
            /**
	         * Updates this hasher with a message.
	         *
	         * @param {WordArray|string} messageUpdate The message to append.
	         *
	         * @return {Hasher} This hasher.
	         *
	         * @example
	         *
	         *     hasher.update('message');
	         *     hasher.update(wordArray);
	         */ update: function(messageUpdate) {
                // Append
                this._append(messageUpdate);
                // Update the hash
                this._process();
                // Chainable
                return this;
            },
            /**
	         * Finalizes the hash computation.
	         * Note that the finalize operation is effectively a destructive, read-once operation.
	         *
	         * @param {WordArray|string} messageUpdate (Optional) A final message update.
	         *
	         * @return {WordArray} The hash.
	         *
	         * @example
	         *
	         *     var hash = hasher.finalize();
	         *     var hash = hasher.finalize('message');
	         *     var hash = hasher.finalize(wordArray);
	         */ finalize: function(messageUpdate) {
                // Final message update
                if (messageUpdate) {
                    this._append(messageUpdate);
                }
                // Perform concrete-hasher logic
                var hash = this._doFinalize();
                return hash;
            },
            blockSize: 512 / 32,
            /**
	         * Creates a shortcut function to a hasher's object interface.
	         *
	         * @param {Hasher} hasher The hasher to create a helper for.
	         *
	         * @return {Function} The shortcut function.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
	         */ _createHelper: function(hasher) {
                return function(message, cfg) {
                    return new hasher.init(cfg).finalize(message);
                };
            },
            /**
	         * Creates a shortcut function to the HMAC's object interface.
	         *
	         * @param {Hasher} hasher The hasher to use in this HMAC helper.
	         *
	         * @return {Function} The shortcut function.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
	         */ _createHmacHelper: function(hasher) {
                return function(message, key) {
                    return new C_algo.HMAC.init(hasher, key).finalize(message);
                };
            }
        });
        /**
	     * Algorithm namespace.
	     */ var C_algo = C.algo = {};
        return C;
    }(Math);
    return CryptoJS;
});

}.call(this) }),
"[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/enc-hex.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

;
(function(root, factory) {
    if (typeof exports === "object") {
        // CommonJS
        module.exports = exports = factory(__turbopack_require__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/core.js [app-rsc] (ecmascript)"));
    } else if (typeof define === "function" && define.amd) {
        // AMD
        ((r)=>r !== undefined && __turbopack_export_value__(r))(factory(__turbopack_require__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/core.js [app-rsc] (ecmascript)")));
    } else {
        // Global (browser)
        factory(root.CryptoJS);
    }
})(this, function(CryptoJS) {
    return CryptoJS.enc.Hex;
});

}.call(this) }),
"[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/sha1.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

;
(function(root, factory) {
    if (typeof exports === "object") {
        // CommonJS
        module.exports = exports = factory(__turbopack_require__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/core.js [app-rsc] (ecmascript)"));
    } else if (typeof define === "function" && define.amd) {
        // AMD
        ((r)=>r !== undefined && __turbopack_export_value__(r))(factory(__turbopack_require__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/core.js [app-rsc] (ecmascript)")));
    } else {
        // Global (browser)
        factory(root.CryptoJS);
    }
})(this, function(CryptoJS) {
    (function() {
        // Shortcuts
        var C = CryptoJS;
        var C_lib = C.lib;
        var WordArray = C_lib.WordArray;
        var Hasher = C_lib.Hasher;
        var C_algo = C.algo;
        // Reusable object
        var W = [];
        /**
	     * SHA-1 hash algorithm.
	     */ var SHA1 = C_algo.SHA1 = Hasher.extend({
            _doReset: function() {
                this._hash = new WordArray.init([
                    0x67452301,
                    0xefcdab89,
                    0x98badcfe,
                    0x10325476,
                    0xc3d2e1f0
                ]);
            },
            _doProcessBlock: function(M, offset) {
                // Shortcut
                var H = this._hash.words;
                // Working variables
                var a = H[0];
                var b = H[1];
                var c = H[2];
                var d = H[3];
                var e = H[4];
                // Computation
                for(var i = 0; i < 80; i++){
                    if (i < 16) {
                        W[i] = M[offset + i] | 0;
                    } else {
                        var n = W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16];
                        W[i] = n << 1 | n >>> 31;
                    }
                    var t = (a << 5 | a >>> 27) + e + W[i];
                    if (i < 20) {
                        t += (b & c | ~b & d) + 0x5a827999;
                    } else if (i < 40) {
                        t += (b ^ c ^ d) + 0x6ed9eba1;
                    } else if (i < 60) {
                        t += (b & c | b & d | c & d) - 0x70e44324;
                    } else /* if (i < 80) */ {
                        t += (b ^ c ^ d) - 0x359d3e2a;
                    }
                    e = d;
                    d = c;
                    c = b << 30 | b >>> 2;
                    b = a;
                    a = t;
                }
                // Intermediate hash value
                H[0] = H[0] + a | 0;
                H[1] = H[1] + b | 0;
                H[2] = H[2] + c | 0;
                H[3] = H[3] + d | 0;
                H[4] = H[4] + e | 0;
            },
            _doFinalize: function() {
                // Shortcuts
                var data = this._data;
                var dataWords = data.words;
                var nBitsTotal = this._nDataBytes * 8;
                var nBitsLeft = data.sigBytes * 8;
                // Add padding
                dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
                dataWords[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);
                dataWords[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
                data.sigBytes = dataWords.length * 4;
                // Hash final blocks
                this._process();
                // Return final computed hash
                return this._hash;
            },
            clone: function() {
                var clone = Hasher.clone.call(this);
                clone._hash = this._hash.clone();
                return clone;
            }
        });
        /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA1('message');
	     *     var hash = CryptoJS.SHA1(wordArray);
	     */ C.SHA1 = Hasher._createHelper(SHA1);
        /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA1(message, key);
	     */ C.HmacSHA1 = Hasher._createHmacHelper(SHA1);
    })();
    return CryptoJS.SHA1;
});

}.call(this) }),
"[project]/node_modules/.pnpm/@upstash+redis@1.31.6/node_modules/@upstash/redis/chunk-2DN6UAHL.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "a": ()=>Se,
    "b": ()=>ve,
    "c": ()=>qC
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$crypto$2d$js$40$4$2e$2$2e$0$2f$node_modules$2f$crypto$2d$js$2f$enc$2d$hex$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/enc-hex.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$crypto$2d$js$40$4$2e$2$2e$0$2f$node_modules$2f$crypto$2d$js$2f$sha1$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/crypto-js@4.2.0/node_modules/crypto-js/sha1.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
var u = class extends Error {
    constructor(n){
        super(n), this.name = "UpstashError";
    }
};
var Se = class {
    baseUrl;
    headers;
    options;
    retry;
    constructor(n){
        this.options = {
            backend: n.options?.backend,
            agent: n.agent,
            responseEncoding: n.responseEncoding ?? "base64",
            cache: n.cache,
            signal: n.signal,
            keepAlive: n.keepAlive ?? !0
        }, this.baseUrl = n.baseUrl.replace(/\/$/, ""), this.headers = {
            "Content-Type": "application/json",
            ...n.headers
        }, this.options.responseEncoding === "base64" && (this.headers["Upstash-Encoding"] = "base64"), typeof n?.retry == "boolean" && n?.retry === !1 ? this.retry = {
            attempts: 1,
            backoff: ()=>0
        } : this.retry = {
            attempts: n?.retry?.retries ?? 5,
            backoff: n?.retry?.backoff ?? ((t)=>Math.exp(t) * 50)
        };
    }
    mergeTelemetry(n) {
        function t(o, m, r) {
            return r && (o[m] ? o[m] = [
                o[m],
                r
            ].join(",") : o[m] = r), o;
        }
        this.headers = t(this.headers, "Upstash-Telemetry-Runtime", n.runtime), this.headers = t(this.headers, "Upstash-Telemetry-Platform", n.platform), this.headers = t(this.headers, "Upstash-Telemetry-Sdk", n.sdk);
    }
    async request(n) {
        let t = {
            cache: this.options.cache,
            method: "POST",
            headers: this.headers,
            body: JSON.stringify(n.body),
            keepalive: this.options.keepAlive,
            agent: this.options?.agent,
            signal: this.options.signal,
            backend: this.options?.backend
        }, o = null, m = null;
        for(let a = 0; a <= this.retry.attempts; a++)try {
            o = await fetch([
                this.baseUrl,
                ...n.path ?? []
            ].join("/"), t);
            break;
        } catch (i) {
            if (this.options.signal?.aborted) {
                let p = new Blob([
                    JSON.stringify({
                        result: this.options.signal.reason ?? "Aborted"
                    })
                ]), d = {
                    status: 200,
                    statusText: this.options.signal.reason ?? "Aborted"
                };
                o = new Response(p, d);
                break;
            }
            m = i, await new Promise((p)=>setTimeout(p, this.retry.backoff(a)));
        }
        if (!o) throw m ?? new Error("Exhausted all retries");
        let r = await o.json();
        if (!o.ok) throw new u(`${r.error}, command was: ${JSON.stringify(n.body)}`);
        return this.options?.responseEncoding === "base64" ? Array.isArray(r) ? r.map(({ result: i, error: p })=>({
                result: De(i),
                error: p
            })) : {
            result: De(r.result),
            error: r.error
        } : r;
    }
};
function Ee(s) {
    let n = "";
    try {
        let t = atob(s), o = t.length, m = new Uint8Array(o);
        for(let r = 0; r < o; r++)m[r] = t.charCodeAt(r);
        n = new TextDecoder().decode(m);
    } catch  {
        n = s;
    }
    return n;
}
function De(s) {
    let n;
    switch(typeof s){
        case "undefined":
            return s;
        case "number":
            {
                n = s;
                break;
            }
        case "object":
            {
                Array.isArray(s) ? n = s.map((t)=>typeof t == "string" ? Ee(t) : Array.isArray(t) ? t.map(De) : t) : n = null;
                break;
            }
        case "string":
            {
                n = s === "OK" ? "OK" : Ee(s);
                break;
            }
        default:
            break;
    }
    return n;
}
function Me(s) {
    let n = Array.isArray(s) ? s.map((t)=>{
        try {
            return Me(t);
        } catch  {
            return t;
        }
    }) : JSON.parse(s);
    return typeof n == "number" && n.toString() !== s ? s : n;
}
function Ae(s) {
    try {
        return Me(s);
    } catch  {
        return s;
    }
}
function l(s) {
    return [
        s[0],
        ...Ae(s.slice(1))
    ];
}
var Pe = (s)=>{
    switch(typeof s){
        case "string":
        case "number":
        case "boolean":
            return s;
        default:
            return JSON.stringify(s);
    }
}, e = class {
    command;
    serialize;
    deserialize;
    constructor(n, t){
        if (this.serialize = Pe, this.deserialize = typeof t?.automaticDeserialization > "u" || t.automaticDeserialization ? t?.deserialize ?? Ae : (o)=>o, this.command = n.map((o)=>this.serialize(o)), t?.latencyLogging) {
            let o = this.exec.bind(this);
            this.exec = async (m)=>{
                let r = performance.now(), a = await o(m), p = (performance.now() - r).toFixed(2);
                return console.log(`Latency for \x1B[38;2;19;185;39m${this.command[0].toString().toUpperCase()}\x1B[0m: \x1B[38;2;0;255;255m${p} ms\x1B[0m`), a;
            };
        }
    }
    async exec(n) {
        let { result: t, error: o } = await n.request({
            body: this.command
        });
        if (o) throw new u(o);
        if (typeof t > "u") throw new Error("Request did not return a result");
        return this.deserialize(t);
    }
};
var g = class extends e {
    constructor(n, t){
        super([
            "append",
            ...n
        ], t);
    }
};
var x = class extends e {
    constructor([n, t, o], m){
        let r = [
            "bitcount",
            n
        ];
        typeof t == "number" && r.push(t), typeof o == "number" && r.push(o), super(r, m);
    }
};
var f = class extends e {
    constructor(n, t){
        super([
            "bitop",
            ...n
        ], t);
    }
};
var y = class extends e {
    constructor(n, t){
        super([
            "bitpos",
            ...n
        ], t);
    }
};
var b = class extends e {
    constructor([n, t, o], m){
        super([
            "COPY",
            n,
            t,
            ...o?.replace ? [
                "REPLACE"
            ] : []
        ], {
            ...m,
            deserialize (r) {
                return r > 0 ? "COPIED" : "NOT_COPIED";
            }
        });
    }
};
var T = class extends e {
    constructor(n){
        super([
            "dbsize"
        ], n);
    }
};
var O = class extends e {
    constructor(n, t){
        super([
            "decr",
            ...n
        ], t);
    }
};
var w = class extends e {
    constructor(n, t){
        super([
            "decrby",
            ...n
        ], t);
    }
};
var D = class extends e {
    constructor(n, t){
        super([
            "del",
            ...n
        ], t);
    }
};
var A = class extends e {
    constructor(n, t){
        super([
            "echo",
            ...n
        ], t);
    }
};
var k = class extends e {
    constructor([n, t, o], m){
        super([
            "eval",
            n,
            t.length,
            ...t,
            ...o ?? []
        ], m);
    }
};
var R = class extends e {
    constructor([n, t, o], m){
        super([
            "evalsha",
            n,
            t.length,
            ...t,
            ...o ?? []
        ], m);
    }
};
var S = class extends e {
    constructor(n, t){
        super([
            "exists",
            ...n
        ], t);
    }
};
var E = class extends e {
    constructor(n, t){
        super([
            "expire",
            ...n.filter(Boolean)
        ], t);
    }
};
var M = class extends e {
    constructor(n, t){
        super([
            "expireat",
            ...n
        ], t);
    }
};
var v = class extends e {
    constructor(n, t){
        let o = [
            "flushall"
        ];
        n && n.length > 0 && n[0].async && o.push("async"), super(o, t);
    }
};
var P = class extends e {
    constructor([n], t){
        let o = [
            "flushdb"
        ];
        n?.async && o.push("async"), super(o, t);
    }
};
var I = class extends e {
    constructor([n, t, ...o], m){
        let r = [
            "geoadd",
            n
        ];
        "nx" in t && t.nx ? r.push("nx") : "xx" in t && t.xx && r.push("xx"), "ch" in t && t.ch && r.push("ch"), "latitude" in t && t.latitude && r.push(t.longitude, t.latitude, t.member), r.push(...o.flatMap(({ latitude: a, longitude: i, member: p })=>[
                i,
                a,
                p
            ])), super(r, m);
    }
};
var N = class extends e {
    constructor([n, t, o, m = "M"], r){
        super([
            "GEODIST",
            n,
            t,
            o,
            m
        ], r);
    }
};
var L = class extends e {
    constructor(n, t){
        let [o] = n, m = Array.isArray(n[1]) ? n[1] : n.slice(1);
        super([
            "GEOHASH",
            o,
            ...m
        ], t);
    }
};
var z = class extends e {
    constructor(n, t){
        let [o] = n, m = Array.isArray(n[1]) ? n[1] : n.slice(1);
        super([
            "GEOPOS",
            o,
            ...m
        ], {
            deserialize: (r)=>Ie(r),
            ...t
        });
    }
};
function Ie(s) {
    let n = [];
    for (let t of s)!t?.[0] || !t?.[1] || n.push({
        lng: parseFloat(t[0]),
        lat: parseFloat(t[1])
    });
    return n;
}
var G = class extends e {
    constructor([n, t, o, m, r], a){
        let i = [
            "GEOSEARCH",
            n
        ];
        (t.type === "FROMMEMBER" || t.type === "frommember") && i.push(t.type, t.member), (t.type === "FROMLONLAT" || t.type === "fromlonlat") && i.push(t.type, t.coordinate.lon, t.coordinate.lat), (o.type === "BYRADIUS" || o.type === "byradius") && i.push(o.type, o.radius, o.radiusType), (o.type === "BYBOX" || o.type === "bybox") && i.push(o.type, o.rect.width, o.rect.height, o.rectType), i.push(m), r?.count && i.push("COUNT", r.count.limit, ...r.count.any ? [
            "ANY"
        ] : []);
        let p = (d)=>!r?.withCoord && !r?.withDist && !r?.withHash ? d.map((c)=>{
                try {
                    return {
                        member: JSON.parse(c)
                    };
                } catch  {
                    return {
                        member: c
                    };
                }
            }) : d.map((c)=>{
                let Oe = 1, C = {};
                try {
                    C.member = JSON.parse(c[0]);
                } catch  {
                    C.member = c[0];
                }
                return r.withDist && (C.dist = parseFloat(c[Oe++])), r.withHash && (C.hash = c[Oe++].toString()), r.withCoord && (C.coord = {
                    long: parseFloat(c[Oe][0]),
                    lat: parseFloat(c[Oe][1])
                }), C;
            });
        super([
            ...i,
            ...r?.withCoord ? [
                "WITHCOORD"
            ] : [],
            ...r?.withDist ? [
                "WITHDIST"
            ] : [],
            ...r?.withHash ? [
                "WITHHASH"
            ] : []
        ], {
            deserialize: p,
            ...a
        });
    }
};
var K = class extends e {
    constructor([n, t, o, m, r, a], i){
        let p = [
            "GEOSEARCHSTORE",
            n,
            t
        ];
        (o.type === "FROMMEMBER" || o.type === "frommember") && p.push(o.type, o.member), (o.type === "FROMLONLAT" || o.type === "fromlonlat") && p.push(o.type, o.coordinate.lon, o.coordinate.lat), (m.type === "BYRADIUS" || m.type === "byradius") && p.push(m.type, m.radius, m.radiusType), (m.type === "BYBOX" || m.type === "bybox") && p.push(m.type, m.rect.width, m.rect.height, m.rectType), p.push(r), a?.count && p.push("COUNT", a.count.limit, ...a.count.any ? [
            "ANY"
        ] : []), super([
            ...p,
            ...a?.storeDist ? [
                "STOREDIST"
            ] : []
        ], i);
    }
};
var X = class extends e {
    constructor(n, t){
        super([
            "get",
            ...n
        ], t);
    }
};
var J = class extends e {
    constructor(n, t){
        super([
            "getbit",
            ...n
        ], t);
    }
};
var U = class extends e {
    constructor(n, t){
        super([
            "getdel",
            ...n
        ], t);
    }
};
var Z = class extends e {
    constructor(n, t){
        super([
            "getrange",
            ...n
        ], t);
    }
};
var B = class extends e {
    constructor(n, t){
        super([
            "getset",
            ...n
        ], t);
    }
};
var H = class extends e {
    constructor(n, t){
        super([
            "hdel",
            ...n
        ], t);
    }
};
var F = class extends e {
    constructor(n, t){
        super([
            "hexists",
            ...n
        ], t);
    }
};
var $ = class extends e {
    constructor(n, t){
        super([
            "hget",
            ...n
        ], t);
    }
};
function Ne(s) {
    if (s.length === 0) return null;
    let n = {};
    for(; s.length >= 2;){
        let t = s.shift(), o = s.shift();
        try {
            !Number.isNaN(Number(o)) && !Number.isSafeInteger(Number(o)) ? n[t] = o : n[t] = JSON.parse(o);
        } catch  {
            n[t] = o;
        }
    }
    return n;
}
var q = class extends e {
    constructor(n, t){
        super([
            "hgetall",
            ...n
        ], {
            deserialize: (o)=>Ne(o),
            ...t
        });
    }
};
var j = class extends e {
    constructor(n, t){
        super([
            "hincrby",
            ...n
        ], t);
    }
};
var Y = class extends e {
    constructor(n, t){
        super([
            "hincrbyfloat",
            ...n
        ], t);
    }
};
var V = class extends e {
    constructor([n], t){
        super([
            "hkeys",
            n
        ], t);
    }
};
var _ = class extends e {
    constructor(n, t){
        super([
            "hlen",
            ...n
        ], t);
    }
};
function Le(s, n) {
    if (n.length === 0 || n.every((o)=>o === null)) return null;
    let t = {};
    for(let o = 0; o < s.length; o++)try {
        t[s[o]] = JSON.parse(n[o]);
    } catch  {
        t[s[o]] = n[o];
    }
    return t;
}
var W = class extends e {
    constructor([n, ...t], o){
        super([
            "hmget",
            n,
            ...t
        ], {
            deserialize: (m)=>Le(t, m),
            ...o
        });
    }
};
var Q = class extends e {
    constructor([n, t], o){
        super([
            "hmset",
            n,
            ...Object.entries(t).flatMap(([m, r])=>[
                    m,
                    r
                ])
        ], o);
    }
};
function ze(s) {
    if (s.length === 0) return null;
    let n = {};
    for(; s.length >= 2;){
        let t = s.shift(), o = s.shift();
        try {
            n[t] = JSON.parse(o);
        } catch  {
            n[t] = o;
        }
    }
    return n;
}
var nn = class extends e {
    constructor(n, t){
        let o = [
            "hrandfield",
            n[0]
        ];
        typeof n[1] == "number" && o.push(n[1]), n[2] && o.push("WITHVALUES"), super(o, {
            deserialize: n[2] ? (m)=>ze(m) : t?.deserialize,
            ...t
        });
    }
};
var tn = class extends e {
    constructor([n, t, o], m){
        let r = [
            "hscan",
            n,
            t
        ];
        o?.match && r.push("match", o.match), typeof o?.count == "number" && r.push("count", o.count), super(r, {
            deserialize: l,
            ...m
        });
    }
};
var en = class extends e {
    constructor([n, t], o){
        super([
            "hset",
            n,
            ...Object.entries(t).flatMap(([m, r])=>[
                    m,
                    r
                ])
        ], o);
    }
};
var on = class extends e {
    constructor(n, t){
        super([
            "hsetnx",
            ...n
        ], t);
    }
};
var sn = class extends e {
    constructor(n, t){
        super([
            "hstrlen",
            ...n
        ], t);
    }
};
var mn = class extends e {
    constructor(n, t){
        super([
            "hvals",
            ...n
        ], t);
    }
};
var rn = class extends e {
    constructor(n, t){
        super([
            "incr",
            ...n
        ], t);
    }
};
var an = class extends e {
    constructor(n, t){
        super([
            "incrby",
            ...n
        ], t);
    }
};
var pn = class extends e {
    constructor(n, t){
        super([
            "incrbyfloat",
            ...n
        ], t);
    }
};
var dn = class extends e {
    constructor(n, t){
        super([
            "JSON.ARRAPPEND",
            ...n
        ], t);
    }
};
var cn = class extends e {
    constructor(n, t){
        super([
            "JSON.ARRINDEX",
            ...n
        ], t);
    }
};
var un = class extends e {
    constructor(n, t){
        super([
            "JSON.ARRINSERT",
            ...n
        ], t);
    }
};
var ln = class extends e {
    constructor(n, t){
        super([
            "JSON.ARRLEN",
            n[0],
            n[1] ?? "$"
        ], t);
    }
};
var hn = class extends e {
    constructor(n, t){
        super([
            "JSON.ARRPOP",
            ...n
        ], t);
    }
};
var Cn = class extends e {
    constructor(n, t){
        let o = n[1] ?? "$", m = n[2] ?? 0, r = n[3] ?? 0;
        super([
            "JSON.ARRTRIM",
            n[0],
            o,
            m,
            r
        ], t);
    }
};
var gn = class extends e {
    constructor(n, t){
        super([
            "JSON.CLEAR",
            ...n
        ], t);
    }
};
var xn = class extends e {
    constructor(n, t){
        super([
            "JSON.DEL",
            ...n
        ], t);
    }
};
var fn = class extends e {
    constructor(n, t){
        super([
            "JSON.FORGET",
            ...n
        ], t);
    }
};
var yn = class extends e {
    constructor(n, t){
        let o = [
            "JSON.GET"
        ];
        typeof n[1] == "string" ? o.push(...n) : (o.push(n[0]), n[1] && (n[1].indent && o.push("INDENT", n[1].indent), n[1].newline && o.push("NEWLINE", n[1].newline), n[1].space && o.push("SPACE", n[1].space)), o.push(...n.slice(2))), super(o, t);
    }
};
var bn = class extends e {
    constructor(n, t){
        super([
            "JSON.MGET",
            ...n[0],
            n[1]
        ], t);
    }
};
var Tn = class extends e {
    constructor(n, t){
        super([
            "JSON.NUMINCRBY",
            ...n
        ], t);
    }
};
var On = class extends e {
    constructor(n, t){
        super([
            "JSON.NUMMULTBY",
            ...n
        ], t);
    }
};
var wn = class extends e {
    constructor(n, t){
        super([
            "JSON.OBJKEYS",
            ...n
        ], t);
    }
};
var Dn = class extends e {
    constructor(n, t){
        super([
            "JSON.OBJLEN",
            ...n
        ], t);
    }
};
var An = class extends e {
    constructor(n, t){
        super([
            "JSON.RESP",
            ...n
        ], t);
    }
};
var kn = class extends e {
    constructor(n, t){
        let o = [
            "JSON.SET",
            n[0],
            n[1],
            n[2]
        ];
        n[3] && (n[3].nx ? o.push("NX") : n[3].xx && o.push("XX")), super(o, t);
    }
};
var Rn = class extends e {
    constructor(n, t){
        super([
            "JSON.STRAPPEND",
            ...n
        ], t);
    }
};
var Sn = class extends e {
    constructor(n, t){
        super([
            "JSON.STRLEN",
            ...n
        ], t);
    }
};
var En = class extends e {
    constructor(n, t){
        super([
            "JSON.TOGGLE",
            ...n
        ], t);
    }
};
var Mn = class extends e {
    constructor(n, t){
        super([
            "JSON.TYPE",
            ...n
        ], t);
    }
};
var vn = class extends e {
    constructor(n, t){
        super([
            "keys",
            ...n
        ], t);
    }
};
var Pn = class extends e {
    constructor(n, t){
        super([
            "lindex",
            ...n
        ], t);
    }
};
var In = class extends e {
    constructor(n, t){
        super([
            "linsert",
            ...n
        ], t);
    }
};
var Nn = class extends e {
    constructor(n, t){
        super([
            "llen",
            ...n
        ], t);
    }
};
var Ln = class extends e {
    constructor(n, t){
        super([
            "lmove",
            ...n
        ], t);
    }
};
var zn = class extends e {
    constructor(n, t){
        super([
            "lpop",
            ...n
        ], t);
    }
};
var Gn = class extends e {
    constructor(n, t){
        let [o, m, r, a] = n;
        super([
            "LMPOP",
            o,
            ...m,
            r,
            ...a ? [
                "COUNT",
                a
            ] : []
        ], t);
    }
};
var Kn = class extends e {
    constructor(n, t){
        let o = [
            "lpos",
            n[0],
            n[1]
        ];
        typeof n[2]?.rank == "number" && o.push("rank", n[2].rank), typeof n[2]?.count == "number" && o.push("count", n[2].count), typeof n[2]?.maxLen == "number" && o.push("maxLen", n[2].maxLen), super(o, t);
    }
};
var Xn = class extends e {
    constructor(n, t){
        super([
            "lpush",
            ...n
        ], t);
    }
};
var Jn = class extends e {
    constructor(n, t){
        super([
            "lpushx",
            ...n
        ], t);
    }
};
var Un = class extends e {
    constructor(n, t){
        super([
            "lrange",
            ...n
        ], t);
    }
};
var Zn = class extends e {
    constructor(n, t){
        super([
            "lrem",
            ...n
        ], t);
    }
};
var Bn = class extends e {
    constructor(n, t){
        super([
            "lset",
            ...n
        ], t);
    }
};
var Hn = class extends e {
    constructor(n, t){
        super([
            "ltrim",
            ...n
        ], t);
    }
};
var Fn = class extends e {
    constructor(n, t){
        let o = Array.isArray(n[0]) ? n[0] : n;
        super([
            "mget",
            ...o
        ], t);
    }
};
var $n = class extends e {
    constructor([n], t){
        super([
            "mset",
            ...Object.entries(n).flatMap(([o, m])=>[
                    o,
                    m
                ])
        ], t);
    }
};
var qn = class extends e {
    constructor([n], t){
        super([
            "msetnx",
            ...Object.entries(n).flatMap((o)=>o)
        ], t);
    }
};
var jn = class extends e {
    constructor(n, t){
        super([
            "persist",
            ...n
        ], t);
    }
};
var Yn = class extends e {
    constructor(n, t){
        super([
            "pexpire",
            ...n
        ], t);
    }
};
var Vn = class extends e {
    constructor(n, t){
        super([
            "pexpireat",
            ...n
        ], t);
    }
};
var _n = class extends e {
    constructor(n, t){
        super([
            "pfadd",
            ...n
        ], t);
    }
};
var Wn = class extends e {
    constructor(n, t){
        super([
            "pfcount",
            ...n
        ], t);
    }
};
var Qn = class extends e {
    constructor(n, t){
        super([
            "pfmerge",
            ...n
        ], t);
    }
};
var nt = class extends e {
    constructor(n, t){
        let o = [
            "ping"
        ];
        typeof n < "u" && typeof n[0] < "u" && o.push(n[0]), super(o, t);
    }
};
var tt = class extends e {
    constructor(n, t){
        super([
            "psetex",
            ...n
        ], t);
    }
};
var et = class extends e {
    constructor(n, t){
        super([
            "pttl",
            ...n
        ], t);
    }
};
var ot = class extends e {
    constructor(n, t){
        super([
            "publish",
            ...n
        ], t);
    }
};
var st = class extends e {
    constructor(n){
        super([
            "randomkey"
        ], n);
    }
};
var mt = class extends e {
    constructor(n, t){
        super([
            "rename",
            ...n
        ], t);
    }
};
var rt = class extends e {
    constructor(n, t){
        super([
            "renamenx",
            ...n
        ], t);
    }
};
var at = class extends e {
    constructor(n, t){
        super([
            "rpop",
            ...n
        ], t);
    }
};
var it = class extends e {
    constructor(n, t){
        super([
            "rpush",
            ...n
        ], t);
    }
};
var pt = class extends e {
    constructor(n, t){
        super([
            "rpushx",
            ...n
        ], t);
    }
};
var dt = class extends e {
    constructor(n, t){
        super([
            "sadd",
            ...n
        ], t);
    }
};
var ct = class extends e {
    constructor([n, t], o){
        let m = [
            "scan",
            n
        ];
        t?.match && m.push("match", t.match), typeof t?.count == "number" && m.push("count", t.count), t?.type && t.type.length > 0 && m.push("type", t.type), super(m, {
            deserialize: l,
            ...o
        });
    }
};
var ut = class extends e {
    constructor(n, t){
        super([
            "scard",
            ...n
        ], t);
    }
};
var lt = class extends e {
    constructor(n, t){
        super([
            "script",
            "exists",
            ...n
        ], {
            deserialize: (o)=>o,
            ...t
        });
    }
};
var ht = class extends e {
    constructor([n], t){
        let o = [
            "script",
            "flush"
        ];
        n?.sync ? o.push("sync") : n?.async && o.push("async"), super(o, t);
    }
};
var Ct = class extends e {
    constructor(n, t){
        super([
            "script",
            "load",
            ...n
        ], t);
    }
};
var gt = class extends e {
    constructor(n, t){
        super([
            "sdiff",
            ...n
        ], t);
    }
};
var xt = class extends e {
    constructor(n, t){
        super([
            "sdiffstore",
            ...n
        ], t);
    }
};
var ft = class extends e {
    constructor([n, t, o], m){
        let r = [
            "set",
            n,
            t
        ];
        o && ("nx" in o && o.nx ? r.push("nx") : "xx" in o && o.xx && r.push("xx"), "get" in o && o.get && r.push("get"), "ex" in o && typeof o.ex == "number" ? r.push("ex", o.ex) : "px" in o && typeof o.px == "number" ? r.push("px", o.px) : "exat" in o && typeof o.exat == "number" ? r.push("exat", o.exat) : "pxat" in o && typeof o.pxat == "number" ? r.push("pxat", o.pxat) : "keepTtl" in o && o.keepTtl && r.push("keepTtl")), super(r, m);
    }
};
var yt = class extends e {
    constructor(n, t){
        super([
            "setbit",
            ...n
        ], t);
    }
};
var bt = class extends e {
    constructor(n, t){
        super([
            "setex",
            ...n
        ], t);
    }
};
var Tt = class extends e {
    constructor(n, t){
        super([
            "setnx",
            ...n
        ], t);
    }
};
var Ot = class extends e {
    constructor(n, t){
        super([
            "setrange",
            ...n
        ], t);
    }
};
var wt = class extends e {
    constructor(n, t){
        super([
            "sinter",
            ...n
        ], t);
    }
};
var Dt = class extends e {
    constructor(n, t){
        super([
            "sinterstore",
            ...n
        ], t);
    }
};
var At = class extends e {
    constructor(n, t){
        super([
            "sismember",
            ...n
        ], t);
    }
};
var kt = class extends e {
    constructor(n, t){
        super([
            "smembers",
            ...n
        ], t);
    }
};
var Rt = class extends e {
    constructor(n, t){
        super([
            "smismember",
            n[0],
            ...n[1]
        ], t);
    }
};
var St = class extends e {
    constructor(n, t){
        super([
            "smove",
            ...n
        ], t);
    }
};
var Et = class extends e {
    constructor([n, t], o){
        let m = [
            "spop",
            n
        ];
        typeof t == "number" && m.push(t), super(m, o);
    }
};
var Mt = class extends e {
    constructor([n, t], o){
        let m = [
            "srandmember",
            n
        ];
        typeof t == "number" && m.push(t), super(m, o);
    }
};
var vt = class extends e {
    constructor(n, t){
        super([
            "srem",
            ...n
        ], t);
    }
};
var Pt = class extends e {
    constructor([n, t, o], m){
        let r = [
            "sscan",
            n,
            t
        ];
        o?.match && r.push("match", o.match), typeof o?.count == "number" && r.push("count", o.count), super(r, {
            deserialize: l,
            ...m
        });
    }
};
var It = class extends e {
    constructor(n, t){
        super([
            "strlen",
            ...n
        ], t);
    }
};
var Nt = class extends e {
    constructor(n, t){
        super([
            "sunion",
            ...n
        ], t);
    }
};
var Lt = class extends e {
    constructor(n, t){
        super([
            "sunionstore",
            ...n
        ], t);
    }
};
var zt = class extends e {
    constructor(n){
        super([
            "time"
        ], n);
    }
};
var Gt = class extends e {
    constructor(n, t){
        super([
            "touch",
            ...n
        ], t);
    }
};
var Kt = class extends e {
    constructor(n, t){
        super([
            "ttl",
            ...n
        ], t);
    }
};
var Xt = class extends e {
    constructor(n, t){
        super([
            "type",
            ...n
        ], t);
    }
};
var Jt = class extends e {
    constructor(n, t){
        super([
            "unlink",
            ...n
        ], t);
    }
};
var Ut = class extends e {
    constructor([n, t, o], m){
        let r = Array.isArray(o) ? [
            ...o
        ] : [
            o
        ];
        super([
            "XACK",
            n,
            t,
            ...r
        ], m);
    }
};
var Zt = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "XADD",
            n
        ];
        m && (m.nomkStream && a.push("NOMKSTREAM"), m.trim && (a.push(m.trim.type, m.trim.comparison, m.trim.threshold), typeof m.trim.limit < "u" && a.push("LIMIT", m.trim.limit))), a.push(t);
        for (let [i, p] of Object.entries(o))a.push(i, p);
        super(a, r);
    }
};
var Bt = class extends e {
    constructor([n, t, o, m, r, a], i){
        let p = [];
        a?.count && p.push("COUNT", a.count), a?.justId && p.push("JUSTID"), super([
            "XAUTOCLAIM",
            n,
            t,
            o,
            m,
            r,
            ...p
        ], i);
    }
};
var Ht = class extends e {
    constructor([n, t, o, m, r, a], i){
        let p = Array.isArray(r) ? [
            ...r
        ] : [
            r
        ], d = [];
        a?.idleMS && d.push("IDLE", a.idleMS), a?.idleMS && d.push("TIME", a.timeMS), a?.retryCount && d.push("RETRYCOUNT", a?.retryCount), a?.force && d.push("FORCE"), a?.justId && d.push("JUSTID"), a?.lastId && d.push("LASTID", a.lastId), super([
            "XCLAIM",
            n,
            t,
            o,
            m,
            ...p,
            ...d
        ], i);
    }
};
var Ft = class extends e {
    constructor([n, t], o){
        let m = Array.isArray(t) ? [
            ...t
        ] : [
            t
        ];
        super([
            "XDEL",
            n,
            ...m
        ], o);
    }
};
var $t = class extends e {
    constructor([n, t], o){
        let m = [
            "XGROUP"
        ];
        switch(t.type){
            case "CREATE":
                m.push("CREATE", n, t.group, t.id), t.options && (t.options.MKSTREAM && m.push("MKSTREAM"), t.options.ENTRIESREAD !== void 0 && m.push("ENTRIESREAD", t.options.ENTRIESREAD.toString()));
                break;
            case "CREATECONSUMER":
                m.push("CREATECONSUMER", n, t.group, t.consumer);
                break;
            case "DELCONSUMER":
                m.push("DELCONSUMER", n, t.group, t.consumer);
                break;
            case "DESTROY":
                m.push("DESTROY", n, t.group);
                break;
            case "SETID":
                m.push("SETID", n, t.group, t.id), t.options && t.options.ENTRIESREAD !== void 0 && m.push("ENTRIESREAD", t.options.ENTRIESREAD.toString());
                break;
            default:
                throw new Error("Invalid XGROUP");
        }
        super(m, o);
    }
};
var qt = class extends e {
    constructor([n, t], o){
        let m = [];
        t.type === "CONSUMERS" ? m.push("CONSUMERS", n, t.group) : m.push("GROUPS", n), super([
            "XINFO",
            ...m
        ], o);
    }
};
var jt = class extends e {
    constructor(n, t){
        super([
            "XLEN",
            ...n
        ], t);
    }
};
var Yt = class extends e {
    constructor([n, t, o, m, r, a], i){
        let p = typeof a?.consumer < "u" ? Array.isArray(a.consumer) ? [
            ...a.consumer
        ] : [
            a.consumer
        ] : [];
        super([
            "XPENDING",
            n,
            t,
            ...a?.idleTime ? [
                "IDLE",
                a.idleTime
            ] : [],
            o,
            m,
            r,
            ...p
        ], i);
    }
};
function Ge(s) {
    let n = {};
    for (let t of s)for(; t.length >= 2;){
        let o = t.shift(), m = t.shift();
        for((o in n) || (n[o] = {}); m.length >= 2;){
            let r = m.shift(), a = m.shift();
            try {
                n[o][r] = JSON.parse(a);
            } catch  {
                n[o][r] = a;
            }
        }
    }
    return n;
}
var Vt = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "XRANGE",
            n,
            t,
            o
        ];
        typeof m == "number" && a.push("COUNT", m), super(a, {
            deserialize: (i)=>Ge(i),
            ...r
        });
    }
};
var Ke = "ERR Unbalanced XREAD list of streams: for each stream key an ID or '$' must be specified", _t = class extends e {
    constructor([n, t, o], m){
        if (Array.isArray(n) && Array.isArray(t) && n.length !== t.length) throw new Error(Ke);
        let r = [];
        typeof o?.count == "number" && r.push("COUNT", o.count), typeof o?.blockMS == "number" && r.push("BLOCK", o.blockMS), r.push("STREAMS", ...Array.isArray(n) ? [
            ...n
        ] : [
            n
        ], ...Array.isArray(t) ? [
            ...t
        ] : [
            t
        ]), super([
            "XREAD",
            ...r
        ], m);
    }
};
var Xe = "ERR Unbalanced XREADGROUP list of streams: for each stream key an ID or '$' must be specified", Wt = class extends e {
    constructor([n, t, o, m, r], a){
        if (Array.isArray(o) && Array.isArray(m) && o.length !== m.length) throw new Error(Xe);
        let i = [];
        typeof r?.count == "number" && i.push("COUNT", r.count), typeof r?.blockMS == "number" && i.push("BLOCK", r.blockMS), typeof r?.NOACK == "boolean" && r?.NOACK && i.push("NOACK"), i.push("STREAMS", ...Array.isArray(o) ? [
            ...o
        ] : [
            o
        ], ...Array.isArray(m) ? [
            ...m
        ] : [
            m
        ]), super([
            "XREADGROUP",
            "GROUP",
            n,
            t,
            ...i
        ], a);
    }
};
var Qt = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "XREVRANGE",
            n,
            t,
            o
        ];
        typeof m == "number" && a.push("COUNT", m), super(a, {
            deserialize: (i)=>Je(i),
            ...r
        });
    }
};
function Je(s) {
    let n = {};
    for (let t of s)for(; t.length >= 2;){
        let o = t.shift(), m = t.shift();
        for((o in n) || (n[o] = {}); m.length >= 2;){
            let r = m.shift(), a = m.shift();
            try {
                n[o][r] = JSON.parse(a);
            } catch  {
                n[o][r] = a;
            }
        }
    }
    return n;
}
var ne = class extends e {
    constructor([n, t], o){
        let { limit: m, strategy: r, threshold: a, exactness: i = "~" } = t;
        super([
            "XTRIM",
            n,
            r,
            i,
            a,
            ...m ? [
                "LIMIT",
                m
            ] : []
        ], o);
    }
};
var h = class extends e {
    constructor([n, t, ...o], m){
        let r = [
            "zadd",
            n
        ];
        "nx" in t && t.nx ? r.push("nx") : "xx" in t && t.xx && r.push("xx"), "ch" in t && t.ch && r.push("ch"), "incr" in t && t.incr && r.push("incr"), "lt" in t && t.lt ? r.push("lt") : "gt" in t && t.gt && r.push("gt"), "score" in t && "member" in t && r.push(t.score, t.member), r.push(...o.flatMap(({ score: a, member: i })=>[
                a,
                i
            ])), super(r, m);
    }
};
var te = class extends e {
    constructor(n, t){
        super([
            "zcard",
            ...n
        ], t);
    }
};
var ee = class extends e {
    constructor(n, t){
        super([
            "zcount",
            ...n
        ], t);
    }
};
var oe = class extends e {
    constructor(n, t){
        super([
            "zincrby",
            ...n
        ], t);
    }
};
var se = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "zinterstore",
            n,
            t
        ];
        Array.isArray(o) ? a.push(...o) : a.push(o), m && ("weights" in m && m.weights ? a.push("weights", ...m.weights) : "weight" in m && typeof m.weight == "number" && a.push("weights", m.weight), "aggregate" in m && a.push("aggregate", m.aggregate)), super(a, r);
    }
};
var me = class extends e {
    constructor(n, t){
        super([
            "zlexcount",
            ...n
        ], t);
    }
};
var re = class extends e {
    constructor([n, t], o){
        let m = [
            "zpopmax",
            n
        ];
        typeof t == "number" && m.push(t), super(m, o);
    }
};
var ae = class extends e {
    constructor([n, t], o){
        let m = [
            "zpopmin",
            n
        ];
        typeof t == "number" && m.push(t), super(m, o);
    }
};
var ie = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "zrange",
            n,
            t,
            o
        ];
        m?.byScore && a.push("byscore"), m?.byLex && a.push("bylex"), m?.rev && a.push("rev"), typeof m?.count < "u" && typeof m?.offset < "u" && a.push("limit", m.offset, m.count), m?.withScores && a.push("withscores"), super(a, r);
    }
};
var pe = class extends e {
    constructor(n, t){
        super([
            "zrank",
            ...n
        ], t);
    }
};
var de = class extends e {
    constructor(n, t){
        super([
            "zrem",
            ...n
        ], t);
    }
};
var ce = class extends e {
    constructor(n, t){
        super([
            "zremrangebylex",
            ...n
        ], t);
    }
};
var ue = class extends e {
    constructor(n, t){
        super([
            "zremrangebyrank",
            ...n
        ], t);
    }
};
var le = class extends e {
    constructor(n, t){
        super([
            "zremrangebyscore",
            ...n
        ], t);
    }
};
var he = class extends e {
    constructor(n, t){
        super([
            "zrevrank",
            ...n
        ], t);
    }
};
var Ce = class extends e {
    constructor([n, t, o], m){
        let r = [
            "zscan",
            n,
            t
        ];
        o?.match && r.push("match", o.match), typeof o?.count == "number" && r.push("count", o.count), super(r, {
            deserialize: l,
            ...m
        });
    }
};
var ge = class extends e {
    constructor(n, t){
        super([
            "zscore",
            ...n
        ], t);
    }
};
var xe = class extends e {
    constructor([n, t, o], m){
        let r = [
            "zunion",
            n
        ];
        Array.isArray(t) ? r.push(...t) : r.push(t), o && ("weights" in o && o.weights ? r.push("weights", ...o.weights) : "weight" in o && typeof o.weight == "number" && r.push("weights", o.weight), "aggregate" in o && r.push("aggregate", o.aggregate), o?.withScores && r.push("withscores")), super(r, m);
    }
};
var fe = class extends e {
    constructor([n, t, o, m], r){
        let a = [
            "zunionstore",
            n,
            t
        ];
        Array.isArray(o) ? a.push(...o) : a.push(o), m && ("weights" in m && m.weights ? a.push("weights", ...m.weights) : "weight" in m && typeof m.weight == "number" && a.push("weights", m.weight), "aggregate" in m && a.push("aggregate", m.aggregate)), super(a, r);
    }
};
var ye = class extends e {
    constructor(n, t){
        super([
            "zdiffstore",
            ...n
        ], t);
    }
};
var be = class extends e {
    constructor(n, t){
        let [o, m] = n;
        super([
            "zmscore",
            o,
            ...m
        ], t);
    }
};
var Te = class {
    client;
    commands;
    commandOptions;
    multiExec;
    constructor(n){
        if (this.client = n.client, this.commands = [], this.commandOptions = n.commandOptions, this.multiExec = n.multiExec ?? !1, this.commandOptions?.latencyLogging) {
            let t = this.exec.bind(this);
            this.exec = async ()=>{
                let o = performance.now(), m = await t(), a = (performance.now() - o).toFixed(2);
                return console.log(`Latency for \x1B[38;2;19;185;39m${this.multiExec ? [
                    "MULTI-EXEC"
                ] : [
                    "PIPELINE"
                ].toString().toUpperCase()}\x1B[0m: \x1B[38;2;0;255;255m${a} ms\x1B[0m`), m;
            };
        }
    }
    exec = async ()=>{
        if (this.commands.length === 0) throw new Error("Pipeline is empty");
        let n = this.multiExec ? [
            "multi-exec"
        ] : [
            "pipeline"
        ];
        return (await this.client.request({
            path: n,
            body: Object.values(this.commands).map((o)=>o.command)
        })).map(({ error: o, result: m }, r)=>{
            if (o) throw new u(`Command ${r + 1} [ ${this.commands[r].command[0]} ] failed: ${o}`);
            return this.commands[r].deserialize(m);
        });
    };
    length() {
        return this.commands.length;
    }
    chain(n) {
        return this.commands.push(n), this;
    }
    append = (...n)=>this.chain(new g(n, this.commandOptions));
    bitcount = (...n)=>this.chain(new x(n, this.commandOptions));
    bitop = (n, t, o, ...m)=>this.chain(new f([
            n,
            t,
            o,
            ...m
        ], this.commandOptions));
    bitpos = (...n)=>this.chain(new y(n, this.commandOptions));
    copy = (...n)=>this.chain(new b(n, this.commandOptions));
    zdiffstore = (...n)=>this.chain(new ye(n, this.commandOptions));
    dbsize = ()=>this.chain(new T(this.commandOptions));
    decr = (...n)=>this.chain(new O(n, this.commandOptions));
    decrby = (...n)=>this.chain(new w(n, this.commandOptions));
    del = (...n)=>this.chain(new D(n, this.commandOptions));
    echo = (...n)=>this.chain(new A(n, this.commandOptions));
    eval = (...n)=>this.chain(new k(n, this.commandOptions));
    evalsha = (...n)=>this.chain(new R(n, this.commandOptions));
    exists = (...n)=>this.chain(new S(n, this.commandOptions));
    expire = (...n)=>this.chain(new E(n, this.commandOptions));
    expireat = (...n)=>this.chain(new M(n, this.commandOptions));
    flushall = (n)=>this.chain(new v(n, this.commandOptions));
    flushdb = (...n)=>this.chain(new P(n, this.commandOptions));
    geoadd = (...n)=>this.chain(new I(n, this.commandOptions));
    geodist = (...n)=>this.chain(new N(n, this.commandOptions));
    geopos = (...n)=>this.chain(new z(n, this.commandOptions));
    geohash = (...n)=>this.chain(new L(n, this.commandOptions));
    geosearch = (...n)=>this.chain(new G(n, this.commandOptions));
    geosearchstore = (...n)=>this.chain(new K(n, this.commandOptions));
    get = (...n)=>this.chain(new X(n, this.commandOptions));
    getbit = (...n)=>this.chain(new J(n, this.commandOptions));
    getdel = (...n)=>this.chain(new U(n, this.commandOptions));
    getrange = (...n)=>this.chain(new Z(n, this.commandOptions));
    getset = (n, t)=>this.chain(new B([
            n,
            t
        ], this.commandOptions));
    hdel = (...n)=>this.chain(new H(n, this.commandOptions));
    hexists = (...n)=>this.chain(new F(n, this.commandOptions));
    hget = (...n)=>this.chain(new $(n, this.commandOptions));
    hgetall = (...n)=>this.chain(new q(n, this.commandOptions));
    hincrby = (...n)=>this.chain(new j(n, this.commandOptions));
    hincrbyfloat = (...n)=>this.chain(new Y(n, this.commandOptions));
    hkeys = (...n)=>this.chain(new V(n, this.commandOptions));
    hlen = (...n)=>this.chain(new _(n, this.commandOptions));
    hmget = (...n)=>this.chain(new W(n, this.commandOptions));
    hmset = (n, t)=>this.chain(new Q([
            n,
            t
        ], this.commandOptions));
    hrandfield = (n, t, o)=>this.chain(new nn([
            n,
            t,
            o
        ], this.commandOptions));
    hscan = (...n)=>this.chain(new tn(n, this.commandOptions));
    hset = (n, t)=>this.chain(new en([
            n,
            t
        ], this.commandOptions));
    hsetnx = (n, t, o)=>this.chain(new on([
            n,
            t,
            o
        ], this.commandOptions));
    hstrlen = (...n)=>this.chain(new sn(n, this.commandOptions));
    hvals = (...n)=>this.chain(new mn(n, this.commandOptions));
    incr = (...n)=>this.chain(new rn(n, this.commandOptions));
    incrby = (...n)=>this.chain(new an(n, this.commandOptions));
    incrbyfloat = (...n)=>this.chain(new pn(n, this.commandOptions));
    keys = (...n)=>this.chain(new vn(n, this.commandOptions));
    lindex = (...n)=>this.chain(new Pn(n, this.commandOptions));
    linsert = (n, t, o, m)=>this.chain(new In([
            n,
            t,
            o,
            m
        ], this.commandOptions));
    llen = (...n)=>this.chain(new Nn(n, this.commandOptions));
    lmove = (...n)=>this.chain(new Ln(n, this.commandOptions));
    lpop = (...n)=>this.chain(new zn(n, this.commandOptions));
    lmpop = (...n)=>this.chain(new Gn(n, this.commandOptions));
    lpos = (...n)=>this.chain(new Kn(n, this.commandOptions));
    lpush = (n, ...t)=>this.chain(new Xn([
            n,
            ...t
        ], this.commandOptions));
    lpushx = (n, ...t)=>this.chain(new Jn([
            n,
            ...t
        ], this.commandOptions));
    lrange = (...n)=>this.chain(new Un(n, this.commandOptions));
    lrem = (n, t, o)=>this.chain(new Zn([
            n,
            t,
            o
        ], this.commandOptions));
    lset = (n, t, o)=>this.chain(new Bn([
            n,
            t,
            o
        ], this.commandOptions));
    ltrim = (...n)=>this.chain(new Hn(n, this.commandOptions));
    mget = (...n)=>this.chain(new Fn(n, this.commandOptions));
    mset = (n)=>this.chain(new $n([
            n
        ], this.commandOptions));
    msetnx = (n)=>this.chain(new qn([
            n
        ], this.commandOptions));
    persist = (...n)=>this.chain(new jn(n, this.commandOptions));
    pexpire = (...n)=>this.chain(new Yn(n, this.commandOptions));
    pexpireat = (...n)=>this.chain(new Vn(n, this.commandOptions));
    pfadd = (...n)=>this.chain(new _n(n, this.commandOptions));
    pfcount = (...n)=>this.chain(new Wn(n, this.commandOptions));
    pfmerge = (...n)=>this.chain(new Qn(n, this.commandOptions));
    ping = (n)=>this.chain(new nt(n, this.commandOptions));
    psetex = (n, t, o)=>this.chain(new tt([
            n,
            t,
            o
        ], this.commandOptions));
    pttl = (...n)=>this.chain(new et(n, this.commandOptions));
    publish = (...n)=>this.chain(new ot(n, this.commandOptions));
    randomkey = ()=>this.chain(new st(this.commandOptions));
    rename = (...n)=>this.chain(new mt(n, this.commandOptions));
    renamenx = (...n)=>this.chain(new rt(n, this.commandOptions));
    rpop = (...n)=>this.chain(new at(n, this.commandOptions));
    rpush = (n, ...t)=>this.chain(new it([
            n,
            ...t
        ], this.commandOptions));
    rpushx = (n, ...t)=>this.chain(new pt([
            n,
            ...t
        ], this.commandOptions));
    sadd = (n, ...t)=>this.chain(new dt([
            n,
            ...t
        ], this.commandOptions));
    scan = (...n)=>this.chain(new ct(n, this.commandOptions));
    scard = (...n)=>this.chain(new ut(n, this.commandOptions));
    scriptExists = (...n)=>this.chain(new lt(n, this.commandOptions));
    scriptFlush = (...n)=>this.chain(new ht(n, this.commandOptions));
    scriptLoad = (...n)=>this.chain(new Ct(n, this.commandOptions));
    sdiff = (...n)=>this.chain(new gt(n, this.commandOptions));
    sdiffstore = (...n)=>this.chain(new xt(n, this.commandOptions));
    set = (n, t, o)=>this.chain(new ft([
            n,
            t,
            o
        ], this.commandOptions));
    setbit = (...n)=>this.chain(new yt(n, this.commandOptions));
    setex = (n, t, o)=>this.chain(new bt([
            n,
            t,
            o
        ], this.commandOptions));
    setnx = (n, t)=>this.chain(new Tt([
            n,
            t
        ], this.commandOptions));
    setrange = (...n)=>this.chain(new Ot(n, this.commandOptions));
    sinter = (...n)=>this.chain(new wt(n, this.commandOptions));
    sinterstore = (...n)=>this.chain(new Dt(n, this.commandOptions));
    sismember = (n, t)=>this.chain(new At([
            n,
            t
        ], this.commandOptions));
    smembers = (...n)=>this.chain(new kt(n, this.commandOptions));
    smismember = (n, t)=>this.chain(new Rt([
            n,
            t
        ], this.commandOptions));
    smove = (n, t, o)=>this.chain(new St([
            n,
            t,
            o
        ], this.commandOptions));
    spop = (...n)=>this.chain(new Et(n, this.commandOptions));
    srandmember = (...n)=>this.chain(new Mt(n, this.commandOptions));
    srem = (n, ...t)=>this.chain(new vt([
            n,
            ...t
        ], this.commandOptions));
    sscan = (...n)=>this.chain(new Pt(n, this.commandOptions));
    strlen = (...n)=>this.chain(new It(n, this.commandOptions));
    sunion = (...n)=>this.chain(new Nt(n, this.commandOptions));
    sunionstore = (...n)=>this.chain(new Lt(n, this.commandOptions));
    time = ()=>this.chain(new zt(this.commandOptions));
    touch = (...n)=>this.chain(new Gt(n, this.commandOptions));
    ttl = (...n)=>this.chain(new Kt(n, this.commandOptions));
    type = (...n)=>this.chain(new Xt(n, this.commandOptions));
    unlink = (...n)=>this.chain(new Jt(n, this.commandOptions));
    zadd = (...n)=>"score" in n[1] ? this.chain(new h([
            n[0],
            n[1],
            ...n.slice(2)
        ], this.commandOptions)) : this.chain(new h([
            n[0],
            n[1],
            ...n.slice(2)
        ], this.commandOptions));
    xadd = (...n)=>this.chain(new Zt(n, this.commandOptions));
    xack = (...n)=>this.chain(new Ut(n, this.commandOptions));
    xdel = (...n)=>this.chain(new Ft(n, this.commandOptions));
    xgroup = (...n)=>this.chain(new $t(n, this.commandOptions));
    xread = (...n)=>this.chain(new _t(n, this.commandOptions));
    xreadgroup = (...n)=>this.chain(new Wt(n, this.commandOptions));
    xinfo = (...n)=>this.chain(new qt(n, this.commandOptions));
    xlen = (...n)=>this.chain(new jt(n, this.commandOptions));
    xpending = (...n)=>this.chain(new Yt(n, this.commandOptions));
    xclaim = (...n)=>this.chain(new Ht(n, this.commandOptions));
    xautoclaim = (...n)=>this.chain(new Bt(n, this.commandOptions));
    xtrim = (...n)=>this.chain(new ne(n, this.commandOptions));
    xrange = (...n)=>this.chain(new Vt(n, this.commandOptions));
    xrevrange = (...n)=>this.chain(new Qt(n, this.commandOptions));
    zcard = (...n)=>this.chain(new te(n, this.commandOptions));
    zcount = (...n)=>this.chain(new ee(n, this.commandOptions));
    zincrby = (n, t, o)=>this.chain(new oe([
            n,
            t,
            o
        ], this.commandOptions));
    zinterstore = (...n)=>this.chain(new se(n, this.commandOptions));
    zlexcount = (...n)=>this.chain(new me(n, this.commandOptions));
    zmscore = (...n)=>this.chain(new be(n, this.commandOptions));
    zpopmax = (...n)=>this.chain(new re(n, this.commandOptions));
    zpopmin = (...n)=>this.chain(new ae(n, this.commandOptions));
    zrange = (...n)=>this.chain(new ie(n, this.commandOptions));
    zrank = (n, t)=>this.chain(new pe([
            n,
            t
        ], this.commandOptions));
    zrem = (n, ...t)=>this.chain(new de([
            n,
            ...t
        ], this.commandOptions));
    zremrangebylex = (...n)=>this.chain(new ce(n, this.commandOptions));
    zremrangebyrank = (...n)=>this.chain(new ue(n, this.commandOptions));
    zremrangebyscore = (...n)=>this.chain(new le(n, this.commandOptions));
    zrevrank = (n, t)=>this.chain(new he([
            n,
            t
        ], this.commandOptions));
    zscan = (...n)=>this.chain(new Ce(n, this.commandOptions));
    zscore = (n, t)=>this.chain(new ge([
            n,
            t
        ], this.commandOptions));
    zunionstore = (...n)=>this.chain(new fe(n, this.commandOptions));
    zunion = (...n)=>this.chain(new xe(n, this.commandOptions));
    get json() {
        return {
            arrappend: (...n)=>this.chain(new dn(n, this.commandOptions)),
            arrindex: (...n)=>this.chain(new cn(n, this.commandOptions)),
            arrinsert: (...n)=>this.chain(new un(n, this.commandOptions)),
            arrlen: (...n)=>this.chain(new ln(n, this.commandOptions)),
            arrpop: (...n)=>this.chain(new hn(n, this.commandOptions)),
            arrtrim: (...n)=>this.chain(new Cn(n, this.commandOptions)),
            clear: (...n)=>this.chain(new gn(n, this.commandOptions)),
            del: (...n)=>this.chain(new xn(n, this.commandOptions)),
            forget: (...n)=>this.chain(new fn(n, this.commandOptions)),
            get: (...n)=>this.chain(new yn(n, this.commandOptions)),
            mget: (...n)=>this.chain(new bn(n, this.commandOptions)),
            numincrby: (...n)=>this.chain(new Tn(n, this.commandOptions)),
            nummultby: (...n)=>this.chain(new On(n, this.commandOptions)),
            objkeys: (...n)=>this.chain(new wn(n, this.commandOptions)),
            objlen: (...n)=>this.chain(new Dn(n, this.commandOptions)),
            resp: (...n)=>this.chain(new An(n, this.commandOptions)),
            set: (...n)=>this.chain(new kn(n, this.commandOptions)),
            strappend: (...n)=>this.chain(new Rn(n, this.commandOptions)),
            strlen: (...n)=>this.chain(new Sn(n, this.commandOptions)),
            toggle: (...n)=>this.chain(new En(n, this.commandOptions)),
            type: (...n)=>this.chain(new Mn(n, this.commandOptions))
        };
    }
};
;
;
var we = class {
    script;
    sha1;
    redis;
    constructor(n, t){
        this.redis = n, this.sha1 = this.digest(t), this.script = t;
    }
    async eval(n, t) {
        return await this.redis.eval(this.script, n, t);
    }
    async evalsha(n, t) {
        return await this.redis.evalsha(this.sha1, n, t);
    }
    async exec(n, t) {
        return await this.redis.evalsha(this.sha1, n, t).catch(async (m)=>{
            if (m instanceof Error && m.message.toLowerCase().includes("noscript")) return await this.redis.eval(this.script, n, t);
            throw m;
        });
    }
    digest(n) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$crypto$2d$js$40$4$2e$2$2e$0$2f$node_modules$2f$crypto$2d$js$2f$enc$2d$hex$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].stringify((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$crypto$2d$js$40$4$2e$2$2e$0$2f$node_modules$2f$crypto$2d$js$2f$sha1$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(n));
    }
};
function Re(s, n) {
    let t = s;
    return t.autoPipelineExecutor || (t.autoPipelineExecutor = new ke(t)), new Proxy(t, {
        get: (o, m)=>m === "pipelineCounter" ? o.autoPipelineExecutor.pipelineCounter : m === "json" ? Re(o, !0) : m in o && !(m in o.autoPipelineExecutor.pipeline) ? o[m] : typeof o.autoPipelineExecutor.pipeline[m] == "function" ? (...a)=>o.autoPipelineExecutor.withAutoPipeline((i)=>{
                    n ? i.json[m](...a) : i[m](...a);
                }) : o.autoPipelineExecutor.pipeline[m]
    });
}
var ke = class {
    pipelinePromises = new WeakMap;
    activePipeline = null;
    indexInCurrentPipeline = 0;
    redis;
    pipeline;
    pipelineCounter = 0;
    constructor(n){
        this.redis = n, this.pipeline = n.pipeline();
    }
    async withAutoPipeline(n) {
        let t = this.activePipeline || this.redis.pipeline();
        this.activePipeline || (this.activePipeline = t, this.indexInCurrentPipeline = 0);
        let o = this.indexInCurrentPipeline++;
        return n(t), (await this.deferExecution().then(()=>{
            if (!this.pipelinePromises.has(t)) {
                let a = t.exec();
                this.pipelineCounter += 1, this.pipelinePromises.set(t, a), this.activePipeline = null;
            }
            return this.pipelinePromises.get(t);
        }))[o];
    }
    async deferExecution() {
        return await Promise.resolve(), await Promise.resolve();
    }
};
var ve = class {
    client;
    opts;
    enableTelemetry;
    enableAutoPipelining;
    constructor(n, t){
        this.client = n, this.opts = t, this.enableTelemetry = t?.enableTelemetry ?? !0, this.enableAutoPipelining = t?.enableAutoPipelining ?? !1;
    }
    get json() {
        return {
            arrappend: (...n)=>new dn(n, this.opts).exec(this.client),
            arrindex: (...n)=>new cn(n, this.opts).exec(this.client),
            arrinsert: (...n)=>new un(n, this.opts).exec(this.client),
            arrlen: (...n)=>new ln(n, this.opts).exec(this.client),
            arrpop: (...n)=>new hn(n, this.opts).exec(this.client),
            arrtrim: (...n)=>new Cn(n, this.opts).exec(this.client),
            clear: (...n)=>new gn(n, this.opts).exec(this.client),
            del: (...n)=>new xn(n, this.opts).exec(this.client),
            forget: (...n)=>new fn(n, this.opts).exec(this.client),
            get: (...n)=>new yn(n, this.opts).exec(this.client),
            mget: (...n)=>new bn(n, this.opts).exec(this.client),
            numincrby: (...n)=>new Tn(n, this.opts).exec(this.client),
            nummultby: (...n)=>new On(n, this.opts).exec(this.client),
            objkeys: (...n)=>new wn(n, this.opts).exec(this.client),
            objlen: (...n)=>new Dn(n, this.opts).exec(this.client),
            resp: (...n)=>new An(n, this.opts).exec(this.client),
            set: (...n)=>new kn(n, this.opts).exec(this.client),
            strappend: (...n)=>new Rn(n, this.opts).exec(this.client),
            strlen: (...n)=>new Sn(n, this.opts).exec(this.client),
            toggle: (...n)=>new En(n, this.opts).exec(this.client),
            type: (...n)=>new Mn(n, this.opts).exec(this.client)
        };
    }
    use = (n)=>{
        let t = this.client.request.bind(this.client);
        this.client.request = (o)=>n(o, t);
    };
    addTelemetry = (n)=>{
        if (this.enableTelemetry) try {
            this.client.mergeTelemetry(n);
        } catch  {}
    };
    createScript(n) {
        return new we(this, n);
    }
    pipeline = ()=>new Te({
            client: this.client,
            commandOptions: this.opts,
            multiExec: !1
        });
    autoPipeline = ()=>Re(this);
    multi = ()=>new Te({
            client: this.client,
            commandOptions: this.opts,
            multiExec: !0
        });
    append = (...n)=>new g(n, this.opts).exec(this.client);
    bitcount = (...n)=>new x(n, this.opts).exec(this.client);
    bitop = (n, t, o, ...m)=>new f([
            n,
            t,
            o,
            ...m
        ], this.opts).exec(this.client);
    bitpos = (...n)=>new y(n, this.opts).exec(this.client);
    copy = (...n)=>new b(n, this.opts).exec(this.client);
    dbsize = ()=>new T(this.opts).exec(this.client);
    decr = (...n)=>new O(n, this.opts).exec(this.client);
    decrby = (...n)=>new w(n, this.opts).exec(this.client);
    del = (...n)=>new D(n, this.opts).exec(this.client);
    echo = (...n)=>new A(n, this.opts).exec(this.client);
    eval = (...n)=>new k(n, this.opts).exec(this.client);
    evalsha = (...n)=>new R(n, this.opts).exec(this.client);
    exists = (...n)=>new S(n, this.opts).exec(this.client);
    expire = (...n)=>new E(n, this.opts).exec(this.client);
    expireat = (...n)=>new M(n, this.opts).exec(this.client);
    flushall = (n)=>new v(n, this.opts).exec(this.client);
    flushdb = (...n)=>new P(n, this.opts).exec(this.client);
    geoadd = (...n)=>new I(n, this.opts).exec(this.client);
    geopos = (...n)=>new z(n, this.opts).exec(this.client);
    geodist = (...n)=>new N(n, this.opts).exec(this.client);
    geohash = (...n)=>new L(n, this.opts).exec(this.client);
    geosearch = (...n)=>new G(n, this.opts).exec(this.client);
    geosearchstore = (...n)=>new K(n, this.opts).exec(this.client);
    get = (...n)=>new X(n, this.opts).exec(this.client);
    getbit = (...n)=>new J(n, this.opts).exec(this.client);
    getdel = (...n)=>new U(n, this.opts).exec(this.client);
    getrange = (...n)=>new Z(n, this.opts).exec(this.client);
    getset = (n, t)=>new B([
            n,
            t
        ], this.opts).exec(this.client);
    hdel = (...n)=>new H(n, this.opts).exec(this.client);
    hexists = (...n)=>new F(n, this.opts).exec(this.client);
    hget = (...n)=>new $(n, this.opts).exec(this.client);
    hgetall = (...n)=>new q(n, this.opts).exec(this.client);
    hincrby = (...n)=>new j(n, this.opts).exec(this.client);
    hincrbyfloat = (...n)=>new Y(n, this.opts).exec(this.client);
    hkeys = (...n)=>new V(n, this.opts).exec(this.client);
    hlen = (...n)=>new _(n, this.opts).exec(this.client);
    hmget = (...n)=>new W(n, this.opts).exec(this.client);
    hmset = (n, t)=>new Q([
            n,
            t
        ], this.opts).exec(this.client);
    hrandfield = (n, t, o)=>new nn([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    hscan = (...n)=>new tn(n, this.opts).exec(this.client);
    hset = (n, t)=>new en([
            n,
            t
        ], this.opts).exec(this.client);
    hsetnx = (n, t, o)=>new on([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    hstrlen = (...n)=>new sn(n, this.opts).exec(this.client);
    hvals = (...n)=>new mn(n, this.opts).exec(this.client);
    incr = (...n)=>new rn(n, this.opts).exec(this.client);
    incrby = (...n)=>new an(n, this.opts).exec(this.client);
    incrbyfloat = (...n)=>new pn(n, this.opts).exec(this.client);
    keys = (...n)=>new vn(n, this.opts).exec(this.client);
    lindex = (...n)=>new Pn(n, this.opts).exec(this.client);
    linsert = (n, t, o, m)=>new In([
            n,
            t,
            o,
            m
        ], this.opts).exec(this.client);
    llen = (...n)=>new Nn(n, this.opts).exec(this.client);
    lmove = (...n)=>new Ln(n, this.opts).exec(this.client);
    lpop = (...n)=>new zn(n, this.opts).exec(this.client);
    lmpop = (...n)=>new Gn(n, this.opts).exec(this.client);
    lpos = (...n)=>new Kn(n, this.opts).exec(this.client);
    lpush = (n, ...t)=>new Xn([
            n,
            ...t
        ], this.opts).exec(this.client);
    lpushx = (n, ...t)=>new Jn([
            n,
            ...t
        ], this.opts).exec(this.client);
    lrange = (...n)=>new Un(n, this.opts).exec(this.client);
    lrem = (n, t, o)=>new Zn([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    lset = (n, t, o)=>new Bn([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    ltrim = (...n)=>new Hn(n, this.opts).exec(this.client);
    mget = (...n)=>new Fn(n, this.opts).exec(this.client);
    mset = (n)=>new $n([
            n
        ], this.opts).exec(this.client);
    msetnx = (n)=>new qn([
            n
        ], this.opts).exec(this.client);
    persist = (...n)=>new jn(n, this.opts).exec(this.client);
    pexpire = (...n)=>new Yn(n, this.opts).exec(this.client);
    pexpireat = (...n)=>new Vn(n, this.opts).exec(this.client);
    pfadd = (...n)=>new _n(n, this.opts).exec(this.client);
    pfcount = (...n)=>new Wn(n, this.opts).exec(this.client);
    pfmerge = (...n)=>new Qn(n, this.opts).exec(this.client);
    ping = (n)=>new nt(n, this.opts).exec(this.client);
    psetex = (n, t, o)=>new tt([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    pttl = (...n)=>new et(n, this.opts).exec(this.client);
    publish = (...n)=>new ot(n, this.opts).exec(this.client);
    randomkey = ()=>new st().exec(this.client);
    rename = (...n)=>new mt(n, this.opts).exec(this.client);
    renamenx = (...n)=>new rt(n, this.opts).exec(this.client);
    rpop = (...n)=>new at(n, this.opts).exec(this.client);
    rpush = (n, ...t)=>new it([
            n,
            ...t
        ], this.opts).exec(this.client);
    rpushx = (n, ...t)=>new pt([
            n,
            ...t
        ], this.opts).exec(this.client);
    sadd = (n, ...t)=>new dt([
            n,
            ...t
        ], this.opts).exec(this.client);
    scan = (...n)=>new ct(n, this.opts).exec(this.client);
    scard = (...n)=>new ut(n, this.opts).exec(this.client);
    scriptExists = (...n)=>new lt(n, this.opts).exec(this.client);
    scriptFlush = (...n)=>new ht(n, this.opts).exec(this.client);
    scriptLoad = (...n)=>new Ct(n, this.opts).exec(this.client);
    sdiff = (...n)=>new gt(n, this.opts).exec(this.client);
    sdiffstore = (...n)=>new xt(n, this.opts).exec(this.client);
    set = (n, t, o)=>new ft([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    setbit = (...n)=>new yt(n, this.opts).exec(this.client);
    setex = (n, t, o)=>new bt([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    setnx = (n, t)=>new Tt([
            n,
            t
        ], this.opts).exec(this.client);
    setrange = (...n)=>new Ot(n, this.opts).exec(this.client);
    sinter = (...n)=>new wt(n, this.opts).exec(this.client);
    sinterstore = (...n)=>new Dt(n, this.opts).exec(this.client);
    sismember = (n, t)=>new At([
            n,
            t
        ], this.opts).exec(this.client);
    smismember = (n, t)=>new Rt([
            n,
            t
        ], this.opts).exec(this.client);
    smembers = (...n)=>new kt(n, this.opts).exec(this.client);
    smove = (n, t, o)=>new St([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    spop = (...n)=>new Et(n, this.opts).exec(this.client);
    srandmember = (...n)=>new Mt(n, this.opts).exec(this.client);
    srem = (n, ...t)=>new vt([
            n,
            ...t
        ], this.opts).exec(this.client);
    sscan = (...n)=>new Pt(n, this.opts).exec(this.client);
    strlen = (...n)=>new It(n, this.opts).exec(this.client);
    sunion = (...n)=>new Nt(n, this.opts).exec(this.client);
    sunionstore = (...n)=>new Lt(n, this.opts).exec(this.client);
    time = ()=>new zt().exec(this.client);
    touch = (...n)=>new Gt(n, this.opts).exec(this.client);
    ttl = (...n)=>new Kt(n, this.opts).exec(this.client);
    type = (...n)=>new Xt(n, this.opts).exec(this.client);
    unlink = (...n)=>new Jt(n, this.opts).exec(this.client);
    xadd = (...n)=>new Zt(n, this.opts).exec(this.client);
    xack = (...n)=>new Ut(n, this.opts).exec(this.client);
    xdel = (...n)=>new Ft(n, this.opts).exec(this.client);
    xgroup = (...n)=>new $t(n, this.opts).exec(this.client);
    xread = (...n)=>new _t(n, this.opts).exec(this.client);
    xreadgroup = (...n)=>new Wt(n, this.opts).exec(this.client);
    xinfo = (...n)=>new qt(n, this.opts).exec(this.client);
    xlen = (...n)=>new jt(n, this.opts).exec(this.client);
    xpending = (...n)=>new Yt(n, this.opts).exec(this.client);
    xclaim = (...n)=>new Ht(n, this.opts).exec(this.client);
    xautoclaim = (...n)=>new Bt(n, this.opts).exec(this.client);
    xtrim = (...n)=>new ne(n, this.opts).exec(this.client);
    xrange = (...n)=>new Vt(n, this.opts).exec(this.client);
    xrevrange = (...n)=>new Qt(n, this.opts).exec(this.client);
    zadd = (...n)=>"score" in n[1] ? new h([
            n[0],
            n[1],
            ...n.slice(2)
        ], this.opts).exec(this.client) : new h([
            n[0],
            n[1],
            ...n.slice(2)
        ], this.opts).exec(this.client);
    zcard = (...n)=>new te(n, this.opts).exec(this.client);
    zcount = (...n)=>new ee(n, this.opts).exec(this.client);
    zdiffstore = (...n)=>new ye(n, this.opts).exec(this.client);
    zincrby = (n, t, o)=>new oe([
            n,
            t,
            o
        ], this.opts).exec(this.client);
    zinterstore = (...n)=>new se(n, this.opts).exec(this.client);
    zlexcount = (...n)=>new me(n, this.opts).exec(this.client);
    zmscore = (...n)=>new be(n, this.opts).exec(this.client);
    zpopmax = (...n)=>new re(n, this.opts).exec(this.client);
    zpopmin = (...n)=>new ae(n, this.opts).exec(this.client);
    zrange = (...n)=>new ie(n, this.opts).exec(this.client);
    zrank = (n, t)=>new pe([
            n,
            t
        ], this.opts).exec(this.client);
    zrem = (n, ...t)=>new de([
            n,
            ...t
        ], this.opts).exec(this.client);
    zremrangebylex = (...n)=>new ce(n, this.opts).exec(this.client);
    zremrangebyrank = (...n)=>new ue(n, this.opts).exec(this.client);
    zremrangebyscore = (...n)=>new le(n, this.opts).exec(this.client);
    zrevrank = (n, t)=>new he([
            n,
            t
        ], this.opts).exec(this.client);
    zscan = (...n)=>new Ce(n, this.opts).exec(this.client);
    zscore = (n, t)=>new ge([
            n,
            t
        ], this.opts).exec(this.client);
    zunion = (...n)=>new xe(n, this.opts).exec(this.client);
    zunionstore = (...n)=>new fe(n, this.opts).exec(this.client);
};
var qC = "v1.31.6";
;

})()),
"[project]/node_modules/.pnpm/@upstash+redis@1.31.6/node_modules/@upstash/redis/nodejs.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Redis": ()=>a
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$chunk$2d$2DN6UAHL$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@upstash+redis@1.31.6/node_modules/@upstash/redis/chunk-2DN6UAHL.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
typeof atob > "u" && (global.atob = (t)=>Buffer.from(t, "base64").toString("utf-8"));
var a = class t extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$chunk$2d$2DN6UAHL$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"] {
    constructor(e){
        if ("request" in e) {
            super(e);
            return;
        }
        if (!e.url) throw new Error("[Upstash Redis] The 'url' property is missing or undefined in your Redis config.");
        if (!e.token) throw new Error("[Upstash Redis] The 'token' property is missing or undefined in your Redis config.");
        (e.url.startsWith(" ") || e.url.endsWith(" ") || /\r|\n/.test(e.url)) && console.warn("The redis url contains whitespace or newline, which can cause errors!"), (e.token.startsWith(" ") || e.token.endsWith(" ") || /\r|\n/.test(e.token)) && console.warn("The redis token contains whitespace or newline, which can cause errors!");
        let n = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$chunk$2d$2DN6UAHL$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["a"]({
            baseUrl: e.url,
            retry: e.retry,
            headers: {
                authorization: `Bearer ${e.token}`
            },
            agent: e.agent,
            responseEncoding: e.responseEncoding,
            cache: e.cache || "no-store",
            signal: e.signal,
            keepAlive: e.keepAlive
        });
        if (super(n, {
            automaticDeserialization: e.automaticDeserialization,
            enableTelemetry: !process.env.UPSTASH_DISABLE_TELEMETRY,
            latencyLogging: e.latencyLogging,
            enableAutoPipelining: e.enableAutoPipelining
        }), this.addTelemetry({
            runtime: typeof EdgeRuntime == "string" ? "edge-light" : `node@${process.version}`,
            platform: process.env.VERCEL ? "vercel" : process.env.AWS_REGION ? "aws" : "unknown",
            sdk: `@upstash/redis@${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$chunk$2d$2DN6UAHL$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["c"]}`
        }), this.enableAutoPipelining) return this.autoPipeline();
    }
    static fromEnv(e) {
        if (typeof process?.env > "u") throw new Error('Unable to get environment variables, `process.env` is undefined. If you are deploying to cloudflare, please import from "@upstash/redis/cloudflare" instead');
        let n = process?.env.UPSTASH_REDIS_REST_URL;
        if (!n) throw new Error("Unable to find environment variable: `UPSTASH_REDIS_REST_URL`");
        let o = process?.env.UPSTASH_REDIS_REST_TOKEN;
        if (!o) throw new Error("Unable to find environment variable: `UPSTASH_REDIS_REST_TOKEN`");
        return new t({
            ...e,
            url: n,
            token: o
        });
    }
};
;

})()),
"[project]/node_modules/.pnpm/@vercel+kv@2.0.0/node_modules/@vercel/kv/dist/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// src/index.ts
__turbopack_esm__({
    "VercelKV": ()=>VercelKV,
    "createClient": ()=>createClient,
    "default": ()=>src_default,
    "kv": ()=>kv
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$nodejs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@upstash+redis@1.31.6/node_modules/@upstash/redis/nodejs.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _kv = null;
process.env.UPSTASH_DISABLE_TELEMETRY = "1";
var VercelKV = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$upstash$2b$redis$40$1$2e$31$2e$6$2f$node_modules$2f40$upstash$2f$redis$2f$nodejs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Redis"] {
    // This API is based on https://github.com/redis/node-redis#scan-iterator which is not supported in @upstash/redis
    /**
   * Same as `scan` but returns an AsyncIterator to allow iteration via `for await`.
   */ async *scanIterator(options) {
        let cursor = 0;
        let keys;
        do {
            [cursor, keys] = await this.scan(cursor, options);
            for (const key of keys){
                yield key;
            }
        }while (cursor !== 0)
    }
    /**
   * Same as `hscan` but returns an AsyncIterator to allow iteration via `for await`.
   */ async *hscanIterator(key, options) {
        let cursor = 0;
        let items;
        do {
            [cursor, items] = await this.hscan(key, cursor, options);
            for (const item of items){
                yield item;
            }
        }while (cursor !== 0)
    }
    /**
   * Same as `sscan` but returns an AsyncIterator to allow iteration via `for await`.
   */ async *sscanIterator(key, options) {
        let cursor = 0;
        let items;
        do {
            [cursor, items] = await this.sscan(key, cursor, options);
            for (const item of items){
                yield item;
            }
        }while (cursor !== 0)
    }
    /**
   * Same as `zscan` but returns an AsyncIterator to allow iteration via `for await`.
   */ async *zscanIterator(key, options) {
        let cursor = 0;
        let items;
        do {
            [cursor, items] = await this.zscan(key, cursor, options);
            for (const item of items){
                yield item;
            }
        }while (cursor !== 0)
    }
};
function createClient(config) {
    return new VercelKV({
        // The Next.js team recommends no value or `default` for fetch requests's `cache` option
        // upstash/redis defaults to `no-store`, so we enforce `default`
        cache: "default",
        enableAutoPipelining: true,
        ...config
    });
}
var src_default = new Proxy({}, {
    get (target, prop, receiver) {
        if (prop === "then" || prop === "parse") {
            return Reflect.get(target, prop, receiver);
        }
        if (!_kv) {
            if (!process.env.KV_REST_API_URL || !process.env.KV_REST_API_TOKEN) {
                throw new Error("@vercel/kv: Missing required environment variables KV_REST_API_URL and KV_REST_API_TOKEN");
            }
            console.warn('\x1B[33m"The default export has been moved to a named export and it will be removed in version 1, change to import { kv }\x1B[0m"');
            _kv = createClient({
                url: process.env.KV_REST_API_URL,
                token: process.env.KV_REST_API_TOKEN
            });
        }
        return Reflect.get(_kv, prop);
    }
});
var kv = new Proxy({}, {
    get (target, prop) {
        if (!_kv) {
            if (!process.env.KV_REST_API_URL || !process.env.KV_REST_API_TOKEN) {
                throw new Error("@vercel/kv: Missing required environment variables KV_REST_API_URL and KV_REST_API_TOKEN");
            }
            _kv = createClient({
                url: process.env.KV_REST_API_URL,
                token: process.env.KV_REST_API_TOKEN
            });
        }
        return Reflect.get(_kv, prop);
    }
});
;
 //# sourceMappingURL=index.js.map

})()),
"[project]/node_modules/.pnpm/@radix-ui+react-compose-refs@1.1.0_@types+react@18.3.3_react@18.3.1/node_modules/@radix-ui/react-compose-refs/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// packages/react/compose-refs/src/composeRefs.tsx
__turbopack_esm__({
    "composeRefs": ()=>composeRefs,
    "useComposedRefs": ()=>useComposedRefs
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
function setRef(ref, value) {
    if (typeof ref === "function") {
        ref(value);
    } else if (ref !== null && ref !== void 0) {
        ref.current = value;
    }
}
function composeRefs(...refs) {
    return (node)=>refs.forEach((ref)=>setRef(ref, node));
}
function useComposedRefs(...refs) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.useCallback(composeRefs(...refs), refs);
}
;
 //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/@radix-ui+react-slot@1.1.0_@types+react@18.3.3_react@18.3.1/node_modules/@radix-ui/react-slot/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// packages/react/slot/src/Slot.tsx
__turbopack_esm__({
    "Root": ()=>Root,
    "Slot": ()=>Slot,
    "Slottable": ()=>Slottable
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$0_$40$types$2b$react$40$18$2e$3$2e$3_react$40$18$2e$3$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@radix-ui+react-compose-refs@1.1.0_@types+react@18.3.3_react@18.3.1/node_modules/@radix-ui/react-compose-refs/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
var Slot = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef((props, forwardedRef)=>{
    const { children, ...slotProps } = props;
    const childrenArray = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.Children.toArray(children);
    const slottable = childrenArray.find(isSlottable);
    if (slottable) {
        const newElement = slottable.props.children;
        const newChildren = childrenArray.map((child)=>{
            if (child === slottable) {
                if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.Children.count(newElement) > 1) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.Children.only(null);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.isValidElement(newElement) ? newElement.props.children : null;
            } else {
                return child;
            }
        });
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(SlotClone, {
            ...slotProps,
            ref: forwardedRef,
            children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.isValidElement(newElement) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.cloneElement(newElement, void 0, newChildren) : null
        });
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(SlotClone, {
        ...slotProps,
        ref: forwardedRef,
        children
    });
});
Slot.displayName = "Slot";
var SlotClone = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef((props, forwardedRef)=>{
    const { children, ...slotProps } = props;
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.isValidElement(children)) {
        const childrenRef = getElementRef(children);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.cloneElement(children, {
            ...mergeProps(slotProps, children.props),
            // @ts-ignore
            ref: forwardedRef ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$0_$40$types$2b$react$40$18$2e$3$2e$3_react$40$18$2e$3$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["composeRefs"])(forwardedRef, childrenRef) : childrenRef
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.Children.count(children) > 1 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.Children.only(null) : null;
});
SlotClone.displayName = "SlotClone";
var Slottable = ({ children })=>{
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children
    });
};
function isSlottable(child) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.isValidElement(child) && child.type === Slottable;
}
function mergeProps(slotProps, childProps) {
    const overrideProps = {
        ...childProps
    };
    for(const propName in childProps){
        const slotPropValue = slotProps[propName];
        const childPropValue = childProps[propName];
        const isHandler = /^on[A-Z]/.test(propName);
        if (isHandler) {
            if (slotPropValue && childPropValue) {
                overrideProps[propName] = (...args)=>{
                    childPropValue(...args);
                    slotPropValue(...args);
                };
            } else if (slotPropValue) {
                overrideProps[propName] = slotPropValue;
            }
        } else if (propName === "style") {
            overrideProps[propName] = {
                ...slotPropValue,
                ...childPropValue
            };
        } else if (propName === "className") {
            overrideProps[propName] = [
                slotPropValue,
                childPropValue
            ].filter(Boolean).join(" ");
        }
    }
    return {
        ...slotProps,
        ...overrideProps
    };
}
function getElementRef(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
    let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
        return element.ref;
    }
    getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
    mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
        return element.props.ref;
    }
    return element.props.ref || element.ref;
}
var Root = Slot;
;
 //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/class-variance-authority@0.7.0/node_modules/class-variance-authority/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "cva": ()=>cva,
    "cx": ()=>cx
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$0$2e$0$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/clsx@2.0.0/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const falsyToString = (value)=>typeof value === "boolean" ? "".concat(value) : value === 0 ? "0" : value;
const cx = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$0$2e$0$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"];
const cva = (base, config)=>{
    return (props)=>{
        var ref;
        if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
        const { variants, defaultVariants } = config;
        const getVariantClassNames = Object.keys(variants).map((variant)=>{
            const variantProp = props === null || props === void 0 ? void 0 : props[variant];
            const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
            if (variantProp === null) return null;
            const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
            return variants[variant][variantKey];
        });
        const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param)=>{
            let [key, value] = param;
            if (value === undefined) {
                return acc;
            }
            acc[key] = value;
            return acc;
        }, {});
        const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (ref = config.compoundVariants) === null || ref === void 0 ? void 0 : ref.reduce((acc, param1)=>{
            let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param1;
            return Object.entries(compoundVariantOptions).every((param)=>{
                let [key, value] = param;
                return Array.isArray(value) ? value.includes({
                    ...defaultVariants,
                    ...propsWithoutUndefined
                }[key]) : ({
                    ...defaultVariants,
                    ...propsWithoutUndefined
                })[key] === value;
            }) ? [
                ...acc,
                cvClass,
                cvClassName
            ] : acc;
        }, []);
        return cx(base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
    };
}; //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.5/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

"use strict";
exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

}.call(this) }),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/processor.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
class Processor {
    constructor(options){
        this.selfOptions = options || {};
        this.pipes = {};
    }
    options(options) {
        if (options) {
            this.selfOptions = options;
        }
        return this.selfOptions;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    pipe(name, pipeArg) {
        let pipe = pipeArg;
        if (typeof name === 'string') {
            if (typeof pipe === 'undefined') {
                return this.pipes[name];
            } else {
                this.pipes[name] = pipe;
            }
        }
        if (name && name.name) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            pipe = name;
            if (pipe.processor === this) {
                return pipe;
            }
            this.pipes[pipe.name] = pipe;
        }
        pipe.processor = this;
        return pipe;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    process(input, pipe) {
        let context = input;
        context.options = this.options();
        let nextPipe = pipe || input.pipe || 'default';
        let lastPipe;
        while(nextPipe){
            if (typeof context.nextAfterChildren !== 'undefined') {
                // children processed and coming back to parent
                context.next = context.nextAfterChildren;
                context.nextAfterChildren = null;
            }
            if (typeof nextPipe === 'string') {
                nextPipe = this.pipe(nextPipe);
            }
            nextPipe.process(context);
            lastPipe = nextPipe;
            nextPipe = null;
            if (context) {
                if (context.next) {
                    context = context.next;
                    nextPipe = context.pipe || lastPipe;
                }
            }
        }
        // eslint-disable-next-line @typescript-eslint/no-unsafe-return
        return context.hasResult ? context.result : undefined;
    }
}
const __TURBOPACK__default__export__ = Processor;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/pipe.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
class Pipe {
    constructor(name){
        this.name = name;
        this.filters = [];
    }
    process(input) {
        if (!this.processor) {
            throw new Error('add this pipe to a processor before using it');
        }
        const debug = this.debug;
        const length = this.filters.length;
        const context = input;
        for(let index = 0; index < length; index++){
            const filter = this.filters[index];
            if (debug) {
                this.log(`filter: ${filter.filterName}`);
            }
            filter(context);
            if (typeof context === 'object' && context.exiting) {
                context.exiting = false;
                break;
            }
        }
        if (!context.next && this.resultCheck) {
            this.resultCheck(context);
        }
    }
    log(msg) {
        console.log(`[jsondiffpatch] ${this.name} pipe, ${msg}`);
    }
    append(...args) {
        this.filters.push(...args);
        return this;
    }
    prepend(...args) {
        this.filters.unshift(...args);
        return this;
    }
    indexOf(filterName) {
        if (!filterName) {
            throw new Error('a filter name is required');
        }
        for(let index = 0; index < this.filters.length; index++){
            const filter = this.filters[index];
            if (filter.filterName === filterName) {
                return index;
            }
        }
        throw new Error(`filter not found: ${filterName}`);
    }
    list() {
        return this.filters.map((f)=>f.filterName);
    }
    after(filterName, ...params) {
        const index = this.indexOf(filterName);
        this.filters.splice(index + 1, 0, ...params);
        return this;
    }
    before(filterName, ...params) {
        const index = this.indexOf(filterName);
        this.filters.splice(index, 0, ...params);
        return this;
    }
    replace(filterName, ...params) {
        const index = this.indexOf(filterName);
        this.filters.splice(index, 1, ...params);
        return this;
    }
    remove(filterName) {
        const index = this.indexOf(filterName);
        this.filters.splice(index, 1);
        return this;
    }
    clear() {
        this.filters.length = 0;
        return this;
    }
    shouldHaveResult(should) {
        if (should === false) {
            this.resultCheck = null;
            return;
        }
        if (this.resultCheck) {
            return;
        }
        this.resultCheck = (context)=>{
            if (!context.hasResult) {
                console.log(context);
                const error = new Error(`${this.name} failed`);
                error.noResult = true;
                throw error;
            }
        };
        return this;
    }
}
const __TURBOPACK__default__export__ = Pipe;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/context.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>Context
});
class Context {
    setResult(result) {
        this.result = result;
        this.hasResult = true;
        return this;
    }
    exit() {
        this.exiting = true;
        return this;
    }
    push(child, name) {
        child.parent = this;
        if (typeof name !== 'undefined') {
            child.childName = name;
        }
        child.root = this.root || this;
        child.options = child.options || this.options;
        if (!this.children) {
            this.children = [
                child
            ];
            this.nextAfterChildren = this.next || null;
            this.next = child;
        } else {
            this.children[this.children.length - 1].next = child;
            this.children.push(child);
        }
        child.next = this;
        return this;
    }
}

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/clone.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>clone
});
function cloneRegExp(re) {
    const regexMatch = /^\/(.*)\/([gimyu]*)$/.exec(re.toString());
    return new RegExp(regexMatch[1], regexMatch[2]);
}
function clone(arg) {
    if (typeof arg !== 'object') {
        return arg;
    }
    if (arg === null) {
        return null;
    }
    if (Array.isArray(arg)) {
        return arg.map(clone);
    }
    if (arg instanceof Date) {
        return new Date(arg.getTime());
    }
    if (arg instanceof RegExp) {
        return cloneRegExp(arg);
    }
    const cloned = {};
    for(const name in arg){
        if (Object.prototype.hasOwnProperty.call(arg, name)) {
            cloned[name] = clone(arg[name]);
        }
    }
    return cloned;
}

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/diff.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/context.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$clone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/clone.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
class DiffContext extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"] {
    constructor(left, right){
        super();
        this.left = left;
        this.right = right;
        this.pipe = 'diff';
    }
    setResult(result) {
        if (this.options.cloneDiffValues && typeof result === 'object') {
            const clone = typeof this.options.cloneDiffValues === 'function' ? this.options.cloneDiffValues : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$clone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"];
            if (typeof result[0] === 'object') {
                result[0] = clone(result[0]);
            }
            if (typeof result[1] === 'object') {
                result[1] = clone(result[1]);
            }
        }
        return super.setResult(result);
    }
}
const __TURBOPACK__default__export__ = DiffContext;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/patch.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/context.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
class PatchContext extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"] {
    constructor(left, delta){
        super();
        this.left = left;
        this.delta = delta;
        this.pipe = 'patch';
    }
}
const __TURBOPACK__default__export__ = PatchContext;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/reverse.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/context.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
class ReverseContext extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$context$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"] {
    constructor(delta){
        super();
        this.delta = delta;
        this.pipe = 'reverse';
    }
}
const __TURBOPACK__default__export__ = ReverseContext;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/trivial.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "diffFilter": ()=>diffFilter,
    "patchFilter": ()=>patchFilter,
    "reverseFilter": ()=>reverseFilter
});
const diffFilter = function trivialMatchesDiffFilter(context) {
    if (context.left === context.right) {
        context.setResult(undefined).exit();
        return;
    }
    if (typeof context.left === 'undefined') {
        if (typeof context.right === 'function') {
            throw new Error('functions are not supported');
        }
        context.setResult([
            context.right
        ]).exit();
        return;
    }
    if (typeof context.right === 'undefined') {
        context.setResult([
            context.left,
            0,
            0
        ]).exit();
        return;
    }
    if (typeof context.left === 'function' || typeof context.right === 'function') {
        throw new Error('functions are not supported');
    }
    context.leftType = context.left === null ? 'null' : typeof context.left;
    context.rightType = context.right === null ? 'null' : typeof context.right;
    if (context.leftType !== context.rightType) {
        context.setResult([
            context.left,
            context.right
        ]).exit();
        return;
    }
    if (context.leftType === 'boolean' || context.leftType === 'number') {
        context.setResult([
            context.left,
            context.right
        ]).exit();
        return;
    }
    if (context.leftType === 'object') {
        context.leftIsArray = Array.isArray(context.left);
    }
    if (context.rightType === 'object') {
        context.rightIsArray = Array.isArray(context.right);
    }
    if (context.leftIsArray !== context.rightIsArray) {
        context.setResult([
            context.left,
            context.right
        ]).exit();
        return;
    }
    if (context.left instanceof RegExp) {
        if (context.right instanceof RegExp) {
            context.setResult([
                context.left.toString(),
                context.right.toString()
            ]).exit();
        } else {
            context.setResult([
                context.left,
                context.right
            ]).exit();
        }
    }
};
diffFilter.filterName = 'trivial';
const patchFilter = function trivialMatchesPatchFilter(context) {
    if (typeof context.delta === 'undefined') {
        context.setResult(context.left).exit();
        return;
    }
    context.nested = !Array.isArray(context.delta);
    if (context.nested) {
        return;
    }
    const nonNestedDelta = context.delta;
    if (nonNestedDelta.length === 1) {
        context.setResult(nonNestedDelta[0]).exit();
        return;
    }
    if (nonNestedDelta.length === 2) {
        if (context.left instanceof RegExp) {
            const regexArgs = /^\/(.*)\/([gimyu]+)$/.exec(nonNestedDelta[1]);
            if (regexArgs) {
                context.setResult(new RegExp(regexArgs[1], regexArgs[2])).exit();
                return;
            }
        }
        context.setResult(nonNestedDelta[1]).exit();
        return;
    }
    if (nonNestedDelta.length === 3 && nonNestedDelta[2] === 0) {
        context.setResult(undefined).exit();
    }
};
patchFilter.filterName = 'trivial';
const reverseFilter = function trivialReferseFilter(context) {
    if (typeof context.delta === 'undefined') {
        context.setResult(context.delta).exit();
        return;
    }
    context.nested = !Array.isArray(context.delta);
    if (context.nested) {
        return;
    }
    const nonNestedDelta = context.delta;
    if (nonNestedDelta.length === 1) {
        context.setResult([
            nonNestedDelta[0],
            0,
            0
        ]).exit();
        return;
    }
    if (nonNestedDelta.length === 2) {
        context.setResult([
            nonNestedDelta[1],
            nonNestedDelta[0]
        ]).exit();
        return;
    }
    if (nonNestedDelta.length === 3 && nonNestedDelta[2] === 0) {
        context.setResult([
            nonNestedDelta[0]
        ]).exit();
    }
};
reverseFilter.filterName = 'trivial';

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/nested.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "collectChildrenDiffFilter": ()=>collectChildrenDiffFilter,
    "collectChildrenPatchFilter": ()=>collectChildrenPatchFilter,
    "collectChildrenReverseFilter": ()=>collectChildrenReverseFilter,
    "objectsDiffFilter": ()=>objectsDiffFilter,
    "patchFilter": ()=>patchFilter,
    "reverseFilter": ()=>reverseFilter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/diff.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/patch.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/reverse.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const collectChildrenDiffFilter = (context)=>{
    if (!context || !context.children) {
        return;
    }
    const length = context.children.length;
    let child;
    let result = context.result;
    for(let index = 0; index < length; index++){
        child = context.children[index];
        if (typeof child.result === 'undefined') {
            continue;
        }
        result = result || {};
        result[child.childName] = child.result;
    }
    if (result && context.leftIsArray) {
        result._t = 'a';
    }
    context.setResult(result).exit();
};
collectChildrenDiffFilter.filterName = 'collectChildren';
const objectsDiffFilter = (context)=>{
    if (context.leftIsArray || context.leftType !== 'object') {
        return;
    }
    const left = context.left;
    const right = context.right;
    let name;
    let child;
    const propertyFilter = context.options.propertyFilter;
    for(name in left){
        if (!Object.prototype.hasOwnProperty.call(left, name)) {
            continue;
        }
        if (propertyFilter && !propertyFilter(name, context)) {
            continue;
        }
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](left[name], right[name]);
        context.push(child, name);
    }
    for(name in right){
        if (!Object.prototype.hasOwnProperty.call(right, name)) {
            continue;
        }
        if (propertyFilter && !propertyFilter(name, context)) {
            continue;
        }
        if (typeof left[name] === 'undefined') {
            child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](undefined, right[name]);
            context.push(child, name);
        }
    }
    if (!context.children || context.children.length === 0) {
        context.setResult(undefined).exit();
        return;
    }
    context.exit();
};
objectsDiffFilter.filterName = 'objects';
const patchFilter = function nestedPatchFilter(context) {
    if (!context.nested) {
        return;
    }
    const nestedDelta = context.delta;
    if (nestedDelta._t) {
        return;
    }
    const objectDelta = nestedDelta;
    let name;
    let child;
    for(name in objectDelta){
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](context.left[name], objectDelta[name]);
        context.push(child, name);
    }
    context.exit();
};
patchFilter.filterName = 'objects';
const collectChildrenPatchFilter = function collectChildrenPatchFilter(context) {
    if (!context || !context.children) {
        return;
    }
    const deltaWithChildren = context.delta;
    if (deltaWithChildren._t) {
        return;
    }
    const object = context.left;
    const length = context.children.length;
    let child;
    for(let index = 0; index < length; index++){
        child = context.children[index];
        const property = child.childName;
        if (Object.prototype.hasOwnProperty.call(context.left, property) && child.result === undefined) {
            delete object[property];
        } else if (object[property] !== child.result) {
            object[property] = child.result;
        }
    }
    context.setResult(object).exit();
};
collectChildrenPatchFilter.filterName = 'collectChildren';
const reverseFilter = function nestedReverseFilter(context) {
    if (!context.nested) {
        return;
    }
    const nestedDelta = context.delta;
    if (nestedDelta._t) {
        return;
    }
    const objectDelta = context.delta;
    let name;
    let child;
    for(name in objectDelta){
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](objectDelta[name]);
        context.push(child, name);
    }
    context.exit();
};
reverseFilter.filterName = 'objects';
const collectChildrenReverseFilter = (context)=>{
    if (!context || !context.children) {
        return;
    }
    const deltaWithChildren = context.delta;
    if (deltaWithChildren._t) {
        return;
    }
    const length = context.children.length;
    let child;
    const delta = {};
    for(let index = 0; index < length; index++){
        child = context.children[index];
        const property = child.childName;
        if (delta[property] !== child.result) {
            delta[property] = child.result;
        }
    }
    context.setResult(delta).exit();
};
collectChildrenReverseFilter.filterName = 'collectChildren';

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/lcs.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

/*

LCS implementation that supports arrays or strings

reference: http://en.wikipedia.org/wiki/Longest_common_subsequence_problem

*/ __turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
const defaultMatch = function(array1, array2, index1, index2) {
    return array1[index1] === array2[index2];
};
const lengthMatrix = function(array1, array2, match, context) {
    const len1 = array1.length;
    const len2 = array2.length;
    let x, y;
    // initialize empty matrix of len1+1 x len2+1
    const matrix = new Array(len1 + 1);
    for(x = 0; x < len1 + 1; x++){
        matrix[x] = new Array(len2 + 1);
        for(y = 0; y < len2 + 1; y++){
            matrix[x][y] = 0;
        }
    }
    matrix.match = match;
    // save sequence lengths for each coordinate
    for(x = 1; x < len1 + 1; x++){
        for(y = 1; y < len2 + 1; y++){
            if (match(array1, array2, x - 1, y - 1, context)) {
                matrix[x][y] = matrix[x - 1][y - 1] + 1;
            } else {
                matrix[x][y] = Math.max(matrix[x - 1][y], matrix[x][y - 1]);
            }
        }
    }
    return matrix;
};
const backtrack = function(matrix, array1, array2, context) {
    let index1 = array1.length;
    let index2 = array2.length;
    const subsequence = {
        sequence: [],
        indices1: [],
        indices2: []
    };
    while(index1 !== 0 && index2 !== 0){
        const sameLetter = matrix.match(array1, array2, index1 - 1, index2 - 1, context);
        if (sameLetter) {
            subsequence.sequence.unshift(array1[index1 - 1]);
            subsequence.indices1.unshift(index1 - 1);
            subsequence.indices2.unshift(index2 - 1);
            --index1;
            --index2;
        } else {
            const valueAtMatrixAbove = matrix[index1][index2 - 1];
            const valueAtMatrixLeft = matrix[index1 - 1][index2];
            if (valueAtMatrixAbove > valueAtMatrixLeft) {
                --index2;
            } else {
                --index1;
            }
        }
    }
    return subsequence;
};
const get = function(array1, array2, match, context) {
    const innerContext = context || {};
    const matrix = lengthMatrix(array1, array2, match || defaultMatch, innerContext);
    return backtrack(matrix, array1, array2, innerContext);
};
const __TURBOPACK__default__export__ = {
    get
};

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/arrays.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "collectChildrenPatchFilter": ()=>collectChildrenPatchFilter,
    "collectChildrenReverseFilter": ()=>collectChildrenReverseFilter,
    "diffFilter": ()=>diffFilter,
    "patchFilter": ()=>patchFilter,
    "reverseFilter": ()=>reverseFilter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/diff.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/patch.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/reverse.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$lcs$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/lcs.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const ARRAY_MOVE = 3;
function arraysHaveMatchByRef(array1, array2, len1, len2) {
    for(let index1 = 0; index1 < len1; index1++){
        const val1 = array1[index1];
        for(let index2 = 0; index2 < len2; index2++){
            const val2 = array2[index2];
            if (index1 !== index2 && val1 === val2) {
                return true;
            }
        }
    }
}
function matchItems(array1, array2, index1, index2, context) {
    const value1 = array1[index1];
    const value2 = array2[index2];
    if (value1 === value2) {
        return true;
    }
    if (typeof value1 !== 'object' || typeof value2 !== 'object') {
        return false;
    }
    const objectHash = context.objectHash;
    if (!objectHash) {
        // no way to match objects was provided, try match by position
        return context.matchByPosition && index1 === index2;
    }
    context.hashCache1 = context.hashCache1 || [];
    let hash1 = context.hashCache1[index1];
    if (typeof hash1 === 'undefined') {
        context.hashCache1[index1] = hash1 = objectHash(value1, index1);
    }
    if (typeof hash1 === 'undefined') {
        return false;
    }
    context.hashCache2 = context.hashCache2 || [];
    let hash2 = context.hashCache2[index2];
    if (typeof hash2 === 'undefined') {
        context.hashCache2[index2] = hash2 = objectHash(value2, index2);
    }
    if (typeof hash2 === 'undefined') {
        return false;
    }
    return hash1 === hash2;
}
const diffFilter = function arraysDiffFilter(context) {
    if (!context.leftIsArray) {
        return;
    }
    const matchContext = {
        objectHash: context.options && context.options.objectHash,
        matchByPosition: context.options && context.options.matchByPosition
    };
    let commonHead = 0;
    let commonTail = 0;
    let index;
    let index1;
    let index2;
    const array1 = context.left;
    const array2 = context.right;
    const len1 = array1.length;
    const len2 = array2.length;
    let child;
    if (len1 > 0 && len2 > 0 && !matchContext.objectHash && typeof matchContext.matchByPosition !== 'boolean') {
        matchContext.matchByPosition = !arraysHaveMatchByRef(array1, array2, len1, len2);
    }
    // separate common head
    while(commonHead < len1 && commonHead < len2 && matchItems(array1, array2, commonHead, commonHead, matchContext)){
        index = commonHead;
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](array1[index], array2[index]);
        context.push(child, index);
        commonHead++;
    }
    // separate common tail
    while(commonTail + commonHead < len1 && commonTail + commonHead < len2 && matchItems(array1, array2, len1 - 1 - commonTail, len2 - 1 - commonTail, matchContext)){
        index1 = len1 - 1 - commonTail;
        index2 = len2 - 1 - commonTail;
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](array1[index1], array2[index2]);
        context.push(child, index2);
        commonTail++;
    }
    let result;
    if (commonHead + commonTail === len1) {
        if (len1 === len2) {
            // arrays are identical
            context.setResult(undefined).exit();
            return;
        }
        // trivial case, a block (1 or more consecutive items) was added
        result = result || {
            _t: 'a'
        };
        for(index = commonHead; index < len2 - commonTail; index++){
            result[index] = [
                array2[index]
            ];
        }
        context.setResult(result).exit();
        return;
    }
    if (commonHead + commonTail === len2) {
        // trivial case, a block (1 or more consecutive items) was removed
        result = result || {
            _t: 'a'
        };
        for(index = commonHead; index < len1 - commonTail; index++){
            result[`_${index}`] = [
                array1[index],
                0,
                0
            ];
        }
        context.setResult(result).exit();
        return;
    }
    // reset hash cache
    delete matchContext.hashCache1;
    delete matchContext.hashCache2;
    // diff is not trivial, find the LCS (Longest Common Subsequence)
    const trimmed1 = array1.slice(commonHead, len1 - commonTail);
    const trimmed2 = array2.slice(commonHead, len2 - commonTail);
    const seq = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$lcs$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].get(trimmed1, trimmed2, matchItems, matchContext);
    const removedItems = [];
    result = result || {
        _t: 'a'
    };
    for(index = commonHead; index < len1 - commonTail; index++){
        if (seq.indices1.indexOf(index - commonHead) < 0) {
            // removed
            result[`_${index}`] = [
                array1[index],
                0,
                0
            ];
            removedItems.push(index);
        }
    }
    let detectMove = true;
    if (context.options && context.options.arrays && context.options.arrays.detectMove === false) {
        detectMove = false;
    }
    let includeValueOnMove = false;
    if (context.options && context.options.arrays && context.options.arrays.includeValueOnMove) {
        includeValueOnMove = true;
    }
    const removedItemsLength = removedItems.length;
    for(index = commonHead; index < len2 - commonTail; index++){
        const indexOnArray2 = seq.indices2.indexOf(index - commonHead);
        if (indexOnArray2 < 0) {
            // added, try to match with a removed item and register as position move
            let isMove = false;
            if (detectMove && removedItemsLength > 0) {
                for(let removeItemIndex1 = 0; removeItemIndex1 < removedItemsLength; removeItemIndex1++){
                    index1 = removedItems[removeItemIndex1];
                    if (matchItems(trimmed1, trimmed2, index1 - commonHead, index - commonHead, matchContext)) {
                        // store position move as: [originalValue, newPosition, ARRAY_MOVE]
                        result[`_${index1}`].splice(1, 2, index, ARRAY_MOVE);
                        if (!includeValueOnMove) {
                            // don't include moved value on diff, to save bytes
                            result[`_${index1}`][0] = '';
                        }
                        index2 = index;
                        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](array1[index1], array2[index2]);
                        context.push(child, index2);
                        removedItems.splice(removeItemIndex1, 1);
                        isMove = true;
                        break;
                    }
                }
            }
            if (!isMove) {
                // added
                result[index] = [
                    array2[index]
                ];
            }
        } else {
            // match, do inner diff
            index1 = seq.indices1[indexOnArray2] + commonHead;
            index2 = seq.indices2[indexOnArray2] + commonHead;
            child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](array1[index1], array2[index2]);
            context.push(child, index2);
        }
    }
    context.setResult(result).exit();
};
diffFilter.filterName = 'arrays';
const compare = {
    numerically (a, b) {
        return a - b;
    },
    numericallyBy (name) {
        return (a, b)=>a[name] - b[name];
    }
};
const patchFilter = function nestedPatchFilter(context) {
    if (!context.nested) {
        return;
    }
    const nestedDelta = context.delta;
    if (nestedDelta._t !== 'a') {
        return;
    }
    let index;
    let index1;
    const delta = nestedDelta;
    const array = context.left;
    // first, separate removals, insertions and modifications
    let toRemove = [];
    let toInsert = [];
    const toModify = [];
    for(index in delta){
        if (index !== '_t') {
            if (index[0] === '_') {
                const removedOrMovedIndex = index;
                // removed item from original array
                if (delta[removedOrMovedIndex][2] === 0 || delta[removedOrMovedIndex][2] === ARRAY_MOVE) {
                    toRemove.push(parseInt(index.slice(1), 10));
                } else {
                    throw new Error('only removal or move can be applied at original array indices,' + ` invalid diff type: ${delta[removedOrMovedIndex][2]}`);
                }
            } else {
                const numberIndex = index;
                if (delta[numberIndex].length === 1) {
                    // added item at new array
                    toInsert.push({
                        index: parseInt(numberIndex, 10),
                        value: delta[numberIndex][0]
                    });
                } else {
                    // modified item at new array
                    toModify.push({
                        index: parseInt(numberIndex, 10),
                        delta: delta[numberIndex]
                    });
                }
            }
        }
    }
    // remove items, in reverse order to avoid sawing our own floor
    toRemove = toRemove.sort(compare.numerically);
    for(index = toRemove.length - 1; index >= 0; index--){
        index1 = toRemove[index];
        const indexDiff = delta[`_${index1}`];
        const removedValue = array.splice(index1, 1)[0];
        if (indexDiff[2] === ARRAY_MOVE) {
            // reinsert later
            toInsert.push({
                index: indexDiff[1],
                value: removedValue
            });
        }
    }
    // insert items, in reverse order to avoid moving our own floor
    toInsert = toInsert.sort(compare.numericallyBy('index'));
    const toInsertLength = toInsert.length;
    for(index = 0; index < toInsertLength; index++){
        const insertion = toInsert[index];
        array.splice(insertion.index, 0, insertion.value);
    }
    // apply modifications
    const toModifyLength = toModify.length;
    let child;
    if (toModifyLength > 0) {
        for(index = 0; index < toModifyLength; index++){
            const modification = toModify[index];
            child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](array[modification.index], modification.delta);
            context.push(child, modification.index);
        }
    }
    if (!context.children) {
        context.setResult(array).exit();
        return;
    }
    context.exit();
};
patchFilter.filterName = 'arrays';
const collectChildrenPatchFilter = function collectChildrenPatchFilter(context) {
    if (!context || !context.children) {
        return;
    }
    const deltaWithChildren = context.delta;
    if (deltaWithChildren._t !== 'a') {
        return;
    }
    const array = context.left;
    const length = context.children.length;
    let child;
    for(let index = 0; index < length; index++){
        child = context.children[index];
        const arrayIndex = child.childName;
        array[arrayIndex] = child.result;
    }
    context.setResult(array).exit();
};
collectChildrenPatchFilter.filterName = 'arraysCollectChildren';
const reverseFilter = function arraysReverseFilter(context) {
    if (!context.nested) {
        const nonNestedDelta = context.delta;
        if (nonNestedDelta[2] === ARRAY_MOVE) {
            const arrayMoveDelta = nonNestedDelta;
            context.newName = `_${arrayMoveDelta[1]}`;
            context.setResult([
                arrayMoveDelta[0],
                parseInt(context.childName.substring(1), 10),
                ARRAY_MOVE
            ]).exit();
        }
        return;
    }
    const nestedDelta = context.delta;
    if (nestedDelta._t !== 'a') {
        return;
    }
    const arrayDelta = nestedDelta;
    let name;
    let child;
    for(name in arrayDelta){
        if (name === '_t') {
            continue;
        }
        child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](arrayDelta[name]);
        context.push(child, name);
    }
    context.exit();
};
reverseFilter.filterName = 'arrays';
const reverseArrayDeltaIndex = (delta, index, itemDelta)=>{
    if (typeof index === 'string' && index[0] === '_') {
        return parseInt(index.substring(1), 10);
    } else if (Array.isArray(itemDelta) && itemDelta[2] === 0) {
        return `_${index}`;
    }
    let reverseIndex = +index;
    for(const deltaIndex in delta){
        const deltaItem = delta[deltaIndex];
        if (Array.isArray(deltaItem)) {
            if (deltaItem[2] === ARRAY_MOVE) {
                const moveFromIndex = parseInt(deltaIndex.substring(1), 10);
                const moveToIndex = deltaItem[1];
                if (moveToIndex === +index) {
                    return moveFromIndex;
                }
                if (moveFromIndex <= reverseIndex && moveToIndex > reverseIndex) {
                    reverseIndex++;
                } else if (moveFromIndex >= reverseIndex && moveToIndex < reverseIndex) {
                    reverseIndex--;
                }
            } else if (deltaItem[2] === 0) {
                const deleteIndex = parseInt(deltaIndex.substring(1), 10);
                if (deleteIndex <= reverseIndex) {
                    reverseIndex++;
                }
            } else if (deltaItem.length === 1 && parseInt(deltaIndex, 10) <= reverseIndex) {
                reverseIndex--;
            }
        }
    }
    return reverseIndex;
};
const collectChildrenReverseFilter = (context)=>{
    if (!context || !context.children) {
        return;
    }
    const deltaWithChildren = context.delta;
    if (deltaWithChildren._t !== 'a') {
        return;
    }
    const arrayDelta = deltaWithChildren;
    const length = context.children.length;
    let child;
    const delta = {
        _t: 'a'
    };
    for(let index = 0; index < length; index++){
        child = context.children[index];
        let name = child.newName;
        if (typeof name === 'undefined') {
            name = reverseArrayDeltaIndex(arrayDelta, child.childName, child.result);
        }
        if (delta[name] !== child.result) {
            // There's no way to type this well.
            delta[name] = child.result;
        }
    }
    context.setResult(delta).exit();
};
collectChildrenReverseFilter.filterName = 'arraysCollectChildren';

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/dates.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "diffFilter": ()=>diffFilter
});
const diffFilter = function datesDiffFilter(context) {
    if (context.left instanceof Date) {
        if (context.right instanceof Date) {
            if (context.left.getTime() !== context.right.getTime()) {
                context.setResult([
                    context.left,
                    context.right
                ]);
            } else {
                context.setResult(undefined);
            }
        } else {
            context.setResult([
                context.left,
                context.right
            ]);
        }
        context.exit();
    } else if (context.right instanceof Date) {
        context.setResult([
            context.left,
            context.right
        ]).exit();
    }
};
diffFilter.filterName = 'dates';

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/texts.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "diffFilter": ()=>diffFilter,
    "patchFilter": ()=>patchFilter,
    "reverseFilter": ()=>reverseFilter
});
const TEXT_DIFF = 2;
const DEFAULT_MIN_LENGTH = 60;
let cachedDiffPatch = null;
function getDiffMatchPatch(options, required) {
    var _a;
    if (!cachedDiffPatch) {
        let instance;
        if ((_a = options === null || options === void 0 ? void 0 : options.textDiff) === null || _a === void 0 ? void 0 : _a.diffMatchPatch) {
            instance = new options.textDiff.diffMatchPatch();
        } else {
            if (!required) {
                return null;
            }
            const error = new Error('The diff-match-patch library was not provided. Pass the library in through the options or use the `jsondiffpatch/with-text-diffs` entry-point.');
            // eslint-disable-next-line camelcase
            error.diff_match_patch_not_found = true;
            throw error;
        }
        cachedDiffPatch = {
            diff: function(txt1, txt2) {
                return instance.patch_toText(instance.patch_make(txt1, txt2));
            },
            patch: function(txt1, patch) {
                const results = instance.patch_apply(instance.patch_fromText(patch), txt1);
                for(let i = 0; i < results[1].length; i++){
                    if (!results[1][i]) {
                        const error = new Error('text patch failed');
                        error.textPatchFailed = true;
                    }
                }
                return results[0];
            }
        };
    }
    return cachedDiffPatch;
}
const diffFilter = function textsDiffFilter(context) {
    if (context.leftType !== 'string') {
        return;
    }
    const left = context.left;
    const right = context.right;
    const minLength = context.options && context.options.textDiff && context.options.textDiff.minLength || DEFAULT_MIN_LENGTH;
    if (left.length < minLength || right.length < minLength) {
        context.setResult([
            left,
            right
        ]).exit();
        return;
    }
    // large text, try to use a text-diff algorithm
    const diffMatchPatch = getDiffMatchPatch(context.options);
    if (!diffMatchPatch) {
        // diff-match-patch library not available,
        // fallback to regular string replace
        context.setResult([
            left,
            right
        ]).exit();
        return;
    }
    const diff = diffMatchPatch.diff;
    context.setResult([
        diff(left, right),
        0,
        TEXT_DIFF
    ]).exit();
};
diffFilter.filterName = 'texts';
const patchFilter = function textsPatchFilter(context) {
    if (context.nested) {
        return;
    }
    const nonNestedDelta = context.delta;
    if (nonNestedDelta[2] !== TEXT_DIFF) {
        return;
    }
    const textDiffDelta = nonNestedDelta;
    // text-diff, use a text-patch algorithm
    const patch = getDiffMatchPatch(context.options, true).patch;
    context.setResult(patch(context.left, textDiffDelta[0])).exit();
};
patchFilter.filterName = 'texts';
const textDeltaReverse = function(delta) {
    let i;
    let l;
    let line;
    let lineTmp;
    let header = null;
    const headerRegex = /^@@ +-(\d+),(\d+) +\+(\d+),(\d+) +@@$/;
    let lineHeader;
    const lines = delta.split('\n');
    for(i = 0, l = lines.length; i < l; i++){
        line = lines[i];
        const lineStart = line.slice(0, 1);
        if (lineStart === '@') {
            header = headerRegex.exec(line);
            lineHeader = i;
            // fix header
            lines[lineHeader] = '@@ -' + header[3] + ',' + header[4] + ' +' + header[1] + ',' + header[2] + ' @@';
        } else if (lineStart === '+') {
            lines[i] = '-' + lines[i].slice(1);
            if (lines[i - 1].slice(0, 1) === '+') {
                // swap lines to keep default order (-+)
                lineTmp = lines[i];
                lines[i] = lines[i - 1];
                lines[i - 1] = lineTmp;
            }
        } else if (lineStart === '-') {
            lines[i] = '+' + lines[i].slice(1);
        }
    }
    return lines.join('\n');
};
const reverseFilter = function textsReverseFilter(context) {
    if (context.nested) {
        return;
    }
    const nonNestedDelta = context.delta;
    if (nonNestedDelta[2] !== TEXT_DIFF) {
        return;
    }
    const textDiffDelta = nonNestedDelta;
    // text-diff, use a text-diff algorithm
    context.setResult([
        textDeltaReverse(textDiffDelta[0]),
        0,
        TEXT_DIFF
    ]).exit();
};
reverseFilter.filterName = 'texts';

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/diffpatcher.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$processor$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/processor.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$pipe$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/pipe.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/diff.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/patch.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/contexts/reverse.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$clone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/clone.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$trivial$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/trivial.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/nested.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/arrays.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$dates$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/dates.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$texts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/filters/texts.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
;
;
;
class DiffPatcher {
    constructor(options){
        this.processor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$processor$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](options);
        this.processor.pipe(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$pipe$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]('diff').append(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.collectChildrenDiffFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$trivial$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.diffFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$dates$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.diffFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$texts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.diffFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.objectsDiffFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.diffFilter).shouldHaveResult());
        this.processor.pipe(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$pipe$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]('patch').append(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.collectChildrenPatchFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.collectChildrenPatchFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$trivial$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.patchFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$texts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.patchFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.patchFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.patchFilter).shouldHaveResult());
        this.processor.pipe(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$pipe$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]('reverse').append(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.collectChildrenReverseFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.collectChildrenReverseFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$trivial$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.reverseFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$texts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.reverseFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$nested$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.reverseFilter, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$filters$2f$arrays$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.reverseFilter).shouldHaveResult());
    }
    options(options) {
        return this.processor.options(options);
    }
    diff(left, right) {
        return this.processor.process(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$diff$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](left, right));
    }
    patch(left, delta) {
        return this.processor.process(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$patch$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](left, delta));
    }
    reverse(delta) {
        return this.processor.process(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$contexts$2f$reverse$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](delta));
    }
    unpatch(right, delta) {
        return this.patch(right, this.reverse(delta));
    }
    clone(value) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$clone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(value);
    }
}
const __TURBOPACK__default__export__ = DiffPatcher;

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "clone": ()=>clone,
    "create": ()=>create,
    "diff": ()=>diff,
    "patch": ()=>patch,
    "reverse": ()=>reverse,
    "unpatch": ()=>unpatch
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/diffpatcher.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
function create(options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](options);
}
let defaultInstance;
function diff(left, right) {
    if (!defaultInstance) {
        defaultInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]();
    }
    return defaultInstance.diff(left, right);
}
function patch(left, delta) {
    if (!defaultInstance) {
        defaultInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]();
    }
    return defaultInstance.patch(left, delta);
}
function unpatch(right, delta) {
    if (!defaultInstance) {
        defaultInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]();
    }
    return defaultInstance.unpatch(right, delta);
}
function reverse(delta) {
    if (!defaultInstance) {
        defaultInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]();
    }
    return defaultInstance.reverse(delta);
}
function clone(value) {
    if (!defaultInstance) {
        defaultInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]();
    }
    return defaultInstance.clone(value);
}

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/date-reviver.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// use as 2nd parameter for JSON.parse to revive Date instances
__turbopack_esm__({
    "default": ()=>dateReviver
});
function dateReviver(key, value) {
    let parts;
    if (typeof value === 'string') {
        parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d*))?(Z|([+-])(\d{2}):(\d{2}))$/.exec(value);
        if (parts) {
            return new Date(Date.UTC(+parts[1], +parts[2] - 1, +parts[3], +parts[4], +parts[5], +parts[6], +(parts[7] || 0)));
        }
    }
    return value;
}

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <exports>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "DiffPatcher": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"],
    "clone": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["clone"],
    "create": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["create"],
    "dateReviver": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$date$2d$reviver$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"],
    "diff": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["diff"],
    "patch": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["patch"],
    "reverse": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reverse"],
    "unpatch": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["unpatch"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$diffpatcher$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/diffpatcher.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$date$2d$reviver$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/date-reviver.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <facade>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "DiffPatcher": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["DiffPatcher"],
    "clone": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["clone"],
    "create": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["create"],
    "dateReviver": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["dateReviver"],
    "diff": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["diff"],
    "patch": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["patch"],
    "reverse": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["reverse"],
    "unpatch": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["unpatch"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <exports>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/node_modules/.pnpm/@ai-sdk+provider@0.0.11/node_modules/@ai-sdk/provider/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// src/errors/api-call-error.ts
__turbopack_esm__({
    "APICallError": ()=>APICallError,
    "DownloadError": ()=>DownloadError,
    "EmptyResponseBodyError": ()=>EmptyResponseBodyError,
    "InvalidArgumentError": ()=>InvalidArgumentError,
    "InvalidDataContentError": ()=>InvalidDataContentError,
    "InvalidPromptError": ()=>InvalidPromptError,
    "InvalidResponseDataError": ()=>InvalidResponseDataError,
    "InvalidToolArgumentsError": ()=>InvalidToolArgumentsError,
    "JSONParseError": ()=>JSONParseError,
    "LoadAPIKeyError": ()=>LoadAPIKeyError,
    "LoadSettingError": ()=>LoadSettingError,
    "NoContentGeneratedError": ()=>NoContentGeneratedError,
    "NoObjectGeneratedError": ()=>NoObjectGeneratedError,
    "NoSuchToolError": ()=>NoSuchToolError,
    "RetryError": ()=>RetryError,
    "TooManyEmbeddingValuesForCallError": ()=>TooManyEmbeddingValuesForCallError,
    "ToolCallParseError": ()=>ToolCallParseError,
    "TypeValidationError": ()=>TypeValidationError,
    "UnsupportedFunctionalityError": ()=>UnsupportedFunctionalityError,
    "UnsupportedJSONSchemaError": ()=>UnsupportedJSONSchemaError
});
var APICallError = class extends Error {
    constructor({ message, url, requestBodyValues, statusCode, responseHeaders, responseBody, cause, isRetryable = statusCode != null && (statusCode === 408 || // request timeout
    statusCode === 409 || // conflict
    statusCode === 429 || // too many requests
    statusCode >= 500), // server error
    data }){
        super(message);
        this.name = "AI_APICallError";
        this.url = url;
        this.requestBodyValues = requestBodyValues;
        this.statusCode = statusCode;
        this.responseHeaders = responseHeaders;
        this.responseBody = responseBody;
        this.cause = cause;
        this.isRetryable = isRetryable;
        this.data = data;
    }
    static isAPICallError(error) {
        return error instanceof Error && error.name === "AI_APICallError" && typeof error.url === "string" && typeof error.requestBodyValues === "object" && (error.statusCode == null || typeof error.statusCode === "number") && (error.responseHeaders == null || typeof error.responseHeaders === "object") && (error.responseBody == null || typeof error.responseBody === "string") && (error.cause == null || typeof error.cause === "object") && typeof error.isRetryable === "boolean" && (error.data == null || typeof error.data === "object");
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            url: this.url,
            requestBodyValues: this.requestBodyValues,
            statusCode: this.statusCode,
            responseHeaders: this.responseHeaders,
            responseBody: this.responseBody,
            cause: this.cause,
            isRetryable: this.isRetryable,
            data: this.data
        };
    }
};
// src/errors/download-error.ts
var DownloadError = class extends Error {
    constructor({ url, statusCode, statusText, cause, message = cause == null ? `Failed to download ${url}: ${statusCode} ${statusText}` : `Failed to download ${url}: ${cause}` }){
        super(message);
        this.name = "AI_DownloadError";
        this.url = url;
        this.statusCode = statusCode;
        this.statusText = statusText;
        this.cause = cause;
    }
    static isDownloadError(error) {
        return error instanceof Error && error.name === "AI_DownloadError" && typeof error.url === "string" && (error.statusCode == null || typeof error.statusCode === "number") && (error.statusText == null || typeof error.statusText === "string");
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            url: this.url,
            statusCode: this.statusCode,
            statusText: this.statusText,
            cause: this.cause
        };
    }
};
// src/errors/empty-response-body-error.ts
var EmptyResponseBodyError = class extends Error {
    constructor({ message = "Empty response body" } = {}){
        super(message);
        this.name = "AI_EmptyResponseBodyError";
    }
    static isEmptyResponseBodyError(error) {
        return error instanceof Error && error.name === "AI_EmptyResponseBodyError";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack
        };
    }
};
// src/errors/invalid-argument-error.ts
var InvalidArgumentError = class extends Error {
    constructor({ parameter, value, message }){
        super(`Invalid argument for parameter ${parameter}: ${message}`);
        this.name = "AI_InvalidArgumentError";
        this.parameter = parameter;
        this.value = value;
    }
    static isInvalidArgumentError(error) {
        return error instanceof Error && error.name === "AI_InvalidArgumentError" && typeof error.parameter === "string" && typeof error.value === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            parameter: this.parameter,
            value: this.value
        };
    }
};
// src/errors/invalid-data-content-error.ts
var InvalidDataContentError = class extends Error {
    constructor({ content, cause, message = `Invalid data content. Expected a base64 string, Uint8Array, ArrayBuffer, or Buffer, but got ${typeof content}.` }){
        super(message);
        this.name = "AI_InvalidDataContentError";
        this.cause = cause;
        this.content = content;
    }
    static isInvalidDataContentError(error) {
        return error instanceof Error && error.name === "AI_InvalidDataContentError" && error.content != null;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            cause: this.cause,
            content: this.content
        };
    }
};
// src/errors/invalid-prompt-error.ts
var InvalidPromptError = class extends Error {
    constructor({ prompt: prompt2, message }){
        super(`Invalid prompt: ${message}`);
        this.name = "AI_InvalidPromptError";
        this.prompt = prompt2;
    }
    static isInvalidPromptError(error) {
        return error instanceof Error && error.name === "AI_InvalidPromptError" && prompt != null;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            prompt: this.prompt
        };
    }
};
// src/errors/invalid-response-data-error.ts
var InvalidResponseDataError = class extends Error {
    constructor({ data, message = `Invalid response data: ${JSON.stringify(data)}.` }){
        super(message);
        this.name = "AI_InvalidResponseDataError";
        this.data = data;
    }
    static isInvalidResponseDataError(error) {
        return error instanceof Error && error.name === "AI_InvalidResponseDataError" && error.data != null;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            data: this.data
        };
    }
};
// src/errors/get-error-message.ts
function getErrorMessage(error) {
    if (error == null) {
        return "unknown error";
    }
    if (typeof error === "string") {
        return error;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return JSON.stringify(error);
}
// src/errors/invalid-tool-arguments-error.ts
var InvalidToolArgumentsError = class extends Error {
    constructor({ toolArgs, toolName, cause, message = `Invalid arguments for tool ${toolName}: ${getErrorMessage(cause)}` }){
        super(message);
        this.name = "AI_InvalidToolArgumentsError";
        this.toolArgs = toolArgs;
        this.toolName = toolName;
        this.cause = cause;
    }
    static isInvalidToolArgumentsError(error) {
        return error instanceof Error && error.name === "AI_InvalidToolArgumentsError" && typeof error.toolName === "string" && typeof error.toolArgs === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            cause: this.cause,
            stack: this.stack,
            toolName: this.toolName,
            toolArgs: this.toolArgs
        };
    }
};
// src/errors/json-parse-error.ts
var JSONParseError = class extends Error {
    constructor({ text, cause }){
        super(`JSON parsing failed: Text: ${text}.
Error message: ${getErrorMessage(cause)}`);
        this.name = "AI_JSONParseError";
        this.cause = cause;
        this.text = text;
    }
    static isJSONParseError(error) {
        return error instanceof Error && error.name === "AI_JSONParseError" && typeof error.text === "string" && typeof error.cause === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            cause: this.cause,
            stack: this.stack,
            valueText: this.text
        };
    }
};
// src/errors/load-api-key-error.ts
var LoadAPIKeyError = class extends Error {
    constructor({ message }){
        super(message);
        this.name = "AI_LoadAPIKeyError";
    }
    static isLoadAPIKeyError(error) {
        return error instanceof Error && error.name === "AI_LoadAPIKeyError";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message
        };
    }
};
// src/errors/load-setting-error.ts
var LoadSettingError = class extends Error {
    constructor({ message }){
        super(message);
        this.name = "AI_LoadSettingError";
    }
    static isLoadSettingError(error) {
        return error instanceof Error && error.name === "AI_LoadSettingError";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message
        };
    }
};
// src/errors/no-content-generated-error.ts
var NoContentGeneratedError = class extends Error {
    constructor({ message = "No content generated." } = {}){
        super(message);
        this.name = "AI_NoContentGeneratedError";
    }
    static isNoContentGeneratedError(error) {
        return error instanceof Error && error.name === "AI_NoContentGeneratedError";
    }
    toJSON() {
        return {
            name: this.name,
            cause: this.cause,
            message: this.message,
            stack: this.stack
        };
    }
};
// src/errors/no-object-generated-error.ts
var NoObjectGeneratedError = class extends Error {
    constructor({ message = "No object generated." } = {}){
        super(message);
        this.name = "AI_NoObjectGeneratedError";
    }
    static isNoObjectGeneratedError(error) {
        return error instanceof Error && error.name === "AI_NoObjectGeneratedError";
    }
    toJSON() {
        return {
            name: this.name,
            cause: this.cause,
            message: this.message,
            stack: this.stack
        };
    }
};
// src/errors/no-such-tool-error.ts
var NoSuchToolError = class extends Error {
    constructor({ toolName, availableTools = void 0, message = `Model tried to call unavailable tool '${toolName}'. ${availableTools === void 0 ? "No tools are available." : `Available tools: ${availableTools.join(", ")}.`}` }){
        super(message);
        this.name = "AI_NoSuchToolError";
        this.toolName = toolName;
        this.availableTools = availableTools;
    }
    static isNoSuchToolError(error) {
        return error instanceof Error && error.name === "AI_NoSuchToolError" && "toolName" in error && error.toolName != void 0 && typeof error.name === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            toolName: this.toolName,
            availableTools: this.availableTools
        };
    }
};
// src/errors/retry-error.ts
var RetryError = class extends Error {
    constructor({ message, reason, errors }){
        super(message);
        this.name = "AI_RetryError";
        this.reason = reason;
        this.errors = errors;
        this.lastError = errors[errors.length - 1];
    }
    static isRetryError(error) {
        return error instanceof Error && error.name === "AI_RetryError" && typeof error.reason === "string" && Array.isArray(error.errors);
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            reason: this.reason,
            lastError: this.lastError,
            errors: this.errors
        };
    }
};
// src/errors/too-many-embedding-values-for-call-error.ts
var TooManyEmbeddingValuesForCallError = class extends Error {
    constructor(options){
        super(`Too many values for a single embedding call. The ${options.provider} model "${options.modelId}" can only embed up to ${options.maxEmbeddingsPerCall} values per call, but ${options.values.length} values were provided.`);
        this.name = "AI_TooManyEmbeddingValuesForCallError";
        this.provider = options.provider;
        this.modelId = options.modelId;
        this.maxEmbeddingsPerCall = options.maxEmbeddingsPerCall;
        this.values = options.values;
    }
    static isInvalidPromptError(error) {
        return error instanceof Error && error.name === "AI_TooManyEmbeddingValuesForCallError" && "provider" in error && typeof error.provider === "string" && "modelId" in error && typeof error.modelId === "string" && "maxEmbeddingsPerCall" in error && typeof error.maxEmbeddingsPerCall === "number" && "values" in error && Array.isArray(error.values);
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            provider: this.provider,
            modelId: this.modelId,
            maxEmbeddingsPerCall: this.maxEmbeddingsPerCall,
            values: this.values
        };
    }
};
// src/errors/tool-call-parse-error.ts
var ToolCallParseError = class extends Error {
    constructor({ cause, text, tools, message = `Failed to parse tool calls: ${getErrorMessage(cause)}` }){
        super(message);
        this.name = "AI_ToolCallParseError";
        this.cause = cause;
        this.text = text;
        this.tools = tools;
    }
    static isToolCallParseError(error) {
        return error instanceof Error && error.name === "AI_ToolCallParseError" && "cause" in error && error.cause != void 0 && "text" in error && error.text != void 0 && typeof error.text === "string" && "tools" in error && error.tools != void 0;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            cause: this.cause,
            text: this.text,
            tools: this.tools
        };
    }
};
// src/errors/type-validation-error.ts
var TypeValidationError = class extends Error {
    constructor({ value, cause }){
        super(`Type validation failed: Value: ${JSON.stringify(value)}.
Error message: ${getErrorMessage(cause)}`);
        this.name = "AI_TypeValidationError";
        this.cause = cause;
        this.value = value;
    }
    static isTypeValidationError(error) {
        return error instanceof Error && error.name === "AI_TypeValidationError";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            cause: this.cause,
            stack: this.stack,
            value: this.value
        };
    }
};
// src/errors/unsupported-functionality-error.ts
var UnsupportedFunctionalityError = class extends Error {
    constructor({ functionality }){
        super(`'${functionality}' functionality not supported.`);
        this.name = "AI_UnsupportedFunctionalityError";
        this.functionality = functionality;
    }
    static isUnsupportedFunctionalityError(error) {
        return error instanceof Error && error.name === "AI_UnsupportedFunctionalityError" && typeof error.functionality === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            functionality: this.functionality
        };
    }
};
// src/errors/unsupported-json-schema-error.ts
var UnsupportedJSONSchemaError = class extends Error {
    constructor({ schema, reason, message = `Unsupported JSON schema: ${reason}` }){
        super(message);
        this.name = "AI_UnsupportedJSONSchemaError";
        this.reason = reason;
        this.schema = schema;
    }
    static isUnsupportedJSONSchemaError(error) {
        return error instanceof Error && error.name === "AI_UnsupportedJSONSchemaError" && "reason" in error && error.reason != void 0 && "schema" in error && error.schema !== void 0;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            reason: this.reason,
            schema: this.schema
        };
    }
};
;
 //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/secure-json-parse@2.7.0/node_modules/secure-json-parse/index.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

'use strict';
const hasBuffer = typeof Buffer !== 'undefined';
const suspectProtoRx = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
function _parse(text, reviver, options) {
    // Normalize arguments
    if (options == null) {
        if (reviver !== null && typeof reviver === 'object') {
            options = reviver;
            reviver = undefined;
        }
    }
    if (hasBuffer && Buffer.isBuffer(text)) {
        text = text.toString();
    }
    // BOM checker
    if (text && text.charCodeAt(0) === 0xFEFF) {
        text = text.slice(1);
    }
    // Parse normally, allowing exceptions
    const obj = JSON.parse(text, reviver);
    // Ignore null and non-objects
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }
    const protoAction = options && options.protoAction || 'error';
    const constructorAction = options && options.constructorAction || 'error';
    // options: 'error' (default) / 'remove' / 'ignore'
    if (protoAction === 'ignore' && constructorAction === 'ignore') {
        return obj;
    }
    if (protoAction !== 'ignore' && constructorAction !== 'ignore') {
        if (suspectProtoRx.test(text) === false && suspectConstructorRx.test(text) === false) {
            return obj;
        }
    } else if (protoAction !== 'ignore' && constructorAction === 'ignore') {
        if (suspectProtoRx.test(text) === false) {
            return obj;
        }
    } else {
        if (suspectConstructorRx.test(text) === false) {
            return obj;
        }
    }
    // Scan result for proto keys
    return filter(obj, {
        protoAction,
        constructorAction,
        safe: options && options.safe
    });
}
function filter(obj, { protoAction = 'error', constructorAction = 'error', safe } = {}) {
    let next = [
        obj
    ];
    while(next.length){
        const nodes = next;
        next = [];
        for (const node of nodes){
            if (protoAction !== 'ignore' && Object.prototype.hasOwnProperty.call(node, '__proto__')) {
                if (safe === true) {
                    return null;
                } else if (protoAction === 'error') {
                    throw new SyntaxError('Object contains forbidden prototype property');
                }
                delete node.__proto__ // eslint-disable-line no-proto
                ;
            }
            if (constructorAction !== 'ignore' && Object.prototype.hasOwnProperty.call(node, 'constructor') && Object.prototype.hasOwnProperty.call(node.constructor, 'prototype')) {
                if (safe === true) {
                    return null;
                } else if (constructorAction === 'error') {
                    throw new SyntaxError('Object contains forbidden prototype property');
                }
                delete node.constructor;
            }
            for(const key in node){
                const value = node[key];
                if (value && typeof value === 'object') {
                    next.push(value);
                }
            }
        }
    }
    return obj;
}
function parse(text, reviver, options) {
    const stackTraceLimit = Error.stackTraceLimit;
    Error.stackTraceLimit = 0;
    try {
        return _parse(text, reviver, options);
    } finally{
        Error.stackTraceLimit = stackTraceLimit;
    }
}
function safeParse(text, reviver) {
    const stackTraceLimit = Error.stackTraceLimit;
    Error.stackTraceLimit = 0;
    try {
        return _parse(text, reviver, {
            safe: true
        });
    } catch (_e) {
        return null;
    } finally{
        Error.stackTraceLimit = stackTraceLimit;
    }
}
module.exports = parse;
module.exports.default = parse;
module.exports.parse = parse;
module.exports.safeParse = safeParse;
module.exports.scan = filter;

}.call(this) }),
"[project]/node_modules/.pnpm/eventsource-parser@1.1.2/node_modules/eventsource-parser/dist/index.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "createParser": ()=>createParser
});
function createParser(onParse) {
    let isFirstChunk;
    let buffer;
    let startingPosition;
    let startingFieldLength;
    let eventId;
    let eventName;
    let data;
    reset();
    return {
        feed,
        reset
    };
    function reset() {
        isFirstChunk = true;
        buffer = "";
        startingPosition = 0;
        startingFieldLength = -1;
        eventId = void 0;
        eventName = void 0;
        data = "";
    }
    function feed(chunk) {
        buffer = buffer ? buffer + chunk : chunk;
        if (isFirstChunk && hasBom(buffer)) {
            buffer = buffer.slice(BOM.length);
        }
        isFirstChunk = false;
        const length = buffer.length;
        let position = 0;
        let discardTrailingNewline = false;
        while(position < length){
            if (discardTrailingNewline) {
                if (buffer[position] === "\n") {
                    ++position;
                }
                discardTrailingNewline = false;
            }
            let lineLength = -1;
            let fieldLength = startingFieldLength;
            let character;
            for(let index = startingPosition; lineLength < 0 && index < length; ++index){
                character = buffer[index];
                if (character === ":" && fieldLength < 0) {
                    fieldLength = index - position;
                } else if (character === "\r") {
                    discardTrailingNewline = true;
                    lineLength = index - position;
                } else if (character === "\n") {
                    lineLength = index - position;
                }
            }
            if (lineLength < 0) {
                startingPosition = length - position;
                startingFieldLength = fieldLength;
                break;
            } else {
                startingPosition = 0;
                startingFieldLength = -1;
            }
            parseEventStreamLine(buffer, position, fieldLength, lineLength);
            position += lineLength + 1;
        }
        if (position === length) {
            buffer = "";
        } else if (position > 0) {
            buffer = buffer.slice(position);
        }
    }
    function parseEventStreamLine(lineBuffer, index, fieldLength, lineLength) {
        if (lineLength === 0) {
            if (data.length > 0) {
                onParse({
                    type: "event",
                    id: eventId,
                    event: eventName || void 0,
                    data: data.slice(0, -1)
                });
                data = "";
                eventId = void 0;
            }
            eventName = void 0;
            return;
        }
        const noValue = fieldLength < 0;
        const field = lineBuffer.slice(index, index + (noValue ? lineLength : fieldLength));
        let step = 0;
        if (noValue) {
            step = lineLength;
        } else if (lineBuffer[index + fieldLength + 1] === " ") {
            step = fieldLength + 2;
        } else {
            step = fieldLength + 1;
        }
        const position = index + step;
        const valueLength = lineLength - step;
        const value = lineBuffer.slice(position, position + valueLength).toString();
        if (field === "data") {
            data += value ? "".concat(value, "\n") : "\n";
        } else if (field === "event") {
            eventName = value;
        } else if (field === "id" && !value.includes("\0")) {
            eventId = value;
        } else if (field === "retry") {
            const retry = parseInt(value, 10);
            if (!Number.isNaN(retry)) {
                onParse({
                    type: "reconnect-interval",
                    value: retry
                });
            }
        }
    }
}
const BOM = [
    239,
    187,
    191
];
function hasBom(buffer) {
    return BOM.every((charCode, index)=>buffer.charCodeAt(index) === charCode);
}
;
 //# sourceMappingURL=index.js.map

})()),
"[project]/node_modules/.pnpm/eventsource-parser@1.1.2/node_modules/eventsource-parser/dist/stream.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "EventSourceParserStream": ()=>EventSourceParserStream
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/eventsource-parser@1.1.2/node_modules/eventsource-parser/dist/index.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
class EventSourceParserStream extends TransformStream {
    constructor(){
        let parser;
        super({
            start (controller) {
                parser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createParser"])((event)=>{
                    if (event.type === "event") {
                        controller.enqueue(event);
                    }
                });
            },
            transform (chunk) {
                parser.feed(chunk);
            }
        });
    }
}
;
 //# sourceMappingURL=stream.js.map

})()),
"[project]/node_modules/.pnpm/@ai-sdk+provider-utils@1.0.0_zod@3.23.8/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// src/combine-headers.ts
__turbopack_esm__({
    "combineHeaders": ()=>combineHeaders,
    "convertAsyncGeneratorToReadableStream": ()=>convertAsyncGeneratorToReadableStream,
    "convertBase64ToUint8Array": ()=>convertBase64ToUint8Array,
    "convertUint8ArrayToBase64": ()=>convertUint8ArrayToBase64,
    "createEventSourceResponseHandler": ()=>createEventSourceResponseHandler,
    "createJsonErrorResponseHandler": ()=>createJsonErrorResponseHandler,
    "createJsonResponseHandler": ()=>createJsonResponseHandler,
    "createJsonStreamResponseHandler": ()=>createJsonStreamResponseHandler,
    "download": ()=>download,
    "extractResponseHeaders": ()=>extractResponseHeaders,
    "generateId": ()=>generateId,
    "getErrorMessage": ()=>getErrorMessage,
    "isAbortError": ()=>isAbortError,
    "isParsableJson": ()=>isParsableJson,
    "isParseableJson": ()=>isParseableJson,
    "loadApiKey": ()=>loadApiKey,
    "loadSetting": ()=>loadSetting,
    "parseJSON": ()=>parseJSON,
    "postJsonToApi": ()=>postJsonToApi,
    "postToApi": ()=>postToApi,
    "safeParseJSON": ()=>safeParseJSON,
    "safeValidateTypes": ()=>safeValidateTypes,
    "validateTypes": ()=>validateTypes,
    "withoutTrailingSlash": ()=>withoutTrailingSlash
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@ai-sdk+provider@0.0.11/node_modules/@ai-sdk/provider/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nanoid$40$3$2e$3$2e$6$2f$node_modules$2f$nanoid$2f$non$2d$secure$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/non-secure/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/secure-json-parse@2.7.0/node_modules/secure-json-parse/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$stream$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/eventsource-parser@1.1.2/node_modules/eventsource-parser/dist/stream.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
function combineHeaders(...headers) {
    return headers.reduce((combinedHeaders, currentHeaders)=>({
            ...combinedHeaders,
            ...currentHeaders != null ? currentHeaders : {}
        }), {});
}
// src/convert-async-generator-to-readable-stream.ts
function convertAsyncGeneratorToReadableStream(stream) {
    return new ReadableStream({
        /**
     * Called when the consumer wants to pull more data from the stream.
     *
     * @param {ReadableStreamDefaultController<T>} controller - The controller to enqueue data into the stream.
     * @returns {Promise<void>}
     */ async pull (controller) {
            try {
                const { value, done } = await stream.next();
                if (done) {
                    controller.close();
                } else {
                    controller.enqueue(value);
                }
            } catch (error) {
                controller.error(error);
            }
        },
        /**
     * Called when the consumer cancels the stream.
     */ cancel () {}
    });
}
;
async function download({ url, fetchImplementation = fetch }) {
    var _a;
    const urlText = url.toString();
    try {
        const response = await fetchImplementation(urlText);
        if (!response.ok) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DownloadError"]({
                url: urlText,
                statusCode: response.status,
                statusText: response.statusText
            });
        }
        return {
            data: new Uint8Array(await response.arrayBuffer()),
            mimeType: (_a = response.headers.get("content-type")) != null ? _a : void 0
        };
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DownloadError"].isDownloadError(error)) {
            throw error;
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DownloadError"]({
            url: urlText,
            cause: error
        });
    }
}
// src/extract-response-headers.ts
function extractResponseHeaders(response) {
    const headers = {};
    response.headers.forEach((value, key)=>{
        headers[key] = value;
    });
    return headers;
}
;
var generateId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nanoid$40$3$2e$3$2e$6$2f$node_modules$2f$nanoid$2f$non$2d$secure$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["customAlphabet"])("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 7);
// src/get-error-message.ts
function getErrorMessage(error) {
    if (error == null) {
        return "unknown error";
    }
    if (typeof error === "string") {
        return error;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return JSON.stringify(error);
}
// src/is-abort-error.ts
function isAbortError(error) {
    return error instanceof DOMException && (error.name === "AbortError" || error.name === "TimeoutError");
}
;
function loadApiKey({ apiKey, environmentVariableName, apiKeyParameterName = "apiKey", description }) {
    if (typeof apiKey === "string") {
        return apiKey;
    }
    if (apiKey != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key must be a string.`
        });
    }
    if (typeof process === "undefined") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key is missing. Pass it using the '${apiKeyParameterName}' parameter. Environment variables is not supported in this environment.`
        });
    }
    apiKey = process.env[environmentVariableName];
    if (apiKey == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key is missing. Pass it using the '${apiKeyParameterName}' parameter or the ${environmentVariableName} environment variable.`
        });
    }
    if (typeof apiKey !== "string") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key must be a string. The value of the ${environmentVariableName} environment variable is not a string.`
        });
    }
    return apiKey;
}
;
function loadSetting({ settingValue, environmentVariableName, settingName, description }) {
    if (typeof settingValue === "string") {
        return settingValue;
    }
    if (settingValue != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting must be a string.`
        });
    }
    if (typeof process === "undefined") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting is missing. Pass it using the '${settingName}' parameter. Environment variables is not supported in this environment.`
        });
    }
    settingValue = process.env[environmentVariableName];
    if (settingValue == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting is missing. Pass it using the '${settingName}' parameter or the ${environmentVariableName} environment variable.`
        });
    }
    if (typeof settingValue !== "string") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting must be a string. The value of the ${environmentVariableName} environment variable is not a string.`
        });
    }
    return settingValue;
}
;
;
;
function validateTypes({ value, schema }) {
    try {
        return schema.parse(value);
    } catch (error) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TypeValidationError"]({
            value,
            cause: error
        });
    }
}
function safeValidateTypes({ value, schema }) {
    try {
        const validationResult = schema.safeParse(value);
        if (validationResult.success) {
            return {
                success: true,
                value: validationResult.data
            };
        }
        return {
            success: false,
            error: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TypeValidationError"]({
                value,
                cause: validationResult.error
            })
        };
    } catch (error) {
        return {
            success: false,
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TypeValidationError"].isTypeValidationError(error) ? error : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TypeValidationError"]({
                value,
                cause: error
            })
        };
    }
}
// src/parse-json.ts
function parseJSON({ text, schema }) {
    try {
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].parse(text);
        if (schema == null) {
            return value;
        }
        return validateTypes({
            value,
            schema
        });
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["JSONParseError"].isJSONParseError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TypeValidationError"].isTypeValidationError(error)) {
            throw error;
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["JSONParseError"]({
            text,
            cause: error
        });
    }
}
function safeParseJSON({ text, schema }) {
    try {
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].parse(text);
        if (schema == null) {
            return {
                success: true,
                value
            };
        }
        return safeValidateTypes({
            value,
            schema
        });
    } catch (error) {
        return {
            success: false,
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["JSONParseError"].isJSONParseError(error) ? error : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["JSONParseError"]({
                text,
                cause: error
            })
        };
    }
}
function isParsableJson(input) {
    try {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].parse(input);
        return true;
    } catch (e) {
        return false;
    }
}
var isParseableJson = isParsableJson;
;
// src/remove-undefined-entries.ts
function removeUndefinedEntries(record) {
    return Object.fromEntries(Object.entries(record).filter(([_key, value])=>value != null));
}
// src/post-to-api.ts
var getOriginalFetch = ()=>fetch;
var postJsonToApi = async ({ url, headers, body, failedResponseHandler, successfulResponseHandler, abortSignal, fetch: fetch2 })=>postToApi({
        url,
        headers: {
            "Content-Type": "application/json",
            ...headers
        },
        body: {
            content: JSON.stringify(body),
            values: body
        },
        failedResponseHandler,
        successfulResponseHandler,
        abortSignal,
        fetch: fetch2
    });
var postToApi = async ({ url, headers = {}, body, successfulResponseHandler, failedResponseHandler, abortSignal, fetch: fetch2 = getOriginalFetch() })=>{
    try {
        const response = await fetch2(url, {
            method: "POST",
            headers: removeUndefinedEntries(headers),
            body: body.content,
            signal: abortSignal
        });
        const responseHeaders = extractResponseHeaders(response);
        if (!response.ok) {
            let errorInformation;
            try {
                errorInformation = await failedResponseHandler({
                    response,
                    url,
                    requestBodyValues: body.values
                });
            } catch (error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"].isAPICallError(error)) {
                    throw error;
                }
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: "Failed to process error response",
                    cause: error,
                    statusCode: response.status,
                    url,
                    responseHeaders,
                    requestBodyValues: body.values
                });
            }
            throw errorInformation.value;
        }
        try {
            return await successfulResponseHandler({
                response,
                url,
                requestBodyValues: body.values
            });
        } catch (error) {
            if (error instanceof Error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"].isAPICallError(error)) {
                    throw error;
                }
            }
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Failed to process successful response",
                cause: error,
                statusCode: response.status,
                url,
                responseHeaders,
                requestBodyValues: body.values
            });
        }
    } catch (error) {
        if (isAbortError(error)) {
            throw error;
        }
        if (error instanceof TypeError && error.message === "fetch failed") {
            const cause = error.cause;
            if (cause != null) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: `Cannot connect to API: ${cause.message}`,
                    cause,
                    url,
                    requestBodyValues: body.values,
                    isRetryable: true
                });
            }
        }
        throw error;
    }
};
;
;
var createJsonErrorResponseHandler = ({ errorSchema, errorToMessage, isRetryable })=>async ({ response, url, requestBodyValues })=>{
        const responseBody = await response.text();
        const responseHeaders = extractResponseHeaders(response);
        if (responseBody.trim() === "") {
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: response.statusText,
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response)
                })
            };
        }
        try {
            const parsedError = parseJSON({
                text: responseBody,
                schema: errorSchema
            });
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: errorToMessage(parsedError),
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    data: parsedError,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response, parsedError)
                })
            };
        } catch (parseError) {
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: response.statusText,
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response)
                })
            };
        }
    };
var createEventSourceResponseHandler = (chunkSchema)=>async ({ response })=>{
        const responseHeaders = extractResponseHeaders(response);
        if (response.body == null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EmptyResponseBodyError"]({});
        }
        return {
            responseHeaders,
            value: response.body.pipeThrough(new TextDecoderStream()).pipeThrough(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$stream$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EventSourceParserStream"]()).pipeThrough(new TransformStream({
                transform ({ data }, controller) {
                    if (data === "[DONE]") {
                        return;
                    }
                    controller.enqueue(safeParseJSON({
                        text: data,
                        schema: chunkSchema
                    }));
                }
            }))
        };
    };
var createJsonStreamResponseHandler = (chunkSchema)=>async ({ response })=>{
        const responseHeaders = extractResponseHeaders(response);
        if (response.body == null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EmptyResponseBodyError"]({});
        }
        let buffer = "";
        return {
            responseHeaders,
            value: response.body.pipeThrough(new TextDecoderStream()).pipeThrough(new TransformStream({
                transform (chunkText, controller) {
                    if (chunkText.endsWith("\n")) {
                        controller.enqueue(safeParseJSON({
                            text: buffer + chunkText,
                            schema: chunkSchema
                        }));
                        buffer = "";
                    } else {
                        buffer += chunkText;
                    }
                }
            }))
        };
    };
var createJsonResponseHandler = (responseSchema)=>async ({ response, url, requestBodyValues })=>{
        const responseBody = await response.text();
        const parsedResult = safeParseJSON({
            text: responseBody,
            schema: responseSchema
        });
        const responseHeaders = extractResponseHeaders(response);
        if (!parsedResult.success) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Invalid JSON response",
                cause: parsedResult.error,
                statusCode: response.status,
                responseHeaders,
                responseBody,
                url,
                requestBodyValues
            });
        }
        return {
            responseHeaders,
            value: parsedResult.value
        };
    };
// src/uint8-utils.ts
function convertBase64ToUint8Array(base64String) {
    const base64Url = base64String.replace(/-/g, "+").replace(/_/g, "/");
    const latin1string = globalThis.atob(base64Url);
    return Uint8Array.from(latin1string, (byte)=>byte.codePointAt(0));
}
function convertUint8ArrayToBase64(array) {
    let latin1string = "";
    for(let i = 0; i < array.length; i++){
        latin1string += String.fromCodePoint(array[i]);
    }
    return globalThis.btoa(latin1string);
}
// src/without-trailing-slash.ts
function withoutTrailingSlash(url) {
    return url == null ? void 0 : url.replace(/\/$/, "");
}
;
 //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/@ai-sdk+ui-utils@0.0.9_zod@3.23.8/node_modules/@ai-sdk/ui-utils/dist/index.mjs [app-rsc] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// src/index.ts
__turbopack_esm__({
    "callChatApi": ()=>callChatApi,
    "callCompletionApi": ()=>callCompletionApi,
    "createChunkDecoder": ()=>createChunkDecoder,
    "formatStreamPart": ()=>formatStreamPart,
    "isDeepEqualData": ()=>isDeepEqualData,
    "parseComplexResponse": ()=>parseComplexResponse,
    "parsePartialJson": ()=>parsePartialJson,
    "parseStreamPart": ()=>parseStreamPart,
    "processChatStream": ()=>processChatStream,
    "readDataStream": ()=>readDataStream
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@ai-sdk+provider-utils@1.0.0_zod@3.23.8/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/secure-json-parse@2.7.0/node_modules/secure-json-parse/index.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
// src/stream-parts.ts
var textStreamPart = {
    code: "0",
    name: "text",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"text" parts expect a string value.');
        }
        return {
            type: "text",
            value
        };
    }
};
var functionCallStreamPart = {
    code: "1",
    name: "function_call",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("function_call" in value) || typeof value.function_call !== "object" || value.function_call == null || !("name" in value.function_call) || !("arguments" in value.function_call) || typeof value.function_call.name !== "string" || typeof value.function_call.arguments !== "string") {
            throw new Error('"function_call" parts expect an object with a "function_call" property.');
        }
        return {
            type: "function_call",
            value
        };
    }
};
var dataStreamPart = {
    code: "2",
    name: "data",
    parse: (value)=>{
        if (!Array.isArray(value)) {
            throw new Error('"data" parts expect an array value.');
        }
        return {
            type: "data",
            value
        };
    }
};
var errorStreamPart = {
    code: "3",
    name: "error",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"error" parts expect a string value.');
        }
        return {
            type: "error",
            value
        };
    }
};
var assistantMessageStreamPart = {
    code: "4",
    name: "assistant_message",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("id" in value) || !("role" in value) || !("content" in value) || typeof value.id !== "string" || typeof value.role !== "string" || value.role !== "assistant" || !Array.isArray(value.content) || !value.content.every((item)=>item != null && typeof item === "object" && "type" in item && item.type === "text" && "text" in item && item.text != null && typeof item.text === "object" && "value" in item.text && typeof item.text.value === "string")) {
            throw new Error('"assistant_message" parts expect an object with an "id", "role", and "content" property.');
        }
        return {
            type: "assistant_message",
            value
        };
    }
};
var assistantControlDataStreamPart = {
    code: "5",
    name: "assistant_control_data",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("threadId" in value) || !("messageId" in value) || typeof value.threadId !== "string" || typeof value.messageId !== "string") {
            throw new Error('"assistant_control_data" parts expect an object with a "threadId" and "messageId" property.');
        }
        return {
            type: "assistant_control_data",
            value: {
                threadId: value.threadId,
                messageId: value.messageId
            }
        };
    }
};
var dataMessageStreamPart = {
    code: "6",
    name: "data_message",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("role" in value) || !("data" in value) || typeof value.role !== "string" || value.role !== "data") {
            throw new Error('"data_message" parts expect an object with a "role" and "data" property.');
        }
        return {
            type: "data_message",
            value
        };
    }
};
var toolCallsStreamPart = {
    code: "7",
    name: "tool_calls",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("tool_calls" in value) || typeof value.tool_calls !== "object" || value.tool_calls == null || !Array.isArray(value.tool_calls) || value.tool_calls.some((tc)=>tc == null || typeof tc !== "object" || !("id" in tc) || typeof tc.id !== "string" || !("type" in tc) || typeof tc.type !== "string" || !("function" in tc) || tc.function == null || typeof tc.function !== "object" || !("arguments" in tc.function) || typeof tc.function.name !== "string" || typeof tc.function.arguments !== "string")) {
            throw new Error('"tool_calls" parts expect an object with a ToolCallPayload.');
        }
        return {
            type: "tool_calls",
            value
        };
    }
};
var messageAnnotationsStreamPart = {
    code: "8",
    name: "message_annotations",
    parse: (value)=>{
        if (!Array.isArray(value)) {
            throw new Error('"message_annotations" parts expect an array value.');
        }
        return {
            type: "message_annotations",
            value
        };
    }
};
var toolCallStreamPart = {
    code: "9",
    name: "tool_call",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("toolName" in value) || typeof value.toolName !== "string" || !("args" in value) || typeof value.args !== "object") {
            throw new Error('"tool_call" parts expect an object with a "toolCallId", "toolName", and "args" property.');
        }
        return {
            type: "tool_call",
            value
        };
    }
};
var toolResultStreamPart = {
    code: "a",
    name: "tool_result",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("toolName" in value) || typeof value.toolName !== "string" || !("args" in value) || typeof value.args !== "object" || !("result" in value)) {
            throw new Error('"tool_result" parts expect an object with a "toolCallId", "toolName", "args", and "result" property.');
        }
        return {
            type: "tool_result",
            value
        };
    }
};
var streamParts = [
    textStreamPart,
    functionCallStreamPart,
    dataStreamPart,
    errorStreamPart,
    assistantMessageStreamPart,
    assistantControlDataStreamPart,
    dataMessageStreamPart,
    toolCallsStreamPart,
    messageAnnotationsStreamPart,
    toolCallStreamPart,
    toolResultStreamPart
];
var streamPartsByCode = {
    [textStreamPart.code]: textStreamPart,
    [functionCallStreamPart.code]: functionCallStreamPart,
    [dataStreamPart.code]: dataStreamPart,
    [errorStreamPart.code]: errorStreamPart,
    [assistantMessageStreamPart.code]: assistantMessageStreamPart,
    [assistantControlDataStreamPart.code]: assistantControlDataStreamPart,
    [dataMessageStreamPart.code]: dataMessageStreamPart,
    [toolCallsStreamPart.code]: toolCallsStreamPart,
    [messageAnnotationsStreamPart.code]: messageAnnotationsStreamPart,
    [toolCallStreamPart.code]: toolCallStreamPart,
    [toolResultStreamPart.code]: toolResultStreamPart
};
var StreamStringPrefixes = {
    [textStreamPart.name]: textStreamPart.code,
    [functionCallStreamPart.name]: functionCallStreamPart.code,
    [dataStreamPart.name]: dataStreamPart.code,
    [errorStreamPart.name]: errorStreamPart.code,
    [assistantMessageStreamPart.name]: assistantMessageStreamPart.code,
    [assistantControlDataStreamPart.name]: assistantControlDataStreamPart.code,
    [dataMessageStreamPart.name]: dataMessageStreamPart.code,
    [toolCallsStreamPart.name]: toolCallsStreamPart.code,
    [messageAnnotationsStreamPart.name]: messageAnnotationsStreamPart.code,
    [toolCallStreamPart.name]: toolCallStreamPart.code,
    [toolResultStreamPart.name]: toolResultStreamPart.code
};
var validCodes = streamParts.map((part)=>part.code);
var parseStreamPart = (line)=>{
    const firstSeparatorIndex = line.indexOf(":");
    if (firstSeparatorIndex === -1) {
        throw new Error("Failed to parse stream string. No separator found.");
    }
    const prefix = line.slice(0, firstSeparatorIndex);
    if (!validCodes.includes(prefix)) {
        throw new Error(`Failed to parse stream string. Invalid code ${prefix}.`);
    }
    const code = prefix;
    const textValue = line.slice(firstSeparatorIndex + 1);
    const jsonValue = JSON.parse(textValue);
    return streamPartsByCode[code].parse(jsonValue);
};
function formatStreamPart(type, value) {
    const streamPart = streamParts.find((part)=>part.name === type);
    if (!streamPart) {
        throw new Error(`Invalid stream part type: ${type}`);
    }
    return `${streamPart.code}:${JSON.stringify(value)}
`;
}
// src/read-data-stream.ts
var NEWLINE = "\n".charCodeAt(0);
function concatChunks(chunks, totalLength) {
    const concatenatedChunks = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks){
        concatenatedChunks.set(chunk, offset);
        offset += chunk.length;
    }
    chunks.length = 0;
    return concatenatedChunks;
}
async function* readDataStream(reader, { isAborted } = {}) {
    const decoder = new TextDecoder();
    const chunks = [];
    let totalLength = 0;
    while(true){
        const { value } = await reader.read();
        if (value) {
            chunks.push(value);
            totalLength += value.length;
            if (value[value.length - 1] !== NEWLINE) {
                continue;
            }
        }
        if (chunks.length === 0) {
            break;
        }
        const concatenatedChunks = concatChunks(chunks, totalLength);
        totalLength = 0;
        const streamParts2 = decoder.decode(concatenatedChunks, {
            stream: true
        }).split("\n").filter((line)=>line !== "").map(parseStreamPart);
        for (const streamPart of streamParts2){
            yield streamPart;
        }
        if (isAborted == null ? void 0 : isAborted()) {
            reader.cancel();
            break;
        }
    }
}
// src/parse-complex-response.ts
function assignAnnotationsToMessage(message, annotations) {
    if (!message || !annotations || !annotations.length) return message;
    return {
        ...message,
        annotations: [
            ...annotations
        ]
    };
}
async function parseComplexResponse({ reader, abortControllerRef, update, onToolCall, onFinish, generateId: generateId2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateId"], getCurrentDate = ()=>/* @__PURE__ */ new Date() }) {
    const createdAt = getCurrentDate();
    const prefixMap = {
        data: []
    };
    let message_annotations = void 0;
    for await (const { type, value } of readDataStream(reader, {
        isAborted: ()=>(abortControllerRef == null ? void 0 : abortControllerRef.current) === null
    })){
        if (type === "text") {
            if (prefixMap["text"]) {
                prefixMap["text"] = {
                    ...prefixMap["text"],
                    content: (prefixMap["text"].content || "") + value
                };
            } else {
                prefixMap["text"] = {
                    id: generateId2(),
                    role: "assistant",
                    content: value,
                    createdAt
                };
            }
        }
        if (type === "tool_call") {
            if (prefixMap.text == null) {
                prefixMap.text = {
                    id: generateId2(),
                    role: "assistant",
                    content: "",
                    createdAt
                };
            }
            if (prefixMap.text.toolInvocations == null) {
                prefixMap.text.toolInvocations = [];
            }
            prefixMap.text.toolInvocations.push(value);
            if (onToolCall) {
                const result = await onToolCall({
                    toolCall: value
                });
                if (result != null) {
                    prefixMap.text.toolInvocations[prefixMap.text.toolInvocations.length - 1] = {
                        ...value,
                        result
                    };
                }
            }
        } else if (type === "tool_result") {
            if (prefixMap.text == null) {
                prefixMap.text = {
                    id: generateId2(),
                    role: "assistant",
                    content: "",
                    createdAt
                };
            }
            if (prefixMap.text.toolInvocations == null) {
                prefixMap.text.toolInvocations = [];
            }
            const toolInvocationIndex = prefixMap.text.toolInvocations.findIndex((invocation)=>invocation.toolCallId === value.toolCallId);
            if (toolInvocationIndex !== -1) {
                prefixMap.text.toolInvocations[toolInvocationIndex] = value;
            } else {
                prefixMap.text.toolInvocations.push(value);
            }
        }
        let functionCallMessage = null;
        if (type === "function_call") {
            prefixMap["function_call"] = {
                id: generateId2(),
                role: "assistant",
                content: "",
                function_call: value.function_call,
                name: value.function_call.name,
                createdAt
            };
            functionCallMessage = prefixMap["function_call"];
        }
        let toolCallMessage = null;
        if (type === "tool_calls") {
            prefixMap["tool_calls"] = {
                id: generateId2(),
                role: "assistant",
                content: "",
                tool_calls: value.tool_calls,
                createdAt
            };
            toolCallMessage = prefixMap["tool_calls"];
        }
        if (type === "data") {
            prefixMap["data"].push(...value);
        }
        let responseMessage = prefixMap["text"];
        if (type === "message_annotations") {
            if (!message_annotations) {
                message_annotations = [
                    ...value
                ];
            } else {
                message_annotations.push(...value);
            }
            functionCallMessage = assignAnnotationsToMessage(prefixMap["function_call"], message_annotations);
            toolCallMessage = assignAnnotationsToMessage(prefixMap["tool_calls"], message_annotations);
            responseMessage = assignAnnotationsToMessage(prefixMap["text"], message_annotations);
        }
        if (message_annotations == null ? void 0 : message_annotations.length) {
            const messagePrefixKeys = [
                "text",
                "function_call",
                "tool_calls"
            ];
            messagePrefixKeys.forEach((key)=>{
                if (prefixMap[key]) {
                    prefixMap[key].annotations = [
                        ...message_annotations
                    ];
                }
            });
        }
        const merged = [
            functionCallMessage,
            toolCallMessage,
            responseMessage
        ].filter(Boolean).map((message)=>({
                ...assignAnnotationsToMessage(message, message_annotations)
            }));
        update(merged, [
            ...prefixMap["data"]
        ]);
    }
    onFinish == null ? void 0 : onFinish(prefixMap);
    return {
        messages: [
            prefixMap.text,
            prefixMap.function_call,
            prefixMap.tool_calls
        ].filter(Boolean),
        data: prefixMap.data
    };
}
// src/call-chat-api.ts
var getOriginalFetch = ()=>fetch;
async function callChatApi({ api, body, streamMode = "stream-data", credentials, headers, abortController, restoreMessagesOnFailure, onResponse, onUpdate, onFinish, onToolCall, generateId: generateId2, fetch: fetch2 = getOriginalFetch() }) {
    var _a, _b;
    const response = await fetch2(api, {
        method: "POST",
        body: JSON.stringify(body),
        headers: {
            "Content-Type": "application/json",
            ...headers
        },
        signal: (_a = abortController == null ? void 0 : abortController()) == null ? void 0 : _a.signal,
        credentials
    }).catch((err)=>{
        restoreMessagesOnFailure();
        throw err;
    });
    if (onResponse) {
        try {
            await onResponse(response);
        } catch (err) {
            throw err;
        }
    }
    if (!response.ok) {
        restoreMessagesOnFailure();
        throw new Error((_b = await response.text()) != null ? _b : "Failed to fetch the chat response.");
    }
    if (!response.body) {
        throw new Error("The response body is empty.");
    }
    const reader = response.body.getReader();
    switch(streamMode){
        case "text":
            {
                const decoder = createChunkDecoder();
                const resultMessage = {
                    id: generateId2(),
                    createdAt: /* @__PURE__ */ new Date(),
                    role: "assistant",
                    content: ""
                };
                while(true){
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    resultMessage.content += decoder(value);
                    resultMessage.id = generateId2();
                    onUpdate([
                        {
                            ...resultMessage
                        }
                    ], []);
                    if ((abortController == null ? void 0 : abortController()) === null) {
                        reader.cancel();
                        break;
                    }
                }
                onFinish == null ? void 0 : onFinish(resultMessage);
                return {
                    messages: [
                        resultMessage
                    ],
                    data: []
                };
            }
        case "stream-data":
            {
                return await parseComplexResponse({
                    reader,
                    abortControllerRef: abortController != null ? {
                        current: abortController()
                    } : void 0,
                    update: onUpdate,
                    onToolCall,
                    onFinish (prefixMap) {
                        if (onFinish && prefixMap.text != null) {
                            onFinish(prefixMap.text);
                        }
                    },
                    generateId: generateId2
                });
            }
        default:
            {
                const exhaustiveCheck = streamMode;
                throw new Error(`Unknown stream mode: ${exhaustiveCheck}`);
            }
    }
}
// src/call-completion-api.ts
var getOriginalFetch2 = ()=>fetch;
async function callCompletionApi({ api, prompt, credentials, headers, body, streamMode = "stream-data", setCompletion, setLoading, setError, setAbortController, onResponse, onFinish, onError, onData, fetch: fetch2 = getOriginalFetch2() }) {
    try {
        setLoading(true);
        setError(void 0);
        const abortController = new AbortController();
        setAbortController(abortController);
        setCompletion("");
        const res = await fetch2(api, {
            method: "POST",
            body: JSON.stringify({
                prompt,
                ...body
            }),
            credentials,
            headers: {
                "Content-Type": "application/json",
                ...headers
            },
            signal: abortController.signal
        }).catch((err)=>{
            throw err;
        });
        if (onResponse) {
            try {
                await onResponse(res);
            } catch (err) {
                throw err;
            }
        }
        if (!res.ok) {
            throw new Error(await res.text() || "Failed to fetch the chat response.");
        }
        if (!res.body) {
            throw new Error("The response body is empty.");
        }
        let result = "";
        const reader = res.body.getReader();
        switch(streamMode){
            case "text":
                {
                    const decoder = createChunkDecoder();
                    while(true){
                        const { done, value } = await reader.read();
                        if (done) {
                            break;
                        }
                        result += decoder(value);
                        setCompletion(result);
                        if (abortController === null) {
                            reader.cancel();
                            break;
                        }
                    }
                    break;
                }
            case "stream-data":
                {
                    for await (const { type, value } of readDataStream(reader, {
                        isAborted: ()=>abortController === null
                    })){
                        switch(type){
                            case "text":
                                {
                                    result += value;
                                    setCompletion(result);
                                    break;
                                }
                            case "data":
                                {
                                    onData == null ? void 0 : onData(value);
                                    break;
                                }
                        }
                    }
                    break;
                }
            default:
                {
                    const exhaustiveCheck = streamMode;
                    throw new Error(`Unknown stream mode: ${exhaustiveCheck}`);
                }
        }
        if (onFinish) {
            onFinish(prompt, result);
        }
        setAbortController(null);
        return result;
    } catch (err) {
        if (err.name === "AbortError") {
            setAbortController(null);
            return null;
        }
        if (err instanceof Error) {
            if (onError) {
                onError(err);
            }
        }
        setError(err);
    } finally{
        setLoading(false);
    }
}
// src/create-chunk-decoder.ts
function createChunkDecoder(complex) {
    const decoder = new TextDecoder();
    if (!complex) {
        return function(chunk) {
            if (!chunk) return "";
            return decoder.decode(chunk, {
                stream: true
            });
        };
    }
    return function(chunk) {
        const decoded = decoder.decode(chunk, {
            stream: true
        }).split("\n").filter((line)=>line !== "");
        return decoded.map(parseStreamPart).filter(Boolean);
    };
}
// src/is-deep-equal-data.ts
function isDeepEqualData(obj1, obj2) {
    if (obj1 === obj2) return true;
    if (obj1 == null || obj2 == null) return false;
    if (typeof obj1 !== "object" && typeof obj2 !== "object") return obj1 === obj2;
    if (obj1.constructor !== obj2.constructor) return false;
    if (obj1 instanceof Date && obj2 instanceof Date) {
        return obj1.getTime() === obj2.getTime();
    }
    if (Array.isArray(obj1)) {
        if (obj1.length !== obj2.length) return false;
        for(let i = 0; i < obj1.length; i++){
            if (!isDeepEqualData(obj1[i], obj2[i])) return false;
        }
        return true;
    }
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);
    if (keys1.length !== keys2.length) return false;
    for (const key of keys1){
        if (!keys2.includes(key)) return false;
        if (!isDeepEqualData(obj1[key], obj2[key])) return false;
    }
    return true;
}
;
// src/fix-json.ts
function fixJson(input) {
    const stack = [
        "ROOT"
    ];
    let lastValidIndex = -1;
    let literalStart = null;
    function processValueStart(char, i, swapState) {
        {
            switch(char){
                case '"':
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_STRING");
                        break;
                    }
                case "f":
                case "t":
                case "n":
                    {
                        lastValidIndex = i;
                        literalStart = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_LITERAL");
                        break;
                    }
                case "-":
                    {
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_NUMBER");
                        break;
                    }
                case "0":
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_NUMBER");
                        break;
                    }
                case "{":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_OBJECT_START");
                        break;
                    }
                case "[":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_ARRAY_START");
                        break;
                    }
            }
        }
    }
    function processAfterObjectValue(char, i) {
        switch(char){
            case ",":
                {
                    stack.pop();
                    stack.push("INSIDE_OBJECT_AFTER_COMMA");
                    break;
                }
            case "}":
                {
                    lastValidIndex = i;
                    stack.pop();
                    break;
                }
        }
    }
    function processAfterArrayValue(char, i) {
        switch(char){
            case ",":
                {
                    stack.pop();
                    stack.push("INSIDE_ARRAY_AFTER_COMMA");
                    break;
                }
            case "]":
                {
                    lastValidIndex = i;
                    stack.pop();
                    break;
                }
        }
    }
    for(let i = 0; i < input.length; i++){
        const char = input[i];
        const currentState = stack[stack.length - 1];
        switch(currentState){
            case "ROOT":
                processValueStart(char, i, "FINISH");
                break;
            case "INSIDE_OBJECT_START":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_KEY");
                                break;
                            }
                        case "}":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_AFTER_COMMA":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_KEY");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_KEY":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_AFTER_KEY");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_AFTER_KEY":
                {
                    switch(char){
                        case ":":
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_BEFORE_VALUE");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_BEFORE_VALUE":
                {
                    processValueStart(char, i, "INSIDE_OBJECT_AFTER_VALUE");
                    break;
                }
            case "INSIDE_OBJECT_AFTER_VALUE":
                {
                    processAfterObjectValue(char, i);
                    break;
                }
            case "INSIDE_STRING":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                lastValidIndex = i;
                                break;
                            }
                        case "\\":
                            {
                                stack.push("INSIDE_STRING_ESCAPE");
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_START":
                {
                    switch(char){
                        case "]":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                                processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_AFTER_VALUE":
                {
                    switch(char){
                        case ",":
                            {
                                stack.pop();
                                stack.push("INSIDE_ARRAY_AFTER_COMMA");
                                break;
                            }
                        case "]":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_AFTER_COMMA":
                {
                    processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
                    break;
                }
            case "INSIDE_STRING_ESCAPE":
                {
                    stack.pop();
                    lastValidIndex = i;
                    break;
                }
            case "INSIDE_NUMBER":
                {
                    switch(char){
                        case "0":
                        case "1":
                        case "2":
                        case "3":
                        case "4":
                        case "5":
                        case "6":
                        case "7":
                        case "8":
                        case "9":
                            {
                                lastValidIndex = i;
                                break;
                            }
                        case "e":
                        case "E":
                        case "-":
                        case ".":
                            {
                                break;
                            }
                        case ",":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                                    processAfterArrayValue(char, i);
                                }
                                if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                                    processAfterObjectValue(char, i);
                                }
                                break;
                            }
                        case "}":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                                    processAfterObjectValue(char, i);
                                }
                                break;
                            }
                        case "]":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                                    processAfterArrayValue(char, i);
                                }
                                break;
                            }
                        default:
                            {
                                stack.pop();
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_LITERAL":
                {
                    const partialLiteral = input.substring(literalStart, i + 1);
                    if (!"false".startsWith(partialLiteral) && !"true".startsWith(partialLiteral) && !"null".startsWith(partialLiteral)) {
                        stack.pop();
                        if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                            processAfterObjectValue(char, i);
                        } else if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                            processAfterArrayValue(char, i);
                        }
                    } else {
                        lastValidIndex = i;
                    }
                    break;
                }
        }
    }
    let result = input.slice(0, lastValidIndex + 1);
    for(let i = stack.length - 1; i >= 0; i--){
        const state = stack[i];
        switch(state){
            case "INSIDE_STRING":
                {
                    result += '"';
                    break;
                }
            case "INSIDE_OBJECT_KEY":
            case "INSIDE_OBJECT_AFTER_KEY":
            case "INSIDE_OBJECT_AFTER_COMMA":
            case "INSIDE_OBJECT_START":
            case "INSIDE_OBJECT_BEFORE_VALUE":
            case "INSIDE_OBJECT_AFTER_VALUE":
                {
                    result += "}";
                    break;
                }
            case "INSIDE_ARRAY_START":
            case "INSIDE_ARRAY_AFTER_COMMA":
            case "INSIDE_ARRAY_AFTER_VALUE":
                {
                    result += "]";
                    break;
                }
            case "INSIDE_LITERAL":
                {
                    const partialLiteral = input.substring(literalStart, input.length);
                    if ("true".startsWith(partialLiteral)) {
                        result += "true".slice(partialLiteral.length);
                    } else if ("false".startsWith(partialLiteral)) {
                        result += "false".slice(partialLiteral.length);
                    } else if ("null".startsWith(partialLiteral)) {
                        result += "null".slice(partialLiteral.length);
                    }
                }
        }
    }
    return result;
}
// src/parse-partial-json.ts
function parsePartialJson(jsonText) {
    if (jsonText == null) {
        return void 0;
    }
    try {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].parse(jsonText);
    } catch (ignored) {
        try {
            const fixedJsonText = fixJson(jsonText);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$secure$2d$json$2d$parse$40$2$2e$7$2e$0$2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].parse(fixedJsonText);
        } catch (ignored2) {}
    }
    return void 0;
}
// src/process-chat-stream.ts
async function processChatStream({ getStreamedResponse, experimental_onFunctionCall, experimental_onToolCall, updateChatRequest, getCurrentMessages }) {
    while(true){
        const messagesAndDataOrJustMessage = await getStreamedResponse();
        if ("messages" in messagesAndDataOrJustMessage) {
            let hasFollowingResponse = false;
            for (const message of messagesAndDataOrJustMessage.messages){
                if ((message.function_call === void 0 || typeof message.function_call === "string") && (message.tool_calls === void 0 || typeof message.tool_calls === "string")) {
                    continue;
                }
                hasFollowingResponse = true;
                if (experimental_onFunctionCall) {
                    const functionCall = message.function_call;
                    if (typeof functionCall !== "object") {
                        console.warn("experimental_onFunctionCall should not be defined when using tools");
                        continue;
                    }
                    const functionCallResponse = await experimental_onFunctionCall(getCurrentMessages(), functionCall);
                    if (functionCallResponse === void 0) {
                        hasFollowingResponse = false;
                        break;
                    }
                    updateChatRequest(functionCallResponse);
                }
                if (experimental_onToolCall) {
                    const toolCalls = message.tool_calls;
                    if (!Array.isArray(toolCalls) || toolCalls.some((toolCall)=>typeof toolCall !== "object")) {
                        console.warn("experimental_onToolCall should not be defined when using tools");
                        continue;
                    }
                    const toolCallResponse = await experimental_onToolCall(getCurrentMessages(), toolCalls);
                    if (toolCallResponse === void 0) {
                        hasFollowingResponse = false;
                        break;
                    }
                    updateChatRequest(toolCallResponse);
                }
            }
            if (!hasFollowingResponse) {
                break;
            }
        } else {
            let fixFunctionCallArguments2 = function(response) {
                for (const message of response.messages){
                    if (message.tool_calls !== void 0) {
                        for (const toolCall of message.tool_calls){
                            if (typeof toolCall === "object") {
                                if (toolCall.function.arguments && typeof toolCall.function.arguments !== "string") {
                                    toolCall.function.arguments = JSON.stringify(toolCall.function.arguments);
                                }
                            }
                        }
                    }
                    if (message.function_call !== void 0) {
                        if (typeof message.function_call === "object") {
                            if (message.function_call.arguments && typeof message.function_call.arguments !== "string") {
                                message.function_call.arguments = JSON.stringify(message.function_call.arguments);
                            }
                        }
                    }
                }
            };
            var fixFunctionCallArguments = fixFunctionCallArguments2;
            const streamedResponseMessage = messagesAndDataOrJustMessage;
            if ((streamedResponseMessage.function_call === void 0 || typeof streamedResponseMessage.function_call === "string") && (streamedResponseMessage.tool_calls === void 0 || typeof streamedResponseMessage.tool_calls === "string")) {
                break;
            }
            if (experimental_onFunctionCall) {
                const functionCall = streamedResponseMessage.function_call;
                if (!(typeof functionCall === "object")) {
                    console.warn("experimental_onFunctionCall should not be defined when using tools");
                    continue;
                }
                const functionCallResponse = await experimental_onFunctionCall(getCurrentMessages(), functionCall);
                if (functionCallResponse === void 0) break;
                fixFunctionCallArguments2(functionCallResponse);
                updateChatRequest(functionCallResponse);
            }
            if (experimental_onToolCall) {
                const toolCalls = streamedResponseMessage.tool_calls;
                if (!(typeof toolCalls === "object")) {
                    console.warn("experimental_onToolCall should not be defined when using functions");
                    continue;
                }
                const toolCallResponse = await experimental_onToolCall(getCurrentMessages(), toolCalls);
                if (toolCallResponse === void 0) break;
                fixFunctionCallArguments2(toolCallResponse);
                updateChatRequest(toolCallResponse);
            }
        }
    }
}
;
 //# sourceMappingURL=index.mjs.map

})()),
"[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "InternalAIProvider": ()=>InternalAIProvider,
    "readStreamableValue": ()=>readStreamableValue,
    "useAIState": ()=>useAIState,
    "useActions": ()=>useActions,
    "useStreamableValue": ()=>useStreamableValue,
    "useSyncUIState": ()=>useSyncUIState,
    "useUIState": ()=>useUIState
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const InternalAIProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call InternalAIProvider() from the server but InternalAIProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "InternalAIProvider");
const readStreamableValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call readStreamableValue() from the server but readStreamableValue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "readStreamableValue");
const useAIState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAIState() from the server but useAIState is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "useAIState");
const useActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useActions() from the server but useActions is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "useActions");
const useStreamableValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useStreamableValue() from the server but useStreamableValue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "useStreamableValue");
const useSyncUIState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSyncUIState() from the server but useSyncUIState is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "useSyncUIState");
const useUIState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useUIState() from the server but useUIState is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs", "useUIState");

})()),
"[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ai$40$3$2e$2$2e$16_openai$40$4$2e$52$2e$2_react$40$18$2e$3$2e$1_svelte$40$4$2e$2$2e$18_vue$40$3$2e$4$2e$31_typescript$40$5$2e$5$2e$2_$5f$zod$40$3$2e$23$2e$8$2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$shared$2e$mjs__$28$client__proxy$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ai$40$3$2e$2$2e$16_openai$40$4$2e$52$2e$2_react$40$18$2e$3$2e$1_svelte$40$4$2e$2$2e$18_vue$40$3$2e$4$2e$31_typescript$40$5$2e$5$2e$2_$5f$zod$40$3$2e$23$2e$8$2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$shared$2e$mjs__$28$client__proxy$29$__);

})()),
"[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-server.mjs [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// rsc/ai-state.tsx
/* __next_internal_action_entry_do_not_use__ {"e35476d11c777b26667915186a13fedb75b19bf1":"$$ACTION_0"} */ __turbopack_esm__({
    "$$ACTION_0": ()=>$$ACTION_0,
    "createAI": ()=>createAI,
    "createStreamableUI": ()=>createStreamableUI,
    "createStreamableValue": ()=>createStreamableValue,
    "getAIState": ()=>getAIState,
    "getMutableAIState": ()=>getMutableAIState,
    "render": ()=>render,
    "streamUI": ()=>streamUI
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__commonjs__external__async_hooks__ = __turbopack_external_require__("async_hooks", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$facade$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/jsondiffpatch@0.6.0/node_modules/jsondiffpatch/lib/index.js [app-rsc] (ecmascript) <facade>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@14.2.4_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$22$2e$5_zod$40$3$2e$23$2e$8$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.22.5_zod@3.23.8/node_modules/zod-to-json-schema/dist/esm/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$22$2e$5_zod$40$3$2e$23$2e$8$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.22.5_zod@3.23.8/node_modules/zod-to-json-schema/dist/esm/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@ai-sdk+provider@0.0.11/node_modules/@ai-sdk/provider/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@ai-sdk+provider-utils@1.0.0_zod@3.23.8/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/eventsource-parser@1.1.2/node_modules/eventsource-parser/dist/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@ai-sdk+ui-utils@0.0.9_zod@3.23.8/node_modules/@ai-sdk/ui-utils/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ai$40$3$2e$2$2e$16_openai$40$4$2e$52$2e$2_react$40$18$2e$3$2e$1_svelte$40$4$2e$2$2e$18_vue$40$3$2e$4$2e$31_typescript$40$5$2e$5$2e$2_$5f$zod$40$3$2e$23$2e$8$2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$shared$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-shared.mjs [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
function createResolvablePromise() {
    let resolve, reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    return {
        promise,
        resolve,
        reject
    };
}
var R = [
    async ({ c, // current
    n })=>{
        const chunk = await n;
        if (chunk.done) {
            return chunk.value;
        }
        if (chunk.append) {
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    c,
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Suspense"], {
                        fallback: chunk.value,
                        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(R, {
                            c: chunk.value,
                            n: chunk.next
                        })
                    })
                ]
            });
        }
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: chunk.value,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(R, {
                c: chunk.value,
                n: chunk.next
            })
        });
    }
][0];
function createSuspensedChunk(initialValue) {
    const { promise, resolve, reject } = createResolvablePromise();
    return {
        row: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: initialValue,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(R, {
                c: initialValue,
                n: promise
            })
        }),
        resolve,
        reject
    };
}
var isFunction = (x)=>typeof x === "function";
var consumeStream = async (stream)=>{
    const reader = stream.getReader();
    while(true){
        const { done } = await reader.read();
        if (done) break;
    }
};
// rsc/ai-state.tsx
var asyncAIStateStorage = new __TURBOPACK__commonjs__external__async_hooks__["AsyncLocalStorage"]();
function getAIStateStoreOrThrow(message) {
    const store = asyncAIStateStorage.getStore();
    if (!store) {
        throw new Error(message);
    }
    return store;
}
function withAIState({ state: state1, options }, fn) {
    return asyncAIStateStorage.run({
        currentState: state1,
        originalState: state1,
        sealed: false,
        options
    }, fn);
}
function getAIStateDeltaPromise() {
    const store = getAIStateStoreOrThrow("Internal error occurred.");
    return store.mutationDeltaPromise;
}
function sealMutableAIState() {
    const store = getAIStateStoreOrThrow("Internal error occurred.");
    store.sealed = true;
}
function getAIState(...args) {
    const store = getAIStateStoreOrThrow("`getAIState` must be called within an AI Action.");
    if (args.length > 0) {
        const key = args[0];
        if (typeof store.currentState !== "object") {
            throw new Error(`You can't get the "${String(key)}" field from the AI state because it's not an object.`);
        }
        return store.currentState[key];
    }
    return store.currentState;
}
function getMutableAIState(...args) {
    const store = getAIStateStoreOrThrow("`getMutableAIState` must be called within an AI Action.");
    if (store.sealed) {
        throw new Error("`getMutableAIState` must be called before returning from an AI Action. Please move it to the top level of the Action's function body.");
    }
    if (!store.mutationDeltaPromise) {
        const { promise, resolve } = createResolvablePromise();
        store.mutationDeltaPromise = promise;
        store.mutationDeltaResolve = resolve;
    }
    function doUpdate(newState, done) {
        var _a, _b;
        if (args.length > 0) {
            if (typeof store.currentState !== "object") {
                const key = args[0];
                throw new Error(`You can't modify the "${String(key)}" field of the AI state because it's not an object.`);
            }
        }
        if (isFunction(newState)) {
            if (args.length > 0) {
                store.currentState[args[0]] = newState(store.currentState[args[0]]);
            } else {
                store.currentState = newState(store.currentState);
            }
        } else {
            if (args.length > 0) {
                store.currentState[args[0]] = newState;
            } else {
                store.currentState = newState;
            }
        }
        (_b = (_a = store.options).onSetAIState) == null ? void 0 : _b.call(_a, {
            key: args.length > 0 ? args[0] : void 0,
            state: store.currentState,
            done
        });
    }
    const mutableState = {
        get: ()=>{
            if (args.length > 0) {
                const key = args[0];
                if (typeof store.currentState !== "object") {
                    throw new Error(`You can't get the "${String(key)}" field from the AI state because it's not an object.`);
                }
                return store.currentState[key];
            }
            return store.currentState;
        },
        update: function update(newAIState) {
            doUpdate(newAIState, false);
        },
        done: function done(...doneArgs) {
            if (doneArgs.length > 0) {
                doUpdate(doneArgs[0], true);
            }
            const delta = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsondiffpatch$40$0$2e$6$2e$0$2f$node_modules$2f$jsondiffpatch$2f$lib$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$facade$3e$__.diff(store.originalState, store.currentState);
            store.mutationDeltaResolve(delta);
        }
    };
    return mutableState;
}
;
;
;
// core/util/delay.ts
async function delay(delayInMs) {
    return new Promise((resolve)=>setTimeout(resolve, delayInMs));
}
// core/util/retry-with-exponential-backoff.ts
var retryWithExponentialBackoff = ({ maxRetries = 2, initialDelayInMs = 2e3, backoffFactor = 2 } = {})=>async (f)=>_retryWithExponentialBackoff(f, {
            maxRetries,
            delayInMs: initialDelayInMs,
            backoffFactor
        });
async function _retryWithExponentialBackoff(f, { maxRetries, delayInMs, backoffFactor }, errors = []) {
    try {
        return await f();
    } catch (error) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isAbortError"])(error)) {
            throw error;
        }
        if (maxRetries === 0) {
            throw error;
        }
        const errorMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error);
        const newErrors = [
            ...errors,
            error
        ];
        const tryNumber = newErrors.length;
        if (tryNumber > maxRetries) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["RetryError"]({
                message: `Failed after ${tryNumber} attempts. Last error: ${errorMessage}`,
                reason: "maxRetriesExceeded",
                errors: newErrors
            });
        }
        if (error instanceof Error && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APICallError"].isAPICallError(error) && error.isRetryable === true && tryNumber <= maxRetries) {
            await delay(delayInMs);
            return _retryWithExponentialBackoff(f, {
                maxRetries,
                delayInMs: backoffFactor * delayInMs,
                backoffFactor
            }, newErrors);
        }
        if (tryNumber === 1) {
            throw error;
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["RetryError"]({
            message: `Failed after ${tryNumber} attempts with non-retryable error: '${errorMessage}'`,
            reason: "errorNotRetryable",
            errors: newErrors
        });
    }
}
// core/generate-text/token-usage.ts
function calculateTokenUsage(usage) {
    return {
        promptTokens: usage.promptTokens,
        completionTokens: usage.completionTokens,
        totalTokens: usage.promptTokens + usage.completionTokens
    };
}
// core/util/detect-image-mimetype.ts
var mimeTypeSignatures = [
    {
        mimeType: "image/gif",
        bytes: [
            71,
            73,
            70
        ]
    },
    {
        mimeType: "image/png",
        bytes: [
            137,
            80,
            78,
            71
        ]
    },
    {
        mimeType: "image/jpeg",
        bytes: [
            255,
            216
        ]
    },
    {
        mimeType: "image/webp",
        bytes: [
            82,
            73,
            70,
            70
        ]
    }
];
function detectImageMimeType(image) {
    for (const { bytes, mimeType } of mimeTypeSignatures){
        if (image.length >= bytes.length && bytes.every((byte, index)=>image[index] === byte)) {
            return mimeType;
        }
    }
    return void 0;
}
;
;
function convertDataContentToUint8Array(content) {
    if (content instanceof Uint8Array) {
        return content;
    }
    if (typeof content === "string") {
        try {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["convertBase64ToUint8Array"])(content);
        } catch (error) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidDataContentError"]({
                message: "Invalid data content. Content string is not a base64-encoded image.",
                content,
                cause: error
            });
        }
    }
    if (content instanceof ArrayBuffer) {
        return new Uint8Array(content);
    }
    throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidDataContentError"]({
        content
    });
}
// core/prompt/invalid-message-role-error.ts
var InvalidMessageRoleError = class extends Error {
    constructor({ role, message = `Invalid message role: '${role}'. Must be one of: "system", "user", "assistant", "tool".` }){
        super(message);
        this.name = "AI_InvalidMessageRoleError";
        this.role = role;
    }
    static isInvalidMessageRoleError(error) {
        return error instanceof Error && error.name === "AI_InvalidMessageRoleError" && typeof error.role === "string";
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            stack: this.stack,
            role: this.role
        };
    }
};
;
function convertToLanguageModelPrompt(prompt) {
    const languageModelMessages = [];
    if (prompt.system != null) {
        languageModelMessages.push({
            role: "system",
            content: prompt.system
        });
    }
    const promptType = prompt.type;
    switch(promptType){
        case "prompt":
            {
                languageModelMessages.push({
                    role: "user",
                    content: [
                        {
                            type: "text",
                            text: prompt.prompt
                        }
                    ]
                });
                break;
            }
        case "messages":
            {
                languageModelMessages.push(...prompt.messages.map(convertToLanguageModelMessage));
                break;
            }
        default:
            {
                const _exhaustiveCheck = promptType;
                throw new Error(`Unsupported prompt type: ${_exhaustiveCheck}`);
            }
    }
    return languageModelMessages;
}
function convertToLanguageModelMessage(message) {
    const role = message.role;
    switch(role){
        case "system":
            {
                return {
                    role: "system",
                    content: message.content
                };
            }
        case "user":
            {
                if (typeof message.content === "string") {
                    return {
                        role: "user",
                        content: [
                            {
                                type: "text",
                                text: message.content
                            }
                        ]
                    };
                }
                return {
                    role: "user",
                    content: message.content.map((part)=>{
                        var _a;
                        switch(part.type){
                            case "text":
                                {
                                    return part;
                                }
                            case "image":
                                {
                                    if (part.image instanceof URL) {
                                        return {
                                            type: "image",
                                            image: part.image,
                                            mimeType: part.mimeType
                                        };
                                    }
                                    if (typeof part.image === "string") {
                                        try {
                                            const url = new URL(part.image);
                                            switch(url.protocol){
                                                case "http:":
                                                case "https:":
                                                    {
                                                        return {
                                                            type: "image",
                                                            image: url,
                                                            mimeType: part.mimeType
                                                        };
                                                    }
                                                case "data:":
                                                    {
                                                        try {
                                                            const [header, base64Content] = part.image.split(",");
                                                            const mimeType = header.split(";")[0].split(":")[1];
                                                            if (mimeType == null || base64Content == null) {
                                                                throw new Error("Invalid data URL format");
                                                            }
                                                            return {
                                                                type: "image",
                                                                image: convertDataContentToUint8Array(base64Content),
                                                                mimeType
                                                            };
                                                        } catch (error) {
                                                            throw new Error(`Error processing data URL: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(message)}`);
                                                        }
                                                    }
                                                default:
                                                    {
                                                        throw new Error(`Unsupported URL protocol: ${url.protocol}`);
                                                    }
                                            }
                                        } catch (_ignored) {}
                                    }
                                    const imageUint8 = convertDataContentToUint8Array(part.image);
                                    return {
                                        type: "image",
                                        image: imageUint8,
                                        mimeType: (_a = part.mimeType) != null ? _a : detectImageMimeType(imageUint8)
                                    };
                                }
                        }
                    })
                };
            }
        case "assistant":
            {
                if (typeof message.content === "string") {
                    return {
                        role: "assistant",
                        content: [
                            {
                                type: "text",
                                text: message.content
                            }
                        ]
                    };
                }
                return {
                    role: "assistant",
                    content: message.content.filter(// remove empty text parts:
                    (part)=>part.type !== "text" || part.text !== "")
                };
            }
        case "tool":
            {
                return message;
            }
        default:
            {
                const _exhaustiveCheck = role;
                throw new InvalidMessageRoleError({
                    role: _exhaustiveCheck
                });
            }
    }
}
;
function getValidatedPrompt(prompt) {
    if (prompt.prompt == null && prompt.messages == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "prompt or messages must be defined"
        });
    }
    if (prompt.prompt != null && prompt.messages != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "prompt and messages cannot be defined at the same time"
        });
    }
    return prompt.prompt != null ? {
        type: "prompt",
        prompt: prompt.prompt,
        messages: void 0,
        system: prompt.system
    } : {
        type: "messages",
        prompt: void 0,
        messages: prompt.messages,
        // only possible case bc of checks above
        system: prompt.system
    };
}
;
function prepareCallSettings({ maxTokens, temperature, topP, presencePenalty, frequencyPenalty, seed, maxRetries }) {
    if (maxTokens != null) {
        if (!Number.isInteger(maxTokens)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "maxTokens",
                value: maxTokens,
                message: "maxTokens must be an integer"
            });
        }
        if (maxTokens < 1) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "maxTokens",
                value: maxTokens,
                message: "maxTokens must be >= 1"
            });
        }
    }
    if (temperature != null) {
        if (typeof temperature !== "number") {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "temperature",
                value: temperature,
                message: "temperature must be a number"
            });
        }
    }
    if (topP != null) {
        if (typeof topP !== "number") {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "topP",
                value: topP,
                message: "topP must be a number"
            });
        }
    }
    if (presencePenalty != null) {
        if (typeof presencePenalty !== "number") {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "presencePenalty",
                value: presencePenalty,
                message: "presencePenalty must be a number"
            });
        }
    }
    if (frequencyPenalty != null) {
        if (typeof frequencyPenalty !== "number") {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "frequencyPenalty",
                value: frequencyPenalty,
                message: "frequencyPenalty must be a number"
            });
        }
    }
    if (seed != null) {
        if (!Number.isInteger(seed)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "seed",
                value: seed,
                message: "seed must be an integer"
            });
        }
    }
    if (maxRetries != null) {
        if (!Number.isInteger(maxRetries)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "maxRetries",
                value: maxRetries,
                message: "maxRetries must be an integer"
            });
        }
        if (maxRetries < 0) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
                parameter: "maxRetries",
                value: maxRetries,
                message: "maxRetries must be >= 0"
            });
        }
    }
    return {
        maxTokens,
        temperature: temperature != null ? temperature : 0,
        topP,
        presencePenalty,
        frequencyPenalty,
        seed,
        maxRetries: maxRetries != null ? maxRetries : 2
    };
}
;
function convertZodToJSONSchema(zodSchema) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$22$2e$5_zod$40$3$2e$23$2e$8$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(zodSchema);
}
// core/util/is-non-empty-object.ts
function isNonEmptyObject(object) {
    return object != null && Object.keys(object).length > 0;
}
// core/prompt/prepare-tools-and-tool-choice.ts
function prepareToolsAndToolChoice({ tools, toolChoice }) {
    if (!isNonEmptyObject(tools)) {
        return {
            tools: void 0,
            toolChoice: void 0
        };
    }
    return {
        tools: Object.entries(tools).map(([name, tool])=>({
                type: "function",
                name,
                description: tool.description,
                parameters: convertZodToJSONSchema(tool.parameters)
            })),
        toolChoice: toolChoice == null ? {
            type: "auto"
        } : typeof toolChoice === "string" ? {
            type: toolChoice
        } : {
            type: "tool",
            toolName: toolChoice.toolName
        }
    };
}
;
function createEventStreamTransformer(customParser) {
    const textDecoder = new TextDecoder();
    let eventSourceParser;
    return new TransformStream({
        async start (controller) {
            eventSourceParser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$eventsource$2d$parser$40$1$2e$1$2e$2$2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createParser"])((event)=>{
                if ("data" in event && event.type === "event" && event.data === "[DONE]" || // Replicate doesn't send [DONE] but does send a 'done' event
                // @see https://replicate.com/docs/streaming
                event.event === "done") {
                    controller.terminate();
                    return;
                }
                if ("data" in event) {
                    const parsedMessage = customParser ? customParser(event.data, {
                        event: event.event
                    }) : event.data;
                    if (parsedMessage) controller.enqueue(parsedMessage);
                }
            });
        },
        transform (chunk) {
            eventSourceParser.feed(textDecoder.decode(chunk));
        }
    });
}
function createCallbacksTransformer(cb) {
    const textEncoder = new TextEncoder();
    let aggregatedResponse = "";
    const callbacks = cb || {};
    return new TransformStream({
        async start () {
            if (callbacks.onStart) await callbacks.onStart();
        },
        async transform (message, controller) {
            const content = typeof message === "string" ? message : message.content;
            controller.enqueue(textEncoder.encode(content));
            aggregatedResponse += content;
            if (callbacks.onToken) await callbacks.onToken(content);
            if (callbacks.onText && typeof message === "string") {
                await callbacks.onText(message);
            }
        },
        async flush () {
            const isOpenAICallbacks = isOfTypeOpenAIStreamCallbacks(callbacks);
            if (callbacks.onCompletion) {
                await callbacks.onCompletion(aggregatedResponse);
            }
            if (callbacks.onFinal && !isOpenAICallbacks) {
                await callbacks.onFinal(aggregatedResponse);
            }
        }
    });
}
function isOfTypeOpenAIStreamCallbacks(callbacks) {
    return "experimental_onFunctionCall" in callbacks;
}
function trimStartOfStreamHelper() {
    let isStreamStart = true;
    return (text)=>{
        if (isStreamStart) {
            text = text.trimStart();
            if (text) isStreamStart = false;
        }
        return text;
    };
}
function AIStream(response, customParser, callbacks) {
    if (!response.ok) {
        if (response.body) {
            const reader = response.body.getReader();
            return new ReadableStream({
                async start (controller) {
                    const { done, value } = await reader.read();
                    if (!done) {
                        const errorText = new TextDecoder().decode(value);
                        controller.error(new Error(`Response error: ${errorText}`));
                    }
                }
            });
        } else {
            return new ReadableStream({
                start (controller) {
                    controller.error(new Error("Response error: No response body"));
                }
            });
        }
    }
    const responseBodyStream = response.body || createEmptyReadableStream();
    return responseBodyStream.pipeThrough(createEventStreamTransformer(customParser)).pipeThrough(createCallbacksTransformer(callbacks));
}
function createEmptyReadableStream() {
    return new ReadableStream({
        start (controller) {
            controller.close();
        }
    });
}
function readableFromAsyncIterable(iterable) {
    let it = iterable[Symbol.asyncIterator]();
    return new ReadableStream({
        async pull (controller) {
            const { done, value } = await it.next();
            if (done) controller.close();
            else controller.enqueue(value);
        },
        async cancel (reason) {
            var _a;
            await ((_a = it.return) == null ? void 0 : _a.call(it, reason));
        }
    });
}
;
function createStreamDataTransformer() {
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    return new TransformStream({
        transform: async (chunk, controller)=>{
            const message = decoder.decode(chunk);
            controller.enqueue(encoder.encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatStreamPart"])("text", message)));
        }
    });
}
;
function parseOpenAIStream() {
    const extract = chunkToText();
    return (data)=>extract(JSON.parse(data));
}
async function* streamable(stream) {
    const extract = chunkToText();
    for await (let chunk of stream){
        if ("promptFilterResults" in chunk) {
            chunk = {
                id: chunk.id,
                created: chunk.created.getDate(),
                object: chunk.object,
                // not exposed by Azure API
                model: chunk.model,
                // not exposed by Azure API
                choices: chunk.choices.map((choice)=>{
                    var _a, _b, _c, _d, _e, _f, _g;
                    return {
                        delta: {
                            content: (_a = choice.delta) == null ? void 0 : _a.content,
                            function_call: (_b = choice.delta) == null ? void 0 : _b.functionCall,
                            role: (_c = choice.delta) == null ? void 0 : _c.role,
                            tool_calls: ((_e = (_d = choice.delta) == null ? void 0 : _d.toolCalls) == null ? void 0 : _e.length) ? (_g = (_f = choice.delta) == null ? void 0 : _f.toolCalls) == null ? void 0 : _g.map((toolCall, index)=>({
                                    index,
                                    id: toolCall.id,
                                    function: toolCall.function,
                                    type: toolCall.type
                                })) : void 0
                        },
                        finish_reason: choice.finishReason,
                        index: choice.index
                    };
                })
            };
        }
        const text = extract(chunk);
        if (text) yield text;
    }
}
function chunkToText() {
    const trimStartOfStream = trimStartOfStreamHelper();
    let isFunctionStreamingIn;
    return (json)=>{
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r;
        if (isChatCompletionChunk(json)) {
            const delta = (_a = json.choices[0]) == null ? void 0 : _a.delta;
            if ((_b = delta.function_call) == null ? void 0 : _b.name) {
                isFunctionStreamingIn = true;
                return {
                    isText: false,
                    content: `{"function_call": {"name": "${delta.function_call.name}", "arguments": "`
                };
            } else if ((_e = (_d = (_c = delta.tool_calls) == null ? void 0 : _c[0]) == null ? void 0 : _d.function) == null ? void 0 : _e.name) {
                isFunctionStreamingIn = true;
                const toolCall = delta.tool_calls[0];
                if (toolCall.index === 0) {
                    return {
                        isText: false,
                        content: `{"tool_calls":[ {"id": "${toolCall.id}", "type": "function", "function": {"name": "${(_f = toolCall.function) == null ? void 0 : _f.name}", "arguments": "`
                    };
                } else {
                    return {
                        isText: false,
                        content: `"}}, {"id": "${toolCall.id}", "type": "function", "function": {"name": "${(_g = toolCall.function) == null ? void 0 : _g.name}", "arguments": "`
                    };
                }
            } else if ((_h = delta.function_call) == null ? void 0 : _h.arguments) {
                return {
                    isText: false,
                    content: cleanupArguments((_i = delta.function_call) == null ? void 0 : _i.arguments)
                };
            } else if ((_l = (_k = (_j = delta.tool_calls) == null ? void 0 : _j[0]) == null ? void 0 : _k.function) == null ? void 0 : _l.arguments) {
                return {
                    isText: false,
                    content: cleanupArguments((_o = (_n = (_m = delta.tool_calls) == null ? void 0 : _m[0]) == null ? void 0 : _n.function) == null ? void 0 : _o.arguments)
                };
            } else if (isFunctionStreamingIn && (((_p = json.choices[0]) == null ? void 0 : _p.finish_reason) === "function_call" || ((_q = json.choices[0]) == null ? void 0 : _q.finish_reason) === "stop")) {
                isFunctionStreamingIn = false;
                return {
                    isText: false,
                    content: '"}}'
                };
            } else if (isFunctionStreamingIn && ((_r = json.choices[0]) == null ? void 0 : _r.finish_reason) === "tool_calls") {
                isFunctionStreamingIn = false;
                return {
                    isText: false,
                    content: '"}}]}'
                };
            }
        }
        const text = trimStartOfStream(isChatCompletionChunk(json) && json.choices[0].delta.content ? json.choices[0].delta.content : isCompletion(json) ? json.choices[0].text : "");
        return text;
    };
    function cleanupArguments(argumentChunk) {
        let escapedPartialJson = argumentChunk.replace(/\\/g, "\\\\").replace(/\//g, "\\/").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        return `${escapedPartialJson}`;
    }
}
var __internal__OpenAIFnMessagesSymbol = Symbol("internal_openai_fn_messages");
function isChatCompletionChunk(data) {
    return "choices" in data && data.choices && data.choices[0] && "delta" in data.choices[0];
}
function isCompletion(data) {
    return "choices" in data && data.choices && data.choices[0] && "text" in data.choices[0];
}
function OpenAIStream(res, callbacks) {
    const cb = callbacks;
    let stream;
    if (Symbol.asyncIterator in res) {
        stream = readableFromAsyncIterable(streamable(res)).pipeThrough(createCallbacksTransformer((cb == null ? void 0 : cb.experimental_onFunctionCall) || (cb == null ? void 0 : cb.experimental_onToolCall) ? {
            ...cb,
            onFinal: void 0
        } : {
            ...cb
        }));
    } else {
        stream = AIStream(res, parseOpenAIStream(), (cb == null ? void 0 : cb.experimental_onFunctionCall) || (cb == null ? void 0 : cb.experimental_onToolCall) ? {
            ...cb,
            onFinal: void 0
        } : {
            ...cb
        });
    }
    if (cb && (cb.experimental_onFunctionCall || cb.experimental_onToolCall)) {
        const functionCallTransformer = createFunctionCallTransformer(cb);
        return stream.pipeThrough(functionCallTransformer);
    } else {
        return stream.pipeThrough(createStreamDataTransformer());
    }
}
function createFunctionCallTransformer(callbacks) {
    const textEncoder = new TextEncoder();
    let isFirstChunk = true;
    let aggregatedResponse = "";
    let aggregatedFinalCompletionResponse = "";
    let isFunctionStreamingIn = false;
    let functionCallMessages = callbacks[__internal__OpenAIFnMessagesSymbol] || [];
    const decode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createChunkDecoder"])();
    return new TransformStream({
        async transform (chunk, controller) {
            const message = decode(chunk);
            aggregatedFinalCompletionResponse += message;
            const shouldHandleAsFunction = isFirstChunk && (message.startsWith('{"function_call":') || message.startsWith('{"tool_calls":'));
            if (shouldHandleAsFunction) {
                isFunctionStreamingIn = true;
                aggregatedResponse += message;
                isFirstChunk = false;
                return;
            }
            if (!isFunctionStreamingIn) {
                controller.enqueue(textEncoder.encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatStreamPart"])("text", message)));
                return;
            } else {
                aggregatedResponse += message;
            }
        },
        async flush (controller) {
            try {
                if (!isFirstChunk && isFunctionStreamingIn && (callbacks.experimental_onFunctionCall || callbacks.experimental_onToolCall)) {
                    isFunctionStreamingIn = false;
                    const payload = JSON.parse(aggregatedResponse);
                    let newFunctionCallMessages = [
                        ...functionCallMessages
                    ];
                    let functionResponse = void 0;
                    if (callbacks.experimental_onFunctionCall) {
                        if (payload.function_call === void 0) {
                            console.warn("experimental_onFunctionCall should not be defined when using tools");
                        }
                        const argumentsPayload = JSON.parse(payload.function_call.arguments);
                        functionResponse = await callbacks.experimental_onFunctionCall({
                            name: payload.function_call.name,
                            arguments: argumentsPayload
                        }, (result)=>{
                            newFunctionCallMessages = [
                                ...functionCallMessages,
                                {
                                    role: "assistant",
                                    content: "",
                                    function_call: payload.function_call
                                },
                                {
                                    role: "function",
                                    name: payload.function_call.name,
                                    content: JSON.stringify(result)
                                }
                            ];
                            return newFunctionCallMessages;
                        });
                    }
                    if (callbacks.experimental_onToolCall) {
                        const toolCalls = {
                            tools: []
                        };
                        for (const tool of payload.tool_calls){
                            toolCalls.tools.push({
                                id: tool.id,
                                type: "function",
                                func: {
                                    name: tool.function.name,
                                    arguments: JSON.parse(tool.function.arguments)
                                }
                            });
                        }
                        let responseIndex = 0;
                        try {
                            functionResponse = await callbacks.experimental_onToolCall(toolCalls, (result)=>{
                                if (result) {
                                    const { tool_call_id, function_name, tool_call_result } = result;
                                    newFunctionCallMessages = [
                                        ...newFunctionCallMessages,
                                        // Only append the assistant message if it's the first response
                                        ...responseIndex === 0 ? [
                                            {
                                                role: "assistant",
                                                content: "",
                                                tool_calls: payload.tool_calls.map((tc)=>({
                                                        id: tc.id,
                                                        type: "function",
                                                        function: {
                                                            name: tc.function.name,
                                                            // we send the arguments an object to the user, but as the API expects a string, we need to stringify it
                                                            arguments: JSON.stringify(tc.function.arguments)
                                                        }
                                                    }))
                                            }
                                        ] : [],
                                        // Append the function call result message
                                        {
                                            role: "tool",
                                            tool_call_id,
                                            name: function_name,
                                            content: JSON.stringify(tool_call_result)
                                        }
                                    ];
                                    responseIndex++;
                                }
                                return newFunctionCallMessages;
                            });
                        } catch (e) {
                            console.error("Error calling experimental_onToolCall:", e);
                        }
                    }
                    if (!functionResponse) {
                        controller.enqueue(textEncoder.encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatStreamPart"])(payload.function_call ? "function_call" : "tool_calls", // parse to prevent double-encoding:
                        JSON.parse(aggregatedResponse))));
                        return;
                    } else if (typeof functionResponse === "string") {
                        controller.enqueue(textEncoder.encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$ui$2d$utils$40$0$2e$0$2e$9_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatStreamPart"])("text", functionResponse)));
                        aggregatedFinalCompletionResponse = functionResponse;
                        return;
                    }
                    const filteredCallbacks = {
                        ...callbacks,
                        onStart: void 0
                    };
                    callbacks.onFinal = void 0;
                    const openAIStream = OpenAIStream(functionResponse, {
                        ...filteredCallbacks,
                        [__internal__OpenAIFnMessagesSymbol]: newFunctionCallMessages
                    });
                    const reader = openAIStream.getReader();
                    while(true){
                        const { done, value } = await reader.read();
                        if (done) {
                            break;
                        }
                        controller.enqueue(value);
                    }
                }
            } finally{
                if (callbacks.onFinal && aggregatedFinalCompletionResponse) {
                    await callbacks.onFinal(aggregatedFinalCompletionResponse);
                }
            }
        }
    });
}
// rsc/constants.ts
var STREAMABLE_VALUE_TYPE = Symbol.for("ui.streamable.value");
var DEV_DEFAULT_STREAMABLE_WARNING_TIME = 15 * 1e3;
// rsc/streamable.tsx
function createStreamableUI(initialValue) {
    let currentValue = initialValue;
    let closed = false;
    let { row, resolve, reject } = createSuspensedChunk(initialValue);
    function assertStream(method) {
        if (closed) {
            throw new Error(method + ": UI stream is already closed.");
        }
    }
    let warningTimeout;
    function warnUnclosedStream() {
        if ("TURBOPACK compile-time truthy", 1) {
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            warningTimeout = setTimeout(()=>{
                console.warn("The streamable UI has been slow to update. This may be a bug or a performance issue or you forgot to call `.done()`.");
            }, DEV_DEFAULT_STREAMABLE_WARNING_TIME);
        }
    }
    warnUnclosedStream();
    const streamable2 = {
        value: row,
        update (value) {
            assertStream(".update()");
            if (value === currentValue) {
                warnUnclosedStream();
                return streamable2;
            }
            const resolvable = createResolvablePromise();
            currentValue = value;
            resolve({
                value: currentValue,
                done: false,
                next: resolvable.promise
            });
            resolve = resolvable.resolve;
            reject = resolvable.reject;
            warnUnclosedStream();
            return streamable2;
        },
        append (value) {
            assertStream(".append()");
            const resolvable = createResolvablePromise();
            currentValue = value;
            resolve({
                value,
                done: false,
                append: true,
                next: resolvable.promise
            });
            resolve = resolvable.resolve;
            reject = resolvable.reject;
            warnUnclosedStream();
            return streamable2;
        },
        error (error) {
            assertStream(".error()");
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            closed = true;
            reject(error);
            return streamable2;
        },
        done (...args) {
            assertStream(".done()");
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            closed = true;
            if (args.length) {
                resolve({
                    value: args[0],
                    done: true
                });
                return streamable2;
            }
            resolve({
                value: currentValue,
                done: true
            });
            return streamable2;
        }
    };
    return streamable2;
}
var STREAMABLE_VALUE_INTERNAL_LOCK = Symbol("streamable.value.lock");
function createStreamableValue(initialValue) {
    const isReadableStream = initialValue instanceof ReadableStream || typeof initialValue === "object" && initialValue !== null && "getReader" in initialValue && typeof initialValue.getReader === "function" && "locked" in initialValue && typeof initialValue.locked === "boolean";
    if (!isReadableStream) {
        return createStreamableValueImpl(initialValue);
    }
    const streamableValue = createStreamableValueImpl();
    streamableValue[STREAMABLE_VALUE_INTERNAL_LOCK] = true;
    (async ()=>{
        try {
            const reader = initialValue.getReader();
            while(true){
                const { value, done } = await reader.read();
                if (done) {
                    break;
                }
                streamableValue[STREAMABLE_VALUE_INTERNAL_LOCK] = false;
                if (typeof value === "string") {
                    streamableValue.append(value);
                } else {
                    streamableValue.update(value);
                }
                streamableValue[STREAMABLE_VALUE_INTERNAL_LOCK] = true;
            }
            streamableValue[STREAMABLE_VALUE_INTERNAL_LOCK] = false;
            streamableValue.done();
        } catch (e) {
            streamableValue[STREAMABLE_VALUE_INTERNAL_LOCK] = false;
            streamableValue.error(e);
        }
    })();
    return streamableValue;
}
function createStreamableValueImpl(initialValue) {
    let closed = false;
    let locked = false;
    let resolvable = createResolvablePromise();
    let currentValue = initialValue;
    let currentError;
    let currentPromise = resolvable.promise;
    let currentPatchValue;
    function assertStream(method) {
        if (closed) {
            throw new Error(method + ": Value stream is already closed.");
        }
        if (locked) {
            throw new Error(method + ": Value stream is locked and cannot be updated.");
        }
    }
    let warningTimeout;
    function warnUnclosedStream() {
        if ("TURBOPACK compile-time truthy", 1) {
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            warningTimeout = setTimeout(()=>{
                console.warn("The streamable UI has been slow to update. This may be a bug or a performance issue or you forgot to call `.done()`.");
            }, DEV_DEFAULT_STREAMABLE_WARNING_TIME);
        }
    }
    warnUnclosedStream();
    function createWrapped(initialChunk) {
        let init;
        if (currentError !== void 0) {
            init = {
                error: currentError
            };
        } else {
            if (currentPatchValue && !initialChunk) {
                init = {
                    diff: currentPatchValue
                };
            } else {
                init = {
                    curr: currentValue
                };
            }
        }
        if (currentPromise) {
            init.next = currentPromise;
        }
        if (initialChunk) {
            init.type = STREAMABLE_VALUE_TYPE;
        }
        return init;
    }
    function updateValueStates(value) {
        currentPatchValue = void 0;
        if (typeof value === "string") {
            if (typeof currentValue === "string") {
                if (value.startsWith(currentValue)) {
                    currentPatchValue = [
                        0,
                        value.slice(currentValue.length)
                    ];
                }
            }
        }
        currentValue = value;
    }
    const streamable2 = {
        set [STREAMABLE_VALUE_INTERNAL_LOCK] (state){
            locked = state;
        },
        get value () {
            return createWrapped(true);
        },
        update (value) {
            assertStream(".update()");
            const resolvePrevious = resolvable.resolve;
            resolvable = createResolvablePromise();
            updateValueStates(value);
            currentPromise = resolvable.promise;
            resolvePrevious(createWrapped());
            warnUnclosedStream();
            return streamable2;
        },
        append (value) {
            assertStream(".append()");
            if (typeof currentValue !== "string" && typeof currentValue !== "undefined") {
                throw new Error(`.append(): The current value is not a string. Received: ${typeof currentValue}`);
            }
            if (typeof value !== "string") {
                throw new Error(`.append(): The value is not a string. Received: ${typeof value}`);
            }
            const resolvePrevious = resolvable.resolve;
            resolvable = createResolvablePromise();
            if (typeof currentValue === "string") {
                currentPatchValue = [
                    0,
                    value
                ];
                currentValue = currentValue + value;
            } else {
                currentPatchValue = void 0;
                currentValue = value;
            }
            currentPromise = resolvable.promise;
            resolvePrevious(createWrapped());
            warnUnclosedStream();
            return streamable2;
        },
        error (error) {
            assertStream(".error()");
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            closed = true;
            currentError = error;
            currentPromise = void 0;
            resolvable.resolve({
                error
            });
            return streamable2;
        },
        done (...args) {
            assertStream(".done()");
            if (warningTimeout) {
                clearTimeout(warningTimeout);
            }
            closed = true;
            currentPromise = void 0;
            if (args.length) {
                updateValueStates(args[0]);
                resolvable.resolve(createWrapped());
                return streamable2;
            }
            resolvable.resolve({});
            return streamable2;
        }
    };
    return streamable2;
}
function render(options) {
    const ui = createStreamableUI(options.initial);
    const text = options.text ? options.text : ({ content })=>content;
    const functions = options.functions ? Object.entries(options.functions).map(([name, { description, parameters }])=>{
        return {
            name,
            description,
            parameters: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$22$2e$5_zod$40$3$2e$23$2e$8$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(parameters)
        };
    }) : void 0;
    const tools = options.tools ? Object.entries(options.tools).map(([name, { description, parameters }])=>{
        return {
            type: "function",
            function: {
                name,
                description,
                parameters: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$22$2e$5_zod$40$3$2e$23$2e$8$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(parameters)
            }
        };
    }) : void 0;
    if (functions && tools) {
        throw new Error("You can't have both functions and tools defined. Please choose one or the other.");
    }
    let finished;
    async function handleRender(args, renderer, res) {
        if (!renderer) return;
        const resolvable = createResolvablePromise();
        if (finished) {
            finished = finished.then(()=>resolvable.promise);
        } else {
            finished = resolvable.promise;
        }
        const value = renderer(args);
        if (value instanceof Promise || value && typeof value === "object" && "then" in value && typeof value.then === "function") {
            const node = await value;
            res.update(node);
            resolvable.resolve(void 0);
        } else if (value && typeof value === "object" && Symbol.asyncIterator in value) {
            const it = value;
            while(true){
                const { done, value: value2 } = await it.next();
                res.update(value2);
                if (done) break;
            }
            resolvable.resolve(void 0);
        } else if (value && typeof value === "object" && Symbol.iterator in value) {
            const it = value;
            while(true){
                const { done, value: value2 } = it.next();
                res.update(value2);
                if (done) break;
            }
            resolvable.resolve(void 0);
        } else {
            res.update(value);
            resolvable.resolve(void 0);
        }
    }
    (async ()=>{
        let hasFunction = false;
        let content = "";
        consumeStream(OpenAIStream(await options.provider.chat.completions.create({
            model: options.model,
            messages: options.messages,
            temperature: options.temperature,
            stream: true,
            ...functions ? {
                functions
            } : {},
            ...tools ? {
                tools
            } : {}
        }), {
            ...functions ? {
                async experimental_onFunctionCall (functionCallPayload) {
                    var _a, _b;
                    hasFunction = true;
                    handleRender(functionCallPayload.arguments, (_b = (_a = options.functions) == null ? void 0 : _a[functionCallPayload.name]) == null ? void 0 : _b.render, ui);
                }
            } : {},
            ...tools ? {
                async experimental_onToolCall (toolCallPayload) {
                    var _a, _b;
                    hasFunction = true;
                    for (const tool of toolCallPayload.tools){
                        handleRender(tool.func.arguments, (_b = (_a = options.tools) == null ? void 0 : _a[tool.func.name]) == null ? void 0 : _b.render, ui);
                    }
                }
            } : {},
            onText (chunk) {
                content += chunk;
                handleRender({
                    content,
                    done: false,
                    delta: chunk
                }, text, ui);
            },
            async onFinal () {
                if (hasFunction) {
                    await finished;
                    ui.done();
                    return;
                }
                handleRender({
                    content,
                    done: true
                }, text, ui);
                await finished;
                ui.done();
            }
        }));
    })();
    return ui.value;
}
;
;
var defaultTextRenderer = ({ content })=>content;
async function streamUI({ model, tools, toolChoice, system, prompt, messages, maxRetries, abortSignal, headers, initial, text, onFinish, ...settings }) {
    if (typeof model === "string") {
        throw new Error("`model` cannot be a string in `streamUI`. Use the actual model instance instead.");
    }
    if ("functions" in settings) {
        throw new Error("`functions` is not supported in `streamUI`, use `tools` instead.");
    }
    if ("provider" in settings) {
        throw new Error("`provider` is no longer needed in `streamUI`. Use `model` instead.");
    }
    if (tools) {
        for (const [name, tool] of Object.entries(tools)){
            if ("render" in tool) {
                throw new Error("Tool definition in `streamUI` should not have `render` property. Use `generate` instead. Found in tool: " + name);
            }
        }
    }
    const ui = createStreamableUI(initial);
    const textRender = text || defaultTextRenderer;
    let finished;
    async function handleRender(args, renderer, res, lastCall = false) {
        if (!renderer) return;
        const resolvable = createResolvablePromise();
        if (finished) {
            finished = finished.then(()=>resolvable.promise);
        } else {
            finished = resolvable.promise;
        }
        const value = renderer(...args);
        if (value instanceof Promise || value && typeof value === "object" && "then" in value && typeof value.then === "function") {
            const node = await value;
            if (lastCall) {
                res.done(node);
            } else {
                res.update(node);
            }
            resolvable.resolve(void 0);
        } else if (value && typeof value === "object" && Symbol.asyncIterator in value) {
            const it = value;
            while(true){
                const { done, value: value2 } = await it.next();
                if (lastCall && done) {
                    res.done(value2);
                } else {
                    res.update(value2);
                }
                if (done) break;
            }
            resolvable.resolve(void 0);
        } else if (value && typeof value === "object" && Symbol.iterator in value) {
            const it = value;
            while(true){
                const { done, value: value2 } = it.next();
                if (lastCall && done) {
                    res.done(value2);
                } else {
                    res.update(value2);
                }
                if (done) break;
            }
            resolvable.resolve(void 0);
        } else {
            if (lastCall) {
                res.done(value);
            } else {
                res.update(value);
            }
            resolvable.resolve(void 0);
        }
    }
    const retry = retryWithExponentialBackoff({
        maxRetries
    });
    const validatedPrompt = getValidatedPrompt({
        system,
        prompt,
        messages
    });
    const result = await retry(()=>model.doStream({
            mode: {
                type: "regular",
                ...prepareToolsAndToolChoice({
                    tools,
                    toolChoice
                })
            },
            ...prepareCallSettings(settings),
            inputFormat: validatedPrompt.type,
            prompt: convertToLanguageModelPrompt(validatedPrompt),
            abortSignal,
            headers
        }));
    const [stream, forkedStream] = result.stream.tee();
    (async ()=>{
        try {
            let content = "";
            let hasToolCall = false;
            const reader = forkedStream.getReader();
            while(true){
                const { done, value } = await reader.read();
                if (done) break;
                switch(value.type){
                    case "text-delta":
                        {
                            content += value.textDelta;
                            handleRender([
                                {
                                    content,
                                    done: false,
                                    delta: value.textDelta
                                }
                            ], textRender, ui);
                            break;
                        }
                    case "tool-call-delta":
                        {
                            hasToolCall = true;
                            break;
                        }
                    case "tool-call":
                        {
                            const toolName = value.toolName;
                            if (!tools) {
                                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NoSuchToolError"]({
                                    toolName
                                });
                            }
                            const tool = tools[toolName];
                            if (!tool) {
                                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NoSuchToolError"]({
                                    toolName,
                                    availableTools: Object.keys(tools)
                                });
                            }
                            hasToolCall = true;
                            const parseResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$2d$utils$40$1$2e$0$2e$0_zod$40$3$2e$23$2e$8$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["safeParseJSON"])({
                                text: value.args,
                                schema: tool.parameters
                            });
                            if (parseResult.success === false) {
                                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$provider$40$0$2e$0$2e$11$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InvalidToolArgumentsError"]({
                                    toolName,
                                    toolArgs: value.args,
                                    cause: parseResult.error
                                });
                            }
                            handleRender([
                                parseResult.value,
                                {
                                    toolName,
                                    toolCallId: value.toolCallId
                                }
                            ], tool.generate, ui, true);
                            break;
                        }
                    case "error":
                        {
                            throw value.error;
                        }
                    case "finish":
                        {
                            onFinish == null ? void 0 : onFinish({
                                finishReason: value.finishReason,
                                usage: calculateTokenUsage(value.usage),
                                value: ui.value,
                                warnings: result.warnings,
                                rawResponse: result.rawResponse
                            });
                        }
                }
            }
            if (hasToolCall) {
                await finished;
            } else {
                handleRender([
                    {
                        content,
                        done: true
                    }
                ], textRender, ui, true);
                await finished;
            }
        } catch (error) {
            ui.error(error);
        }
    })();
    return {
        ...result,
        stream,
        value: ui.value
    };
}
;
;
;
var innerAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])("e35476d11c777b26667915186a13fedb75b19bf1", $$ACTION_0);
async function $$ACTION_0({ action, options }, state1, ...args) {
    return await withAIState({
        state: state1,
        options
    }, async ()=>{
        const result = await action(...args);
        sealMutableAIState();
        return [
            getAIStateDeltaPromise(),
            result
        ];
    });
}
function wrapAction(action, options) {
    return innerAction.bind(null, {
        action,
        options
    });
}
function createAI({ actions, initialAIState, initialUIState, onSetAIState, onGetUIState }) {
    const wrappedActions = {};
    for(const name in actions){
        wrappedActions[name] = wrapAction(actions[name], {
            onSetAIState
        });
    }
    const wrappedSyncUIState = onGetUIState ? wrapAction(onGetUIState, {}) : void 0;
    const AI = async (props)=>{
        var _a, _b;
        if ("useState" in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__) {
            throw new Error("This component can only be used inside Server Components.");
        }
        let uiState = (_a = props.initialUIState) != null ? _a : initialUIState;
        let aiState = (_b = props.initialAIState) != null ? _b : initialAIState;
        let aiStateDelta = void 0;
        if (wrappedSyncUIState) {
            const [newAIStateDelta, newUIState] = await wrappedSyncUIState(aiState);
            if (newUIState !== void 0) {
                aiStateDelta = newAIStateDelta;
                uiState = newUIState;
            }
        }
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$14$2e$2$2e$4_react$2d$dom$40$18$2e$3$2e$1_react$40$18$2e$3$2e$1_$5f$react$40$18$2e$3$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ai$40$3$2e$2$2e$16_openai$40$4$2e$52$2e$2_react$40$18$2e$3$2e$1_svelte$40$4$2e$2$2e$18_vue$40$3$2e$4$2e$31_typescript$40$5$2e$5$2e$2_$5f$zod$40$3$2e$23$2e$8$2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$shared$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InternalAIProvider"], {
            wrappedActions,
            wrappedSyncUIState,
            initialUIState: uiState,
            initialAIState: aiState,
            initialAIStatePatch: aiStateDelta,
            children: props.children
        });
    };
    return AI;
}
;
 //# sourceMappingURL=rsc-server.mjs.map

})()),
"[project]/.next-internal/server/app/play-ground/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/app/login/actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/lib/chat/actions.tsx [app-rsc] (ecmascript)\", ACTIONS_MODULE3 => \"[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-server.mjs [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

__turbopack_export_value__({
    '18165312b87b38c8eeea9c03383b142333a1ad1b': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['getChat'])(...args)),
    '31009c7e4eb3a1734f1c375d268a8d7fb6265461': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['removeChat'])(...args)),
    '41c0dcd5c5291966abcf0a0b596c982656f90cec': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/login/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['authenticate'])(...args)),
    '4cce0840ac9b329a49dfe73eb7178760406da35a': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['getMissingKeys'])(...args)),
    '5e03bcf849e13ca19473aba42d365d04b06cc25f': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['clearChats'])(...args)),
    '6ca9c22386c40a18919c3de1ab9497503920cb02': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['getChats'])(...args)),
    '718cbc29b764923891ed4b7989778bae0bcf4d5b': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['refreshHistory'])(...args)),
    'a8bbe34e13a85554c86edd279e11a5d47f9ac99f': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['shareChat'])(...args)),
    'ab97caf8205be2cafa5e15f7d14d3b611771b349': (...args)=>Promise.resolve(__turbopack_require__("[project]/lib/chat/actions.tsx [app-rsc] (ecmascript)")).then((mod)=>(0, mod['$$ACTION_0'])(...args)),
    'b9866039bc2be50317d38a6877bc3db70570090d': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['saveChat'])(...args)),
    'c8fa3317f36f19ea4d0892b9476f0b602c0a04d0': (...args)=>Promise.resolve(__turbopack_require__("[project]/lib/chat/actions.tsx [app-rsc] (ecmascript)")).then((mod)=>(0, mod['$$ACTION_1'])(...args)),
    'c9d0a5a7cbcec3e236840f2cbe72dd889bdf72b8': (...args)=>Promise.resolve(__turbopack_require__("[project]/lib/chat/actions.tsx [app-rsc] (ecmascript)")).then((mod)=>(0, mod['$$ACTION_2'])(...args)),
    'd5acf6a4dfbe80c4e6e05dcee9d7efa1779e6793': (...args)=>Promise.resolve(__turbopack_require__("[project]/lib/chat/actions.tsx [app-rsc] (ecmascript)")).then((mod)=>(0, mod['$$ACTION_3'])(...args)),
    'e35476d11c777b26667915186a13fedb75b19bf1': (...args)=>Promise.resolve(__turbopack_require__("[project]/node_modules/.pnpm/ai@3.2.16_openai@4.52.2_react@18.3.1_svelte@4.2.18_vue@3.4.31_typescript@5.5.2__zod@3.23.8/node_modules/ai/rsc/dist/rsc-server.mjs [app-rsc] (ecmascript)")).then((mod)=>(0, mod['$$ACTION_0'])(...args)),
    'ebc79be7431569f619b8d3c6ffab40a5718aa134': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/login/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['getUser'])(...args)),
    'f1a7cb54f3fd619d4be5d2b973bfd46453125cb6': (...args)=>Promise.resolve(__turbopack_require__("[project]/app/actions.ts [app-rsc] (ecmascript)")).then((mod)=>(0, mod['getSharedChat'])(...args))
});

}.call(this) }),

};

//# sourceMappingURL=_bc27ff._.js.map