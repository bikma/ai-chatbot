(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/ssr/edge-wrapper_b4b4c7.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/ssr/edge-wrapper_b4b4c7.js",
  "chunks": [
    "chunks/ssr/_2f6b93._.js",
    "chunks/ssr/2d6a6_@auth_core_702dc0._.js",
    "chunks/ssr/25314_jose_dist_browser_b678e9._.js",
    "chunks/ssr/34e2e_react_4e4194._.js",
    "chunks/ssr/node_modules__pnpm_686439._.js",
    "chunks/ssr/_3c8259._.js"
  ],
  "source": "entry"
});
