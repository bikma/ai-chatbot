(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/ssr/edge-wrapper_6a4164.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/ssr/edge-wrapper_6a4164.js",
  "chunks": [
    "chunks/ssr/_5581a7._.js",
    "chunks/ssr/2d6a6_@auth_core_702dc0._.js",
    "chunks/ssr/25314_jose_dist_browser_b678e9._.js",
    "chunks/ssr/34e2e_react_4e4194._.js",
    "chunks/ssr/node_modules__pnpm_ed4563._.js",
    "chunks/ssr/_3c8259._.js"
  ],
  "source": "entry"
});
