Error.stackTraceLimit = 100;
global.self = global;
require("./chunks/[turbopack-node]__a86098._.js");
require("./chunks/postcss_config_js_transform_ts_b0fe12._.js");
require("./chunks/[output]__next_transform_cc8fc1.js");
require("./chunks/[output]__next_transform_ad1f0f.js");
