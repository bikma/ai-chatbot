(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_js_transform_ts_2cce8e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_js_transform_ts_2cce8e._.js",
  "chunks": [
    "chunks/node_modules__pnpm_475f19._.js",
    "chunks/_0b8f1c._.js"
  ],
  "source": "dynamic"
});
