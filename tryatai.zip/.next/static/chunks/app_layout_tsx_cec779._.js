(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_cec779._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_cec779._.js",
  "chunks": [
    "static/chunks/_9ef1b4._.js",
    "static/chunks/ae632_next_eb2216._.js",
    "static/chunks/9722c_tailwind-merge_dist_bundle-mjs_mjs_a0fe8d._.js",
    "static/chunks/f8f15_react-icons_io5_index_mjs_175dc9._.js",
    "static/chunks/f8f15_react-icons_lib_68da56._.js",
    "static/chunks/52f43_@radix-ui_react-icons_dist_react-icons_esm_028f1c.js",
    "static/chunks/407ca_framer-motion_dist_es_94e0e7._.js",
    "static/chunks/node_modules__pnpm_4231d2._.js",
    "static/chunks/_f0a753._.css"
  ],
  "source": "dynamic"
});
