(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_play-ground_page_tsx_46afa1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_play-ground_page_tsx_46afa1._.js",
  "chunks": [
    "static/chunks/_200429._.js",
    "static/chunks/6e532_react-syntax-highlighter_dist_30b7cb._.js",
    "static/chunks/node_modules__pnpm_f9e053._.js",
    "static/chunks/6db0f_refractor_lang_d93fc0._.js",
    "static/chunks/6db0f_refractor_597452._.js",
    "static/chunks/f5950_micromark_dev_lib_fc124b._.js",
    "static/chunks/4c273_micromark-core-commonmark_dev_lib_76580a._.js",
    "static/chunks/node_modules__pnpm_3d09f2._.js",
    "static/chunks/components_stocks_b36f8d._.js"
  ],
  "source": "dynamic"
});
