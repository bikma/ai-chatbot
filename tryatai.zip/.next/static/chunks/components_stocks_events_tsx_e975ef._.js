(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_stocks_events_tsx_e975ef._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_stocks_events_tsx_e975ef._.js",
  "chunks": [
    "static/chunks/adeb4_date-fns_8f7098._.js",
    "static/chunks/components_stocks_events_tsx_06e132._.js"
  ],
  "source": "dynamic"
});
