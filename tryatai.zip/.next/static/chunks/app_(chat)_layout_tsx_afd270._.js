(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(chat)_layout_tsx_afd270._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(chat)_layout_tsx_afd270._.js",
  "chunks": [
    "static/chunks/app_(chat)_layout_tsx_90a9aa._.js"
  ],
  "source": "dynamic"
});
