(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/components_stocks_3fd20e._.js", {

"[project]/components/stocks/stock.tsx [app-client] (ecmascript, async loader)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_747183._.js",
  "static/chunks/components_stocks_stock_tsx_b4cdd2._.js",
  "static/chunks/components_stocks_stock_tsx_a887e3._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/components/stocks/stock.tsx [app-client] (ecmascript)");
    });
});

})()),
"[project]/components/stocks/stock-purchase.tsx [app-client] (ecmascript, async loader)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "static/chunks/components_stocks_stock-purchase_tsx_d6a1b8._.js",
  "static/chunks/components_stocks_stock-purchase_tsx_fde572._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/components/stocks/stock-purchase.tsx [app-client] (ecmascript)");
    });
});

})()),
"[project]/components/stocks/stocks.tsx [app-client] (ecmascript, async loader)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "static/chunks/components_stocks_stocks_tsx_036c53._.js",
  "static/chunks/components_stocks_stocks_tsx_b0df87._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/components/stocks/stocks.tsx [app-client] (ecmascript)");
    });
});

})()),
"[project]/components/stocks/events.tsx [app-client] (ecmascript, async loader)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "static/chunks/adeb4_date-fns_8f7098._.js",
  "static/chunks/components_stocks_events_tsx_06e132._.js",
  "static/chunks/components_stocks_events_tsx_e975ef._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/components/stocks/events.tsx [app-client] (ecmascript)");
    });
});

})()),
}]);