(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_stocks_stocks_tsx_b0df87._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_stocks_stocks_tsx_b0df87._.js",
  "chunks": [
    "static/chunks/components_stocks_stocks_tsx_036c53._.js"
  ],
  "source": "dynamic"
});
