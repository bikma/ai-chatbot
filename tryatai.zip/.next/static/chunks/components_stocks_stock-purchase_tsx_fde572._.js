(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_stocks_stock-purchase_tsx_fde572._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_stocks_stock-purchase_tsx_fde572._.js",
  "chunks": [
    "static/chunks/components_stocks_stock-purchase_tsx_d6a1b8._.js"
  ],
  "source": "dynamic"
});
