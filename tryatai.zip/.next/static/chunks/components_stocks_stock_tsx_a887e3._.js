(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_stocks_stock_tsx_a887e3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_stocks_stock_tsx_a887e3._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_747183._.js",
    "static/chunks/components_stocks_stock_tsx_b4cdd2._.js"
  ],
  "source": "dynamic"
});
