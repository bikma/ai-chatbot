(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_play-ground_layout_tsx_16cc3d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_play-ground_layout_tsx_16cc3d._.js",
  "chunks": [
    "static/chunks/app_play-ground_layout_tsx_b89362._.js"
  ],
  "source": "dynamic"
});
