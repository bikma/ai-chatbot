(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/ae632_next_dist_esm_build_templates_app-page_0ebc83.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/ae632_next_dist_esm_build_templates_app-page_0ebc83.js",
  "chunks": [
    "static/chunks/ae632_next_dist_compiled_react_8f3465._.js",
    "static/chunks/ae632_next_dist_compiled_react-dom_cjs_react-dom_development_237775.js",
    "static/chunks/ae632_next_dist_compiled_react-dom_ccaa85._.js",
    "static/chunks/ae632_next_dist_compiled_2de704._.js",
    "static/chunks/ae632_next_dist_client_f22acc._.js",
    "static/chunks/ae632_next_dist_ffded1._.js",
    "static/chunks/90481_@swc_helpers_cjs_e55b81._.js",
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_7ffffa._.js"
  ],
  "source": "entry"
});
