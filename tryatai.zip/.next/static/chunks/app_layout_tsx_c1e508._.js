(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_c1e508._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_c1e508._.js",
  "chunks": [
    "static/chunks/_e14490._.css",
    "static/chunks/_02769f._.js",
    "static/chunks/80c44_next_847790._.js",
    "static/chunks/9722c_tailwind-merge_dist_bundle-mjs_mjs_a0fe8d._.js",
    "static/chunks/52f43_@radix-ui_react-icons_dist_react-icons_esm_028f1c.js",
    "static/chunks/97fae_framer-motion_dist_es_56f3d3._.js",
    "static/chunks/node_modules__pnpm_1c875f._.js"
  ],
  "source": "dynamic"
});
