(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/80c44_next_dist_esm_build_templates_app-page_7412ad.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/80c44_next_dist_esm_build_templates_app-page_7412ad.js",
  "chunks": [
    "static/chunks/80c44_next_dist_compiled_react_62155b._.js",
    "static/chunks/80c44_next_dist_compiled_react-dom_cjs_react-dom_development_ff8e01.js",
    "static/chunks/80c44_next_dist_compiled_react-dom_a04830._.js",
    "static/chunks/80c44_next_dist_compiled_37ee9c._.js",
    "static/chunks/80c44_next_dist_client_c5844c._.js",
    "static/chunks/80c44_next_dist_2967b5._.js",
    "static/chunks/90481_@swc_helpers_cjs_e55b81._.js",
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_974e5c._.js"
  ],
  "source": "entry"
});
