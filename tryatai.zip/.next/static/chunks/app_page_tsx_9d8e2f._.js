(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_9d8e2f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_9d8e2f._.js",
  "chunks": [
    "static/chunks/ae632_next_dist_ca1cd7._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js"
  ],
  "source": "dynamic"
});
